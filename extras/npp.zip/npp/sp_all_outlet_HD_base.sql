/****** Object:  StoredProcedure [ebi].[sp_all_outlet_HD_base]    Script Date: 6/14/2023 10:40:31 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER PROC [ebi].[sp_all_outlet_HD_base] @iri_week_end_date [nvarchar](200),@Fiscal_Month [INT],@Fiscal_YEAR [INT] AS 
BEGIN

select @iri_week_end_date = cast(@iri_week_end_date as Date)

/*
DECLARE @Fiscal_Month INT, @Fiscal_YEAR INT, @iri_week_end_date date
select @Fiscal_Month = Fiscal_Month, @Fiscal_YEAR = Fiscal_YEAR from (select TOP 1* from (select DISTINCT Fiscal_Month, Fiscal_YEAR from ebi.calendar_week_dim2 where calendar_month = MONTH(DATEADD(MM, DATEDIFF(MM, 0, GETDATE()) - 1, 0)) and calendar_year = YEAR(DATEADD(MM, DATEDIFF(MM, 0, GETDATE()) - 1, 0))) tbl) new_tbl

select @iri_week_end_date = max(wk_end_dt) from [ebi].[cal_445_wk_dim_2] where fiscal_yr_cd = @Fiscal_YEAR and rank_val = @Fiscal_Month group by fiscal_yr_cd,rank_val 
select @iri_week_end_date
*/



IF OBJECT_ID('tempdb..#all_outlet_HD_time_aggregated') IS NOT NULL
BEGIN
DROP TABLE #all_outlet_HD_time_aggregated
END

CREATE TABLE #all_outlet_HD_time_aggregated
WITH
( DISTRIBUTION = ROUND_ROBIN
)
AS
select SKU_Nbr, @iri_week_end_date as Week_end_date , 'Last 4-5 week' as Time_period, sum(COALESCE(Dollar_Sales, 0)) as 'Consumption' from ebi.ebi_HD_base where Week_End_Date in (select wk_end_dt from [ebi].[cal_445_wk_dim_2] where fiscal_yr_cd = @Fiscal_YEAR and rank_val = @Fiscal_Month )
GROUP BY SKU_Nbr

UNION

select SKU_Nbr, @iri_week_end_date as Week_end_date , 'Last 13 weeks' as Time_period, sum(COALESCE(Dollar_Sales, 0)) as 'Consumption' from ebi.ebi_HD_base where Week_End_Date in (select TOP 13 wk_end_dt from [ebi].[cal_445_wk_dim_2] where wk_end_dt <= @iri_week_end_date order by wk_end_dt desc)
GROUP BY SKU_Nbr

UNION

select SKU_Nbr, @iri_week_end_date as Week_end_date , 'Last 52 weeks' as Time_period, sum(COALESCE(Dollar_Sales, 0)) as 'Consumption' from ebi.ebi_HD_base where Week_End_Date in (select TOP 52 wk_end_dt from [ebi].[cal_445_wk_dim_2] where wk_end_dt <= @iri_week_end_date order by wk_end_dt desc)
GROUP BY SKU_Nbr


select * from #all_outlet_HD_time_aggregated


IF OBJECT_ID('tempdb..#all_outlet_HD_mapped') IS NOT NULL
BEGIN
DROP TABLE #all_outlet_HD_mapped
END

CREATE TABLE #all_outlet_HD_mapped
WITH
( 
DISTRIBUTION = ROUND_ROBIN
)
AS
select a.SKU_Nbr, a.Week_end_date, a.Time_period, a.Consumption, b.BU, b.Segment
from #all_outlet_HD_time_aggregated a
inner JOIN (select * from [ebi].[ebi_all_outlet_HD_Map] where BU is NOT NULL and Active_Flag = 'Y') b
ON a.SKU_Nbr = b.SKU_Nbr

--select * from #all_outlet_HD_mapped where Segment = 'Hypochlorite'


IF OBJECT_ID('tempdb..#all_outlet_HD_BU_aggregated') IS NOT NULL
BEGIN
DROP TABLE #all_outlet_HD_BU_aggregated
END

CREATE TABLE #all_outlet_HD_BU_aggregated
WITH
( 
DISTRIBUTION = ROUND_ROBIN
)
AS

select BU AS AO_BU, 'Total' AS AO_Segment, Week_End_Date, Time_Period, 'Clorox' as AO_Share_Component, 'BU Total' as AO_level, sum(Consumption) as Sales
FROM #all_outlet_HD_mapped
GROUP BY   Week_end_date, Time_Period, BU

UNION

select a.BU AS AO_BU, a.Segment as AO_Segment, a.Week_End_Date, a.Time_Period, 'Clorox' as AO_Share_Component, 'Segment Total' as AO_level, sum(a.Consumption) as Sales
FROM (select * from #all_outlet_HD_mapped where Segment IS NOT NULL) a
GROUP BY a.Week_end_date, a.Time_Period, a.BU, a.Segment


UNION

select 'Total' AS AO_BU, 'Total' as AO_Segment, a.Week_End_Date, a.Time_Period, 'Clorox' as AO_Share_Component, 'All Category Total' as AO_level, sum(a.Consumption) as Sales
FROM (select * from #all_outlet_HD_mapped) a
GROUP BY a.Week_end_date, a.Time_Period

UNION

select 'Total excl VMS/Burts' AS AO_BU, a1.AO_Segment, a1.Week_end_date, a1.Time_period, a1.AO_Share_Component, a1.AO_Level , COALESCE(a1.Sales,0) - COALESCE(b1.Sales,0) AS Sales
from
(select 'Total' AS AO_BU, 'Total' as AO_Segment, a.Week_End_Date, a.Time_Period, 'Clorox' as AO_Share_Component, 'All Category Total' as AO_level, sum(a.Consumption) as Sales
FROM (select * from #all_outlet_HD_mapped) a
GROUP BY a.Week_end_date, a.Time_Period) as a1
LEFT JOIN
(select 'VMS/Burts' AS AO_BU, 'Total' as AO_Segment, a.Week_End_Date, a.Time_Period, 'Clorox' as AO_Share_Component, 'All Category Total' as AO_level, sum(a.Consumption) as Sales
FROM (select * from #all_outlet_HD_mapped where BU in ('Burt''s','VMS')) a
GROUP BY a.Week_end_date, a.Time_Period) as b1
ON a1.Week_end_date = b1.Week_end_date and
a1.Time_Period = b1.Time_Period

--select * from #all_outlet_HD_BU_aggregated 



 IF OBJECT_ID('tempdb..#HD_sharetab_clx') IS NOT NULL
BEGIN
DROP TABLE #HD_sharetab_clx
END

CREATE TABLE #HD_sharetab_clx
WITH
( DISTRIBUTION = ROUND_ROBIN
)
AS
  select [Source], Retailer, 
  case
  when ([Type] = 'Clx') then CONCAT(Product,[Type])
  when ([Type] = 'Cat') then Product
  end as BUName,
  [Type],
  Category,
  Product,
  [Dollar Sales],
  Time_Period,
  Week_end_date
  from
  (
SELECT 
	   case 
	   when ([AO_Share_Component] = 'Category') then 'Cat'
	   when ([AO_Share_Component] = 'Clorox') then 'Clx'
	   end as [Type]
	  ,'Home Depot' as [Source]
      ,'Home Depot' as [Retailer]
      ,[Time_Period]
      ,[Week_End_Date]
      ,[Sales] as [Dollar Sales]
	  ,case 
	  when (AO_Segment = 'Total' and AO_Level = 'BU Total') then AO_BU
	  when (AO_Level = 'Segment Total') then AO_Segment
	  when (AO_Level in ('All Category Total', 'Custom Total')) then AO_BU
	  when (AO_Segment <> 'Total' and AO_Level = 'BU Total') then AO_Segment
	  end as Product,
	  case 
	  when (AO_Segment = 'Total' and AO_Level = 'BU Total') then NULL
	  when (AO_Level = 'Segment Total') then AO_BU
	  when (AO_Level in ('All Category Total', 'Custom Total')) then NULL
	  when (AO_Segment <> 'Total' and AO_Level = 'BU Total') then AO_BU
	  end as Category
  FROM #all_outlet_HD_BU_aggregated
  ) a
 

select * from #HD_sharetab_clx order by 8, 5, 6

----------------------category calculations-------------



 IF OBJECT_ID('tempdb..#HD_sharetab_share_value') IS NOT NULL
BEGIN
DROP TABLE #HD_sharetab_share_value
END

CREATE TABLE #HD_sharetab_share_value
WITH
( DISTRIBUTION = ROUND_ROBIN
)
AS
  select [Source], Retailer, 
  case
  when ([Type] = 'Clx') then CONCAT(Product,[Type])
  when ([Type] = 'Cat') then Product
  end as BUName,
  [Type],
  Category,
  Product,
  [Share],
  Time_Period,
  Week_end_date
  from
  (
SELECT 
	   case 
	   when ([AO_Share Component] = 'Category') then 'Cat'
	   when ([AO_Share Component] = 'Clorox') then 'Clx'
	   end as [Type]
	   ,'Home Depot' as [Source]
      ,'Home Depot' as [Retailer]
      ,[Time_Period]
      ,IRI_month_end_date AS [Week_End_Date]
      ,[Share] as [Share]
	  ,case 
	  when (AO_Segment = 'Total' and AO_Level = 'BU Total') then AO_BU
	  when (AO_Level = 'Segment Total') then AO_Segment
	  when (AO_Level in ('All Category Total', 'Custom Total')) then AO_BU
	  when (AO_Segment <> 'Total' and AO_Level = 'BU Total') then AO_Segment
	  end as Product,
	  case 
	  when (AO_Segment = 'Total' and AO_Level = 'BU Total') then NULL
	  when (AO_Level = 'Segment Total') then AO_BU
	  when (AO_Level in ('All Category Total', 'Custom Total')) then NULL
	  when (AO_Segment <> 'Total' and AO_Level = 'BU Total') then AO_BU
	  end as Category
 FROM [ebi].[ebi_all_outlet_iri_panel_share] where IRI_month_end_date = @iri_week_end_date and Retailer = 'Home Depot'
  ) a


select * from #HD_sharetab_share_value order by 8,4,5,6


--------------------LEVEL 1 formuale for category calculations
--------------------

IF OBJECT_ID('tempdb..#HD_sharetab_cat') IS NOT NULL
BEGIN
DROP TABLE #HD_sharetab_cat
END 
CREATE TABLE #HD_sharetab_cat
WITH
(
DISTRIBUTION = ROUND_ROBIN
)
AS
select * from (
select  a.[Source], a.Retailer, a.Product as [BUName] , 'Cat' as [Type], a.Category, a.Product,
(a.[Dollar Sales] / NULLIF(b.Share,0)) AS [Dollar Sales],  a.Time_Period, a.Week_end_date
from #HD_sharetab_clx a
inner join #HD_sharetab_share_value b
on a.[Source] = b.[Source] and
a.Retailer = b.Retailer and
a.BUName = b.BUName and
a.[Type] = b.[Type] and
a.Product = b.Product and 
a.Time_Period = b.Time_Period
and a.Week_end_date = b.Week_end_date
) a1
where a1.[Dollar Sales] is NOT NULL


--select * from #HD_sharetab_cat  order by 8,5,6,3
-------------------------

IF OBJECT_ID('tempdb..#panel_raw_data_for_special_cases') IS NOT NULL
BEGIN
DROP TABLE #panel_raw_data_for_special_cases
END 
CREATE TABLE #panel_raw_data_for_special_cases
WITH
(
DISTRIBUTION = ROUND_ROBIN
)
AS
select * from (
SELECT [AO_BU],[AO_Segment],[AO_Level],[AO_Share Component],[Product],[Retailer],[Time_Period], b.[Week_end_date],c.IRI_month_end_date as [IRI_month_end_Date],[Dollar_Sales],null as Share, GETDATE() as  [Modified_time]
FROM [ebi].[ebi_all_outlet_panel_base] b
INNER JOIN  [ebi].[ebi_all_outlet_iri_product_mapping] a
ON a.AO_Product = b.Product
INNER JOIN ebi.calendar_panel_iri c on b.Week_end_date = c.Panel_week_end_date ) a1
where a1.IRI_month_end_date = @iri_week_end_date and a1.Retailer = 'Home Depot'

--select * from #panel_raw_data_for_special_cases where AO_BU = 'Home Care' and AO_segment = 'Total' in ('Disinfecting Aerosol', 'Wet Floor')
---------------------------------------------------
---------------------------------------------------
----PELLETS
DELETE FROM #HD_sharetab_cat where Product in ('Pellets')
--Pellets 52 weeks category  (Level 2 formulae for category calculations)

INSERT INTO #HD_sharetab_cat([Source], [Retailer],[BUName],[Type],[Category], [Product], [Dollar Sales], [Time_Period], [Week_end_date])
select a.Source, a.Retailer, c.AO_Segment as BUName, a.[Type], c.AO_BU as Category, c.AO_Segment as Product, (a.[Dollar Sales]*c.[Dollar_Sales])/NULLIF(b.[Dollar_Sales],0) as [Dollar Sales], c.Time_Period, a.Week_end_date
from 
(select * from #HD_sharetab_cat where Time_Period = 'Last 52 weeks' and [Type] = 'Cat' and Category is NULL
and Product = 'Kingsford') a
INNER JOIN
(select * from #panel_raw_data_for_special_cases where Time_Period = 'Last 52 weeks' and [AO_Share Component] = 'Category'
and AO_BU = 'Kingsford' and AO_Segment = 'Total') b
ON a.Time_Period = b.Time_Period and
a.Product = b.AO_BU
INNER JOIN
(select * from #panel_raw_data_for_special_cases where Time_Period = 'Last 52 weeks' and [AO_Share Component] = 'Category'
and AO_BU = 'Kingsford' and AO_Segment = 'Pellets') c
ON a.Time_Period = c.Time_Period and 
a.Product = c.AO_BU


--Pellets 13 weeks category(Level 2 formulae for category calculations)

INSERT INTO #HD_sharetab_cat([Source], [Retailer],[BUName],[Type],[Category], [Product], [Dollar Sales], [Time_Period], [Week_end_date])
select c.Source, c.Retailer, c.BUName as BUName, c.[Type], c.Category as Category, c.Product as Product, (a.[Dollar Sales]*c.[Dollar Sales])/NULLIF(b.[Dollar Sales],0) as [Dollar Sales], a.Time_Period, c.Week_end_date
from 
(select * from #HD_sharetab_cat where Time_Period = 'Last 13 weeks' and [Type] = 'Cat' and Category = 'Kingsford'
and Product = 'Charcoal') a
INNER JOIN
(select * from #HD_sharetab_cat where Time_Period = 'Last 52 weeks' and [Type] = 'Cat' and Category = 'Kingsford'
and Product = 'Charcoal') b
ON a.Category = b.Category
INNER JOIN
(select * from #HD_sharetab_cat where Time_Period = 'Last 52 weeks' and [Type] = 'Cat' and Category = 'Kingsford'
and Product = 'Pellets') c
ON a.Category = c.Category


--Pellets 4-5 week category(Level 2 formulae for category calculations)

INSERT INTO #HD_sharetab_cat([Source], [Retailer],[BUName],[Type],[Category], [Product], [Dollar Sales], [Time_Period], [Week_end_date])
select c.Source, c.Retailer, c.BUName as BUName, c.[Type], c.Category as Category, c.Product as Product, (a.[Dollar Sales]*c.[Dollar Sales])/NULLIF(b.[Dollar Sales],0) as [Dollar Sales], a.Time_Period, c.Week_end_date
from 
(select * from #HD_sharetab_cat where Time_Period = 'Last 4-5 week' and [Type] = 'Cat' and Category is NULL
and Product = 'Kingsford') a
INNER JOIN
(select * from #HD_sharetab_cat where Time_Period = 'Last 13 weeks' and [Type] = 'Cat' and Category is NULL
and Product = 'Kingsford') b
ON a.Product= b.Product
INNER JOIN
(select * from #HD_sharetab_cat where Time_Period = 'Last 13 weeks' and [Type] = 'Cat' and Category = 'Kingsford'
and Product = 'Pellets') c
ON a.Product = c.Category

--Wet Floor, Disinfecting Aerosol 
--------------------------
--------------------------
DELETE FROM #HD_sharetab_cat where Product in ('Wet Floor', 'Disinfecting Aerosol')

-----Wet Floor, Disinfecting Aerosol 52, 13 weeks category (Level 2 formulae for category calculations)


INSERT INTO #HD_sharetab_cat([Source], [Retailer],[BUName],[Type],[Category], [Product], [Dollar Sales], [Time_Period], [Week_end_date])
select a.[Source], a.Retailer, c.AO_Segment as BUName, a.[Type], c.AO_BU as Category, c.AO_Segment as Product, (a.[Dollar Sales]*c.[Dollar_Sales])/NULLIF(b.[Dollar_Sales],0) as [Dollar Sales], c.Time_Period, a.Week_end_date
from 
(select * from #HD_sharetab_cat where Time_Period in ('Last 52 weeks','Last 13 weeks') and [Type] = 'Cat' and Category is NULL
and Product = 'Home Care') a
INNER JOIN
(select * from #panel_raw_data_for_special_cases where Time_Period in ('Last 52 weeks', 'Last 13 weeks') and [AO_Share Component] = 'Category'
and AO_BU = 'Home Care' and AO_Segment ='Total') b
ON a.Time_Period = b.Time_Period and
a.Product = b.AO_BU
INNER JOIN
(select * from #panel_raw_data_for_special_cases where Time_Period in ('Last 52 weeks', 'Last 13 weeks') and [AO_Share Component] = 'Category'
and AO_BU = 'Home Care' and AO_Segment in ('Wet Floor', 'Disinfecting Aerosol')) c
ON a.Time_Period = c.Time_Period and 
a.Product = c.AO_BU
--------------------------------------

-----------------if 13 weeks Disinfecting Aerosol is NULL or row count is zero then calculating for disinfecting Aerosol (Level 3 formulae for category calculations for 13 weeks only)

IF ((select COUNT(*) from #HD_sharetab_cat where Time_Period in ('Last 13 Weeks') and Product in ('Disinfecting Aerosol') and [Dollar Sales] is NOT NULL )) = 0
BEGIN

delete from #HD_sharetab_cat where Time_Period in ('Last 13 Weeks') and Product in ('Disinfecting Aerosol')

INSERT INTO #HD_sharetab_cat([Source], [Retailer],[BUName],[Type],[Category], [Product], [Dollar Sales], [Time_Period], [Week_end_date])
select a.[Source], a.Retailer, c.BUName as BUName, a.[Type], c.Category, c.Product, (a.[Dollar Sales]*c.[Dollar Sales])/NULLIF(b.[Dollar Sales],0) as [Dollar Sales], a.Time_Period, a.Week_end_date
from 
(select * from #HD_sharetab_cat where Time_Period in ('Last 13 weeks') and [Type] = 'Cat' and Category is NULL
and Product = 'Home Care') a
INNER JOIN
(select * from #HD_sharetab_cat where Time_Period in ('Last 52 weeks') and [Type] = 'Cat' and Category is NULL
and Product = 'Home Care') b
ON a.[Source] = b.[Source] and
a.Retailer = b.Retailer and
a.Product = b.Product and
ISNULL(a.Category,'`') = ISNULL(b.Category,'`') and
a.Week_end_date = b.Week_end_date
INNER JOIN
(select * from #HD_sharetab_cat where Time_Period in ('Last 52 weeks') and [Type] = 'Cat' and Category = 'Home Care'
and Product = 'Disinfecting Aerosol') c
ON a.[Source] = c.[Source] and
a.Retailer = c.Retailer and
a.Product = c.Category and
a.Week_end_date = b.Week_end_date

END

---NOTE: For wet_floor and disinfecting aerosol 4-5 weeks calculations are not done, for this data is not as per Chris's excel file
--------------
---category All category TOTAL

INSERT INTO #HD_sharetab_cat([Source], [Retailer],[BUName],[Type],[Category], [Product], [Dollar Sales], [Time_Period], [Week_end_date])
select [Source], Retailer, 'Total' AS BUName, [Type], NULL as Category, 'Total' AS Product, sum(coalesce([Dollar Sales],0)) as Sales, Time_Period, Week_End_Date
FROM (select * from #HD_sharetab_cat where Category is NULL and Product <> 'Total') a
GROUP BY [Source], Retailer, [Type], Week_end_date, Time_Period

union

select a1.[Source], a1.Retailer, 'Total excl VMS/Burts' AS BUName, a1.[Type], NULL as Category, 'Total excl VMS/Burts' AS Product, (coalesce(a1.[Sales],0) - coalesce(b1.[Sales],0)) as Sales, a1.Time_Period, a1.Week_End_Date 
from (select [Source], Retailer, 'Total' AS BUName, [Type], NULL as Category, 'Total' AS Product, sum(coalesce([Dollar Sales],0)) as Sales, Time_Period, Week_End_Date
FROM (select * from #HD_sharetab_cat where Category is NULL and Product <> 'Total') a
GROUP BY [Source], Retailer, [Type], Week_end_date, Time_Period ) a1
LEFT JOIN
(select [Source], Retailer, 'VMS/Burts' AS BUName, [Type], NULL as Category, 'VMS/Burts' AS Product, sum(coalesce([Dollar Sales],0)) as Sales, Time_Period, Week_End_Date
FROM (select * from #HD_sharetab_cat where Category is NULL and Product in ('VMS', 'Burts')) b
GROUP BY [Source], Retailer, [Type], Week_end_date, Time_Period) b1
ON a1.[Source] = b1.[Source] and
a1.[Retailer] = b1.[Retailer] and
a1.[Type] = b1.[Type] and
a1.Time_Period = b1.Time_Period and
a1.Week_end_date = b1.Week_end_date


--select * from #HD_sharetab_cat order by 8, 5, 6

--select * from #HD_sharetab_clx order by 8, 5, 6

-----


DELETE FROM [ebi].[ebi_all_outlet_HD_base] where [Week_end_date] in (select DISTINCT([Week_end_date]) from #HD_sharetab_clx)
INSERT INTO [ebi].[ebi_all_outlet_HD_base]([Source], [Retailer], [BUName], [Type], [Category], [Product],[Dollar Sales],[Time_Period], [Week_end_date] )
SELECT [Source], [Retailer], [BUName], [Type], [Category], [Product],[Dollar Sales],[Time_Period],  [Week_end_date] FROM #HD_sharetab_clx

INSERT INTO [ebi].[ebi_all_outlet_HD_base]([Source], [Retailer], [BUName], [Type], [Category], [Product],[Dollar Sales],[Time_Period], [Week_end_date] )
SELECT [Source], [Retailer], [BUName], [Type], [Category], [Product],[Dollar Sales],[Time_Period],  [Week_end_date] FROM #HD_sharetab_cat


END