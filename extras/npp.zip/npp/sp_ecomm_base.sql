/****** Object:  StoredProcedure [ebi].[sp_ecomm_base]    Script Date: 2/2/2023 9:06:35 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROC [ebi].[sp_ecomm_base] AS

begin

delete from [ebi].[ebi_ecomm_stg] where Month_End_Date > CONVERT(date, GETDATE())
/*deleting records based on DISTINCT Week_End_Date from base table and reloading*/
IF OBJECT_ID('tempdb..#distinct_Month_end_date_tobe_deleted') IS NOT NULL
BEGIN
DROP TABLE #distinct_Month_end_date_tobe_deleted
END

CREATE TABLE #distinct_Month_end_date_tobe_deleted
WITH
( DISTRIBUTION = ROUND_ROBIN
)
AS
select a.[Product], a.[Geography], a.[Time_Period],a.[Month_End_Date] from
(select distinct [Product], [Geography], [Time_Period],[Month_End_Date] from [ebi].[ebi_ecomm_stg]) a

--select * from #distinct_week_end_date_tobe_deleted order by Week_End_Date
--select * from #distinct_week_end_date_tobe_deleted

delete a from [ebi].[ebi_ecomm_iri_base] a
inner join #distinct_Month_end_date_tobe_deleted b on 
a.Product = b.Product and
a.Geography = b.Geography and
a.Time_Period = B.Time_Period and
a.Month_End_Date = b.Month_End_Date

drop table #distinct_Month_end_date_tobe_deleted
 
insert into [ebi].[ebi_ecomm_iri_base] ([Product], [Geography], [Time_Period],[Month_End_Date],[Dollar_Sales],[Dollar_Sales_Year_AGO]) 
select [Product], [Geography], [Time_Period],[Month_End_Date],[Dollar_Sales],[Dollar_Sales_Year_AGO]
 from  [ebi].[ebi_ecomm_stg]



END;

--exec [ebi].[sp_ecomm_base]
--select * from [ebi].[ebi_ecomm_base]
--select * from [ebi].[ebi_ecomm_stg]

--select * into ebi.ebi_ecomm_iri_base
--from [ebi].[ebi_ecomm_base]

GO
