/****** Object:  StoredProcedure [ebi].[sp_all_outlet_DG_base]    Script Date: 6/14/2023 10:40:24 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER PROC [ebi].[sp_all_outlet_DG_base] @iri_week_end_date [nvarchar](200),@Fiscal_Month [INT],@Fiscal_YEAR [INT] AS 
BEGIN

select @iri_week_end_date = cast(@iri_week_end_date as Date)


/*
DECLARE @Fiscal_Month INT, @Fiscal_YEAR INT, @iri_week_end_date date
select @Fiscal_Month = Fiscal_Month, @Fiscal_YEAR = Fiscal_YEAR from (select TOP 1* from (select DISTINCT Fiscal_Month, Fiscal_YEAR from ebi.calendar_week_dim2 where calendar_month = MONTH(DATEADD(MM, DATEDIFF(MM, 0, GETDATE()) - 1, 0)) and calendar_year = YEAR(DATEADD(MM, DATEDIFF(MM, 0, GETDATE()) - 1, 0))) tbl) new_tbl

select @iri_week_end_date = max(wk_end_dt) from [ebi].[cal_445_wk_dim_2] where fiscal_yr_cd = @Fiscal_YEAR and rank_val = @Fiscal_Month group by fiscal_yr_cd,rank_val 
select @iri_week_end_date
*/



------*****-------
--checking if 12 months are available for aggregation, if True then aggregate for 12 months else, blank table for 12 months (52 weeks == 12 months, in DG we get monthly data)
declare @count_months_for_52 INT
select @count_months_for_52 = COUNT(distinct(month_end_date)) from ebi.ebi_DG_base  where month_end_date in (select TOP 12 month_end_dt from (select fiscal_yr_cd, rank_val, max(wk_end_dt) as month_end_dt from [ebi].[cal_445_wk_dim] group by fiscal_yr_cd, rank_val) a where month_end_dt <= @iri_week_end_date order by month_end_dt desc)

IF OBJECT_ID('tempdb..#all_outlet_DG_time_aggregated_52weeks') IS NOT NULL
BEGIN
DROP TABLE #all_outlet_DG_time_aggregated_52weeks
END

IF @count_months_for_52 = 12
BEGIN
CREATE TABLE #all_outlet_DG_time_aggregated_52weeks
WITH
( DISTRIBUTION = ROUND_ROBIN
)
AS
select Category, Segment, Sub_segment, Vendor, Brand, @iri_week_end_date as Week_end_date , 'Last 52 weeks' as Time_period, sum(COALESCE(Sales, 0)) as 'Sales' from ebi.ebi_DG_base where month_end_date in (select TOP 12 month_end_dt from (select fiscal_yr_cd, rank_val, max(wk_end_dt) as month_end_dt from [ebi].[cal_445_wk_dim] group by fiscal_yr_cd, rank_val) a where month_end_dt <= @iri_week_end_date order by month_end_dt desc)
GROUP BY month_end_date, Category, Segment, Sub_segment, Vendor, Brand
END
ELSE 
BEGIN
CREATE TABLE #all_outlet_DG_time_aggregated_52weeks
(
Category nvarchar(255),
Segment nvarchar(255),
Sub_segment nvarchar(255),
Vendor nvarchar(255),
Brand nvarchar(255),
Week_end_date Date,
Time_Period nvarchar(50),
Sales decimal(18,6)
)
WITH
(
DISTRIBUTION = ROUND_ROBIN
)
END


------*****-------
--checking if 3 months are available for aggregation, if True then aggregate for 3 months else, blank table for 3 months (13 weeks == 3 months, in DG we get monthly data)
declare @count_months_for_13 INT
select @count_months_for_13 = COUNT(distinct(month_end_date)) from ebi.ebi_DG_base  where month_end_date in (select TOP 3 month_end_dt from (select fiscal_yr_cd, rank_val, max(wk_end_dt) as month_end_dt from [ebi].[cal_445_wk_dim] group by fiscal_yr_cd, rank_val) a where month_end_dt <= @iri_week_end_date order by month_end_dt desc)

IF OBJECT_ID('tempdb..#all_outlet_DG_time_aggregated_13weeks') IS NOT NULL
BEGIN
DROP TABLE #all_outlet_DG_time_aggregated_13weeks
END

IF @count_months_for_13 = 3
BEGIN
CREATE TABLE #all_outlet_DG_time_aggregated_13weeks
WITH
( DISTRIBUTION = ROUND_ROBIN
)
AS
select Category, Segment, Sub_segment, Vendor, Brand, @iri_week_end_date as Week_end_date , 'Last 13 weeks' as Time_period, sum(COALESCE(Sales, 0)) as 'Sales' from ebi.ebi_DG_base where month_end_date in (select TOP 3 month_end_dt from (select fiscal_yr_cd, rank_val, max(wk_end_dt) as month_end_dt from [ebi].[cal_445_wk_dim] group by fiscal_yr_cd, rank_val) a where month_end_dt <= @iri_week_end_date order by month_end_dt desc)
GROUP BY month_end_date, Category, Segment, Sub_segment, Vendor, Brand
END
ELSE 
BEGIN
CREATE TABLE #all_outlet_DG_time_aggregated_13weeks
(
Category nvarchar(255),
Segment nvarchar(255),
Sub_segment nvarchar(255),
Vendor nvarchar(255),
Brand nvarchar(255),
Week_end_date Date,
Time_Period nvarchar(50),
Sales decimal(18,6)
)
WITH
(
DISTRIBUTION = ROUND_ROBIN
)
END

----------------------------

IF OBJECT_ID('tempdb..#all_outlet_DG_time_aggregated') IS NOT NULL
BEGIN
DROP TABLE #all_outlet_DG_time_aggregated
END

CREATE TABLE #all_outlet_DG_time_aggregated
WITH
( DISTRIBUTION = ROUND_ROBIN
)
AS
select Category, Segment, Sub_segment, Vendor, Brand, month_end_date AS [Week_end_date], Time_period, Sales from ebi.ebi_DG_base where month_end_date = @iri_week_end_date

UNION

select * from #all_outlet_DG_time_aggregated_13weeks

UNION

select * from #all_outlet_DG_time_aggregated_52weeks


-------****----------



IF OBJECT_ID('tempdb..#all_outlet_DG_mapped') IS NOT NULL
BEGIN
DROP TABLE #all_outlet_DG_mapped
END

CREATE TABLE #all_outlet_DG_mapped
WITH
( 
DISTRIBUTION = ROUND_ROBIN
)
AS
select a.Category, a.Segment, a.Sub_segment, b.Sub_segment as AO_subsegment, A.Vendor, A.Brand,  a.Week_end_date, a.Time_period, a.Sales, b.AO_BU, b.AO_Segment
from (select * from #all_outlet_DG_time_aggregated where Brand NOT IN ('Fresh Step', 'Scoop Away')) a
INNER JOIN (select * from [ebi].[ebi_all_outlet_DG_Map] where Sub_segment is NULL and Brand is NULL) b
ON a.Category = b.Category
and a.Segment = b.Segment

UNION

select a.Category, a.Segment, a.Sub_segment, b.Sub_segment as AO_subsegment, A.Vendor, A.Brand,  a.Week_end_date, a.Time_period, a.Sales, b.AO_BU, b.AO_Segment
from #all_outlet_DG_time_aggregated a
INNER join (select * from [ebi].[ebi_all_outlet_DG_Map] where Sub_segment is NOT NULL and Brand is NULL) b
ON a.Category = b.Category
and a.Segment = b.Segment
and a.Sub_segment = b.Sub_segment

UNION

select a.Category, a.Segment, a.Sub_segment, b.Sub_segment as AO_subsegment, A.Vendor, A.Brand,  a.Week_end_date, a.Time_period, a.Sales, b.AO_BU, b.AO_Segment
from (select * from #all_outlet_DG_time_aggregated where Brand IN ('Fresh Step', 'Scoop Away')) a
INNER join (select * from [ebi].[ebi_all_outlet_DG_Map] where Sub_segment is NULL and Brand is NOT NULL) b
ON a.Category = b.Category
and a.Segment = b.Segment
and a.Brand = b.Brand

--select * from #all_outlet_DG_mapped


-------*****-------


IF OBJECT_ID('tempdb..#all_outlet_DG_BU_aggregated') IS NOT NULL
BEGIN
DROP TABLE #all_outlet_DG_BU_aggregated
END

CREATE TABLE #all_outlet_DG_BU_aggregated
WITH
( 
DISTRIBUTION = ROUND_ROBIN
)
AS

select AO_BU AS AO_BU, 'Total' AS AO_Segment, Week_End_Date, Time_Period, 'Category' as AO_Share_Component, 'BU Total' as AO_level, sum(Sales) as Sales
FROM #all_outlet_DG_mapped
GROUP BY   Week_end_date, Time_Period, AO_BU

UNION

select a.AO_BU AS AO_BU, a.AO_Segment as AO_Segment, a.Week_End_Date, a.Time_Period, 'Category' as AO_Share_Component, 'Segment Total' as AO_level, sum(a.Sales) as Sales
FROM (select * from #all_outlet_DG_mapped where AO_Segment IS NOT NULL) a
GROUP BY a.Week_end_date, a.Time_Period, a.AO_BU, a.AO_Segment

UNION

select a.AO_BU AS AO_BU, 'Total' AS AO_Segment, a.Week_End_Date, a.Time_Period, 'Clorox' as AO_Share_Component, 'BU Total' as AO_level, sum(COALESCE(a.Sales,0)) as Sales
FROM (select * from #all_outlet_DG_mapped where Vendor = 'Clorox') a
GROUP BY a.Week_end_date, a.Time_Period, a.AO_BU

UNION

select a.AO_BU AS AO_BU, a.AO_Segment as AO_Segment, a.Week_End_Date, a.Time_Period, 'Clorox' as AO_Share_Component, 'Segment Total' as AO_level, sum(COALESCE(a.Sales,0)) as Sales
FROM (select * from #all_outlet_DG_mapped where AO_Segment IS NOT NULL and Vendor = 'Clorox') a
GROUP BY a.Week_end_date, a.Time_Period, a.AO_BU, a.AO_Segment

UNION

select 'Total' AS AO_BU, 'Total' as AO_Segment, a.Week_End_Date, a.Time_Period, 'Category' as AO_Share_Component, 'All Category Total' as AO_level, sum(COALESCE(a.Sales,0)) as Sales
FROM (select * from #all_outlet_DG_mapped where Category not in  ('Air Care','Convenience Clean')) a
GROUP BY a.Week_end_date, a.Time_Period

UNION

select 'Total' AS AO_BU, 'Total' as AO_Segment, a.Week_End_Date, a.Time_Period, 'Clorox' as AO_Share_Component, 'All Category Total' as AO_level, sum(COALESCE(a.Sales,0)) as Sales
FROM (select * from #all_outlet_DG_mapped where Vendor = 'Clorox' and Category not in  ('Air Care','Convenience Clean')) a
GROUP BY a.Week_end_date, a.Time_Period

UNION

select 'Total excl VMS/Burts' AS AO_BU, a1.AO_Segment, a1.Week_end_date, a1.Time_period, a1.AO_Share_Component, a1.AO_Level , COALESCE(a1.Sales,0) - COALESCE(b1.Sales,0) AS Sales
from
(select 'Total' AS AO_BU, 'Total' as AO_Segment, a.Week_End_Date, a.Time_Period, 'Category' as AO_Share_Component, 'All Category Total' as AO_level, sum(COALESCE(a.Sales,0)) as Sales
FROM (select * from #all_outlet_DG_mapped where Category not in ('Air Care','Convenience Clean')) a
GROUP BY a.Week_end_date, a.Time_Period) as a1
LEFT JOIN
(select 'VMS/Burts' AS AO_BU, 'Total' as AO_Segment, a.Week_End_Date, a.Time_Period, 'Category' as AO_Share_Component, 'All Category Total' as AO_level, sum(COALESCE(a.Sales,0)) as Sales
FROM (select * from #all_outlet_DG_mapped where AO_BU in ('Burt''s','VMS') and Category not in  ('Air Care','Convenience Clean')) a
GROUP BY a.Week_end_date, a.Time_Period) as b1
ON a1.Week_end_date = b1.Week_end_date and
a1.Time_Period = b1.Time_Period

UNION

select 'Total excl VMS/Burts' AS AO_BU, a1.AO_Segment, a1.Week_end_date, a1.Time_period, a1.AO_Share_Component, a1.AO_Level , COALESCE(a1.Sales,0) - COALESCE(b1.Sales,0) AS Sales
from
(select 'Total' AS AO_BU, 'Total' as AO_Segment, a.Week_End_Date, a.Time_Period, 'Clorox' as AO_Share_Component, 'All Category Total' as AO_level, sum(COALESCE(a.Sales,0)) as Sales
FROM (select * from #all_outlet_DG_mapped where Vendor = 'Clorox' and Category not in  ('Air Care','Convenience Clean')) a
GROUP BY a.Week_end_date, a.Time_Period) as a1
LEFT JOIN
(select 'VMS/Burts' AS AO_BU, 'Total' as AO_Segment, a.Week_End_Date, a.Time_Period, 'Clorox' as AO_Share_Component, 'All Category Total' as AO_level, sum(COALESCE(a.Sales,0)) as Sales
FROM (select * from #all_outlet_DG_mapped where AO_BU in ('Burt''s','VMS') and Vendor = 'Clorox' and Category not in  ('Air Care','Convenience Clean')) a
GROUP BY a.Week_end_date, a.Time_Period) as b1
ON a1.Week_end_date = b1.Week_end_date and
a1.Time_Period = b1.Time_Period


--HOMECARE CALCULATIONs(deleting and the creating its record by excluding Disinfecting Aerosol, Wet Floor from BU TOTAL 
--or including only 'Home Cleaning' Category for 'Home Care' BU total )
--------*****-------
DELETE FROM #all_outlet_DG_BU_aggregated where AO_BU = 'Home Care' and AO_Segment = 'Total'

INSERT INTO #all_outlet_DG_BU_aggregated(AO_BU, AO_Segment, Week_End_Date, Time_Period, AO_Share_Component, AO_level, Sales)
select AO_BU AS AO_BU, 'Total' AS AO_Segment, Week_End_Date, Time_Period, 'Category' as AO_Share_Component, 'BU Total' as AO_level, sum(Sales) as Sales
FROM ( select * from  #all_outlet_DG_mapped where Category = 'Home Cleaning') a
GROUP BY   Week_end_date, Time_Period, AO_BU

UNION

select a.AO_BU AS AO_BU, 'Total' AS AO_Segment, a.Week_End_Date, a.Time_Period, 'Clorox' as AO_Share_Component, 'BU Total' as AO_level, sum(COALESCE(a.Sales,0)) as Sales
FROM (select * from #all_outlet_DG_mapped where Category = 'Home Cleaning' and Vendor = 'Clorox') a
GROUP BY a.Week_end_date, a.Time_Period, a.AO_BU



--select * from #all_outlet_DG_BU_aggregated where AO_BU = 'Home Care' and AO_Segment = 'Total'



 IF OBJECT_ID('tempdb..#DG_sharetab') IS NOT NULL
BEGIN
DROP TABLE #DG_sharetab
END

CREATE TABLE #DG_sharetab
WITH
( DISTRIBUTION = ROUND_ROBIN
)
AS
  select [Source], Retailer, 
  case
  when ([Type] = 'Clx') then CONCAT(Product,[Type])
  when ([Type] = 'Cat') then Product
  end as BUName,
  [Type],
  Category,
  Product,
  [Dollar Sales],
  Time_Period,
  Week_end_date
  from
  (
SELECT 
	   case 
	   when ([AO_Share_Component] = 'Category') then 'Cat'
	   when ([AO_Share_Component] = 'Clorox') then 'Clx'
	   end as [Type]
	  ,'DG' as [Source]
      ,'DG' as [Retailer]
      ,[Time_Period]
      ,[Week_End_Date]
      ,[Sales] as [Dollar Sales]
	  ,case 
	  when (AO_Segment = 'Total' and AO_Level = 'BU Total') then AO_BU
	  when (AO_Level = 'Segment Total') then AO_Segment
	  when (AO_Level in ('All Category Total', 'Custom Total')) then AO_BU
	  when (AO_Segment <> 'Total' and AO_Level = 'BU Total') then AO_Segment
	  end as Product,
	  case 
	  when (AO_Segment = 'Total' and AO_Level = 'BU Total') then NULL
	  when (AO_Level = 'Segment Total') then AO_BU
	  when (AO_Level in ('All Category Total', 'Custom Total')) then NULL
	  when (AO_Segment <> 'Total' and AO_Level = 'BU Total') then AO_BU
	  end as Category
  FROM #all_outlet_DG_BU_aggregated
  ) a
  
delete from #DG_sharetab where [Type] = 'Cat' and Product in ('Fresh Step', 'Scoop Away')
--select * from #DG_sharetab

 
DELETE FROM [ebi].[ebi_all_outlet_DG_base] where [Week_end_date] in (select DISTINCT([Week_end_date]) from #DG_sharetab)
INSERT INTO [ebi].[ebi_all_outlet_DG_base]([Source],[Retailer], [BUName], [Type], [Category], [Product],[Dollar Sales],[Time_Period],  [Week_end_date] )
SELECT [Source], [Retailer], [BUName], [Type], [Category], [Product], [Dollar Sales],[Time_Period],  [Week_end_date] FROM #DG_sharetab


END


--select * from [ebi].[ebi_all_outlet_DG_base] order by 9,8,4,5,6

--select * from ebi.ebi_all_outlet_DG_map where AO_BU = 'Home Care'

--select sum(Sales) from ebi.ebi_DG_base where category = 'Home Cleaning' and month_end_date = '2021-12-26'


--select distinct category, Segment, Sub_segment, Vendor, Brand from ebi.ebi_DG_base where category = 'Home Cleaning' and month_end_date = '2021-12-26'


--select * from ebi.ebi_VMS_base
