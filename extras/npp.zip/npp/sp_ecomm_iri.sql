/****** Object:  StoredProcedure [ebi].[sp_ecomm_iri]    Script Date: 2/2/2023 9:10:11 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROC [ebi].[sp_ecomm_iri] AS
BEGIN

/*
DECLARE @Fiscal_Month INT, @Fiscal_YEAR INT, @month_end_date DATE
select @Fiscal_Month = Fiscal_Month, @Fiscal_YEAR = Fiscal_YEAR from (select TOP 1* from (select DISTINCT Fiscal_Month, Fiscal_YEAR from ebi.calendar_week_dim2 where calendar_month = MONTH(DATEADD(MM, DATEDIFF(MM, 0, GETDATE()) - 3, 0)) and calendar_year = YEAR(DATEADD(MM, DATEDIFF(MM, 0, GETDATE()) - 3, 0))) tbl) new_tbl


select @month_end_date = max(wk_end_dt) from [ebi].[cal_445_wk_dim_2] where fiscal_yr_cd = @Fiscal_YEAR and rank_val = @Fiscal_Month group by fiscal_yr_cd,rank_val
--select @month_end_date
*/

/*
DECLARE @Fiscal_Month INT, @Fiscal_YEAR INT, @month_end_date DATE, @month_end_date_YAGO DATE
select @month_end_date = max(Month_End_Date) from [ebi].[ebi_ecomm_iri_base]
select @Fiscal_YEAR = fiscal_yr_cd, @Fiscal_Month = rank_val from [ebi].[cal_445_wk_dim_2] where wk_end_dt = @month_end_date
select @month_end_date

select @month_end_date_YAGO = max(IRI_week_end_date) from ebi.calendar_week_dim2 where Fiscal_year = @Fiscal_YEAR - 1 and Fiscal_Month = @Fiscal_Month
--select @month_end_date_YAGO
*/



IF OBJECT_ID('tempdb..#ecomm_iri_retailer_except_MULOP_and_MULOPPlus') IS NOT NULL
BEGIN
DROP TABLE #ecomm_iri_retailer_except_MULOP_and_MULOPPlus
END

CREATE TABLE #ecomm_iri_retailer_except_MULOP_and_MULOPPlus
WITH
( 
DISTRIBUTION = ROUND_ROBIN
)
AS
select a.[Product] as [IRI_Products], b.[Ecomm_Products], a.[Geography], a.[Time_Period], a.[Month_End_Date], a.[Dollar_Sales], a.[Dollar_Sales_Year_AGO], b.BU, b.Segment, b.Share_Component
from (select * from [ebi].[ebi_ecomm_iri_base] where [Geography] not in ('MULOP', 'MULO + Pet Specialty + Pet Ecom') and [Month_End_Date] in (select distinct Week_End_Date from ebi.ebi_iri_RL_base_AO)) a
RIGHT JOIN (select * from [ebi].[ebi_ecomm_iri_product_BU_mapping] where Active_Flag = 'Y' and IRI_products is NOT NULL) b
ON TRIM(lower(a.Product)) = TRIM(lower(b.IRI_Products))


----------------------------------------------------------------------------------------------------

IF OBJECT_ID('tempdb..#ecomm_iri_retailer_MULOP_and_MULOPPlus') IS NOT NULL
BEGIN
DROP TABLE #ecomm_iri_retailer_MULOP_and_MULOPPlus
END

CREATE TABLE #ecomm_iri_retailer_MULOP_and_MULOPPlus
WITH
( 
DISTRIBUTION = ROUND_ROBIN
)
AS
--MULOP, MULO+P retailer,  VMS Probiotics segment total (VMS BU Total is not calculated; it is not required in Ecomm )
select a.[Product] as [IRI_Products], b.[Ecomm_Products], a.[Geography], a.[Time_Period], a.[Month_End_Date], a.[Dollar_Sales], a.[Dollar_Sales_Year_AGO], b.BU, b.Segment, b.Share_Component
from (select * from [ebi].[ebi_ecomm_iri_base] where [Geography] in ('MULOP', 'MULO + Pet Specialty + Pet Ecom') and [Month_End_Date] in (select distinct Week_End_Date from ebi.ebi_iri_RL_base_AO)) a
RIGHT JOIN (select * from [ebi].[ebi_ecomm_iri_product_BU_mapping] where Active_Flag = 'Y' and IRI_products is NOT NULL and BU not in ('VMS')) b
ON TRIM(lower(a.Product)) = TRIM(lower(b.IRI_Products))

UNION


--MULOP retailer,  VMS Probiotics segment total (VMS BU Total is not calculated; it is not required in Ecomm  )
select a.SPINS_Brand as [IRI_Products],  c.[Ecomm_Products] as [Ecomm_Products], a.Retailer as Geography,a.Time_Period, a.Week_End_Date as Month_End_Date, a.[Dollar_Sales], a.[Dollar_Sales_Year_Ago], b.AO_BU as [BU], b.AO_Segment as [Segment], b.[AO_Share_Component] as [Share_Component]  from (select * from ebi.ebi_iri_RL_base_AO where Retailer in ('MULOP') and Week_End_Date in (select distinct Month_End_Date from ebi.ebi_ecomm_iri_base) and Time_Period in ('Last 52 weeks'
,'Last 13 weeks')) a
RIGHT JOIN
(
select Product, SPINS_Brand, AO_BU, AO_Segment, case when [AO_Share Component] = 'Clorox' then 'Clx'
when [AO_Share Component] = 'Category' then 'Cat' 
end as [AO_Share_Component] from ebi.ebi_all_outlet_iri_RL_product_mapping where AO_Segment not in ('Total')
) b
ON a.Product = b.Product
and a.SPINS_Brand = b.SPINS_Brand
INNER JOIN
(select * from [ebi].[ebi_ecomm_iri_product_BU_mapping] where Active_Flag = 'Y' and IRI_products is NOT NULL and BU in ('VMS')) c
ON b.AO_BU = c.[BU]
and b.AO_Segment = c.[Segment]
and b.[AO_Share_Component] = c.[Share_Component]


UNION


--MULO+P retailer, only VMS Probiotics segment total(VMS BU Total is not calculated; it is not required in Ecomm  )
select a.SPINS_Brand as [IRI_Products],  c.[Ecomm_Products] as [Ecomm_Products], 'MULO + Pet Specialty + Pet Ecom' as Geography,a.Time_Period, a.Week_End_Date as Month_End_Date, a.[Dollar_Sales], a.[Dollar_Sales_Year_Ago], b.AO_BU as [BU], b.AO_Segment as [Segment], b.[AO_Share_Component] as [Share_Component]  from (select * from ebi.ebi_iri_RL_base_AO where Retailer in ('MULOP') and Week_End_Date in (select distinct Month_End_Date from ebi.ebi_ecomm_iri_base) and Time_Period in ('Last 52 weeks'
,'Last 13 weeks')) a
RIGHT JOIN
(
select Product, SPINS_Brand, AO_BU, AO_Segment, case when [AO_Share Component] = 'Clorox' then 'Clx'
when [AO_Share Component] = 'Category' then 'Cat' 
end as [AO_Share_Component] from ebi.ebi_all_outlet_iri_RL_product_mapping where AO_Segment not in ('Total')
) b
ON a.Product = b.Product
and a.SPINS_Brand = b.SPINS_Brand
INNER JOIN
(select * from [ebi].[ebi_ecomm_iri_product_BU_mapping] where Active_Flag = 'Y' and IRI_products is NOT NULL and BU in ('VMS')) c
ON b.AO_BU = c.[BU]
and b.AO_Segment = c.[Segment]
and b.[AO_Share_Component] = c.[Share_Component]

------------------------------------------------------


IF OBJECT_ID('tempdb..#ecomm_iri_products') IS NOT NULL
BEGIN
DROP TABLE #ecomm_iri_products
END

CREATE TABLE #ecomm_iri_products
WITH
( 
DISTRIBUTION = ROUND_ROBIN
)
AS

select * from #ecomm_iri_retailer_MULOP_and_MULOPPlus

UNION

select * from #ecomm_iri_retailer_except_MULOP_and_MULOPPlus


--select * from #ecomm_iri_products order by 5,4,3,8,9,10

--------------------------------------------------------------------------------------------

IF OBJECT_ID('tempdb..#ecomm_iri_products_with_total_clorox') IS NOT NULL
BEGIN
DROP TABLE #ecomm_iri_products_with_total_clorox
END

CREATE TABLE #ecomm_iri_products_with_total_clorox
WITH
( 
DISTRIBUTION = ROUND_ROBIN
)
AS
select * from #ecomm_iri_products

UNION

select b.IRI_Products, b.Ecomm_Products, a.[Geography], a.Time_Period, a.Month_End_Date, a.[Dollar_Sales], a.[Dollar_Sales_Year_AGO], a.[BU], a.[Segment],a.[Share_Component] from
(select  Geography, Time_Period, Month_End_Date, SUM([Dollar_Sales]) as [Dollar_Sales], SUM([Dollar_Sales_Year_AGO]) as [Dollar_Sales_Year_AGO], 'Total' as [BU], 'Total' as [Segment], Share_Component from #ecomm_iri_products where BU in ('Total excl VMS/Burts', 'VMS', 'Burt''s') and Segment in ('Probiotics', 'Total')  group by Month_End_Date, Time_Period, Geography, Share_Component) a
LEFT JOIN (select * from [ebi].[ebi_ecomm_iri_product_BU_mapping] where Active_Flag = 'Y' and IRI_products is NULL) b
ON a.BU = b.BU
and a.Segment = b.Segment
and a.Share_Component = b.Share_Component


select * from #ecomm_iri_products_with_total_clorox
---------------------------------------------------------------

DELETE FROM [ebi].[ebi_ecomm_iri_processed] where Month_End_Date in (select DISTINCT(Month_End_Date) from #ecomm_iri_products_with_total_clorox)
INSERT INTO [ebi].[ebi_ecomm_iri_processed]([IRI_Products],[Ecomm_Products], [Geography], [Time_Period], [Month_End_Date], [Dollar_Sales], [Dollar_Sales_Year_AGO], [BU], [Segment], [Share_Component])
SELECT [IRI_Products], [Ecomm_products], [Geography], [Time_Period], [Month_End_Date], [Dollar_Sales], [Dollar_Sales_Year_AGO], [BU], [Segment], [Share_Component] FROM #ecomm_iri_products_with_total_clorox



END
GO


