/****** Object:  StoredProcedure [ebi].[sp_iri_renew_life_base_AO]    Script Date: 2/1/2023 11:17:40 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROC [ebi].[sp_iri_renew_life_base_AO] AS


begin

delete from [ebi].[ebi_iri_RL_stg_AO] where week_end_date > CONVERT(date, GETDATE())


/*deleting records based on DISTINCT Week_end_date and Time_Period combination from base table and reloading*/
IF OBJECT_ID('tempdb..#distinct_week_end_date_timeperiod_tobe_deleted') IS NOT NULL
BEGIN
DROP TABLE #distinct_week_end_date_timeperiod_tobe_deleted
END

CREATE TABLE #distinct_week_end_date_timeperiod_tobe_deleted
WITH
( DISTRIBUTION = ROUND_ROBIN
)
AS
select a.Week_end_date, a.Time_period from
(select distinct [Week_end_date], [Time_period] from [ebi].[ebi_iri_RL_stg_AO]) a

select * from #distinct_week_end_date_timeperiod_tobe_deleted order by week_end_date

delete a from [ebi].[ebi_iri_RL_base_AO] a
inner join #distinct_week_end_date_timeperiod_tobe_deleted b on a.Week_end_date = b.Week_end_date
and a.Time_period = b.Time_period

drop table #distinct_week_end_date_timeperiod_tobe_deleted
 
insert into [ebi].[ebi_iri_RL_base_AO] ([Product], [Time], [Geography], [Retailer], [SPINS_Brand], [Time_Period], [Week_end_date], [Dollar_Sales], [Dollar_Sales_Year_Ago], [Dollar_Sales_2_Years_Ago], [Dollar_Sales_3_Years_Ago], [Dollar_Sales_%_Change_vs_YA], [Dollar_Sales_%_Change_vs_2_YA], [Modified_time]) 
select [Product], [Time], [Geography], [Retailer], [SPINS_Brand], [Time_Period], [Week_end_date], TRY_CONVERT(decimal(18,2),[Dollar_Sales]) as [Dollar_Sales], TRY_CONVERT(decimal(18,2),[Dollar_Sales_Year_Ago]) as [Dollar_Sales_Year_Ago], TRY_CONVERT(decimal(18,2),[Dollar_Sales_2_Years_Ago]) as [Dollar_Sales_2_Years_Ago], TRY_CONVERT(decimal(18,2),[Dollar_Sales_3_Years_Ago]) as [Dollar_Sales_3_Years_Ago], TRY_CONVERT(decimal(18,2),[Dollar_Sales_%_Change_vs_YA]) as [Dollar_Sales_%_Change_vs_YA],TRY_CONVERT(decimal(18,2),[Dollar_Sales_%_Change_vs_2_YA]) as [Dollar_Sales_%_Change_vs_2_YA],GETDATE()
 from  [ebi].[ebi_iri_RL_stg_AO]


END;


--select * from [ebi].[ebi_all_outlet_iri_output_stg]

--select * from ebi.calendar_week_dim
--select * from [ebi].[ebi_all_outlet_iri_output_base]


GO


