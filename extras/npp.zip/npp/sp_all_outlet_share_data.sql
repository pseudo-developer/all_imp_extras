/****** Object:  StoredProcedure [ebi].[sp_all_outlet_share_data]    Script Date: 2/14/2023 12:24:34 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROC [ebi].[sp_all_outlet_share_data] @iri_week_end_date [nvarchar](200),@Fiscal_Month [INT],@Fiscal_YEAR [INT] AS 
BEGIN

declare @Yago_IRI_Week_End_Date varchar(30)
declare @Curr_IRI_Week_End_Date varchar(30)
SET @Yago_IRI_Week_End_Date=(select iri_week_end_date from [ebi].[calendar_week_dim] where weekid =(
select weekid-100 from [ebi].[calendar_week_dim] where iri_week_end_date = (select max([Week_end_date]) from ebi.ebi_all_outlet_iri_base)))
SET @Curr_IRI_Week_End_Date=(select max([Week_end_date]) from ebi.ebi_all_outlet_iri_base)


IF OBJECT_ID('tempdb..#all_outlet_all_sources_data') IS NOT NULL
BEGIN
DROP TABLE #all_outlet_all_sources_data
END

CREATE TABLE #all_outlet_all_sources_data
WITH
( 
DISTRIBUTION = ROUND_ROBIN
)
AS
select [Source], [Retailer], [BUName], [Type], [Category], [Product], [Dollar Sales], [Time_Period], [Week_end_date] from ebi.ebi_all_outlet_stackline_base
UNION
select 
[Source], [Retailer], [BUName], [Type], [Category], [Product], [Dollar Sales], [Time_Period], [Week_end_date] from ebi.ebi_all_outlet_iri_base where [Week_end_date]!= @Yago_IRI_Week_End_Date
UNION
select  
[Source], [Retailer], [BUName], [Type], [Category], [Product],Dollar_Sales_Year_Ago [Dollar Sales], [Time_Period],@Yago_IRI_Week_End_Date [Week_end_date] 
from ebi.ebi_all_outlet_iri_base
where [Week_end_date]= @Curr_IRI_Week_End_Date
UNION
select [Source], [Retailer], [BUName], [Type], [Category], [Product], [Dollar Sales], [Time_Period], [Week_end_date] from ebi.ebi_all_outlet_VMS_base
UNION
select [Source], [Retailer], [BUName], [Type], [Category], [Product], [Dollar Sales], [Time_Period], [Week_end_date] from ebi.ebi_all_outlet_chewy_base
UNION
select [Source], [Retailer], [BUName], [Type], [Category], [Product], [Dollar Sales], [Time_Period], [Week_end_date] from ebi.ebi_all_outlet_DG_base
UNION
select [Source], [Retailer], [BUName], [Type], [Category], [Product], [Dollar Sales], [Time_Period], [Week_end_date] from ebi.ebi_all_outlet_HD_base
UNION
select [Source], [Retailer], [BUName], [Type], [Category], [Product], [Dollar Sales], [Time_Period], [Week_end_date] from ebi.ebi_all_outlet_lowes_base
UNION
select [Source], [Retailer], [BUName], [Type], [Category], [Product], [Dollar Sales], [Time_Period], [Week_end_date] from ebi.ebi_all_outlet_costco_base

----------------------------


--select * from  #all_outlet_all_sources_data order by 1,2,8,4,5,6



IF OBJECT_ID('tempdb..#all_outlet_all_sources_data_with_missing_products') IS NOT NULL
BEGIN
DROP TABLE #all_outlet_all_sources_data_with_missing_products
END

CREATE TABLE #all_outlet_all_sources_data_with_missing_products
WITH
( 
DISTRIBUTION = ROUND_ROBIN
)
AS
select a1.[Source],a1.[Retailer], a1.AO_BUName as BUName, a1.[Type], a1.AO_Category as Category, a1.AO_Product as Product, a1.Time_Period, a1.Week_end_date, COALESCE(b1.[Dollar Sales],0) as [Dollar Sales], b1.[Source] as b_source, b1.BUName as b_BUName  from
(
select [Source],[Retailer], AO_BUName ,[Type], AO_Category, AO_Product, Time_Period, Week_end_date
FROM (select DISTINCT [Source], [Retailer] from #all_outlet_all_sources_data) a
CROSS JOIN 
(select [Type], AO_Category, AO_Product, case
  when ([Type] = 'Clx') then CONCAT(AO_Product,[Type])
  when ([Type] = 'Cat') then AO_Product
  end as AO_BUName from 
		(select DISTINCT([Type]) from #all_outlet_all_sources_data) x
		CROSS JOIN
		(select AO_Category, AO_Product from [ebi].[ebi_all_outlet_product_map]) y)c
CROSS JOIN (select DISTINCT(Time_Period) from #all_outlet_all_sources_data) d
CROSS JOIN (select DISTINCT(Week_end_date) from #all_outlet_all_sources_data) e
) a1
LEFT JOIN
(select * from #all_outlet_all_sources_data) b1
ON 
lower(TRIM(a1.[Source])) = lower(TRIM(b1.[Source])) and
lower(TRIM(a1.Retailer)) = lower(TRIM(b1.Retailer)) and
lower(TRIM(a1.AO_BUName)) = lower(TRIM(b1.BUName)) and
lower(TRIM(a1.[Type])) = lower(TRIM(b1.[Type])) and
ISNULL(a1.AO_Category,'`') = ISNULL(b1.Category,'`') and
lower(TRIM(a1.AO_Product)) = lower(TRIM(b1.Product)) and
lower((a1.Time_Period)) = lower(TRIM(b1.Time_Period)) and
a1.Week_end_date = b1.Week_end_date



IF OBJECT_ID('tempdb..#all_outlet_all_sources_data_LER_Tracked_mapping') IS NOT NULL
BEGIN
DROP TABLE #all_outlet_all_sources_data_LER_Tracked_mapping
END

CREATE TABLE #all_outlet_all_sources_data_LER_Tracked_mapping
WITH
( 
DISTRIBUTION = ROUND_ROBIN
)
AS
select b.[LER vs Non], b.[Tracked vs Non],a.[Source], a.[Retailer], a.[BUName], a.[Type], a.[Category], a.[Product], a.[Dollar Sales], a.[Time_Period], a.[Week_end_date] 
from #all_outlet_all_sources_data_with_missing_products a
INNER JOIN
ebi.ebi_all_outlet_LER_tracked_map b
ON a.[Source] = b.[Source] and
a.Retailer = b.Retailer


--------------NonLERMULO:  MULO+P - (IRI LER(walmart, kroger, Target,Sams))----------------
INSERT INTO #all_outlet_all_sources_data_LER_Tracked_mapping([LER vs Non], [Tracked vs Non], [Source], [Retailer], [BUName], [Type], [Category], [Product], [Dollar Sales], [Time_Period], [Week_end_date] )
select 'NonLER' as [LER vs Non], 'Tracked' as [Tracked vs Non], a.[Source], 'NonLERMULO' as Retailer, a.BUName, a.[Type], a.Category, a.Product , (COALESCE(a.[Dollar Sales], 0) - COALESCE(b.[Dollar Sales], 0)) as [Dollar Sales], a.Time_Period, a.Week_end_date
from
(select * from #all_outlet_all_sources_data_with_missing_products where Retailer = 'MULO+P' and [Source] = 'IRI') a
INNER JOIN
(select 'IRI' as [Source], 'LERMULO' as Retailer ,BUName,[Type], Category, Product, Time_Period, Week_end_date, SUM(COALESCE([Dollar Sales], 0)) as [Dollar Sales] from #all_outlet_all_sources_data_LER_Tracked_mapping where [LER vs Non] = 'LER' and [Source] = 'IRI'
group by BUName,[Type], Category, Product, Time_Period, Week_end_date ) b
ON 
lower(TRIM(a.[Source])) = lower(TRIM(b.[Source])) and
lower(TRIM(a.BUName)) = lower(TRIM(b.BUName)) and
lower(TRIM(a.[Type])) = lower(TRIM(b.[Type])) and
ISNULL(a.Category,'`') = ISNULL(b.Category,'`') and
lower(TRIM(a.Product)) = lower(TRIM(b.Product)) and
lower((a.Time_Period)) = lower(TRIM(b.Time_Period)) and
a.Week_end_date = b.Week_end_date

-----------------------------------------------------

IF OBJECT_ID('tempdb..#final_share_data') IS NOT NULL
BEGIN
DROP TABLE #final_share_data
END

CREATE TABLE #final_share_data
WITH
( 
DISTRIBUTION = ROUND_ROBIN
)
AS
select [LER vs Non], [Tracked vs Non], [Source], Retailer ,BUName, [Type], Category, Product, [Dollar Sales], Time_Period, Week_end_date from #all_outlet_all_sources_data_LER_Tracked_mapping

UNION

select NULL as [LER vs Non], NULL as [Tracked vs Non], NULL as [Source], 'LER' as Retailer ,BUName,[Type], Category, Product, SUM(COALESCE([Dollar Sales], 0)) as [Dollar Sales], Time_Period, Week_end_date from #all_outlet_all_sources_data_LER_Tracked_mapping where [LER vs Non] = 'LER'
group by BUName,[Type], Category, Product, Time_Period, Week_end_date

UNION


select NULL as [LER vs Non], NULL as [Tracked vs Non], NULL as [Source], 'NonLER' as Retailer ,BUName,[Type], Category, Product, SUM(COALESCE([Dollar Sales], 0)) as [Dollar Sales], Time_Period, Week_end_date from #all_outlet_all_sources_data_LER_Tracked_mapping where [LER vs Non] = 'NonLER' and ([Source] <> 'IRI' or Retailer = 'NonLERMULO')  --CHANGED "ADDED [Source] = 'DG'"
group by BUName,[Type], Category, Product, Time_Period, Week_end_date 

[LER vs Non] in ('LER','NonLER') and ([Source] <> 'IRI' or Retailer = 'NonLERMULO') and [Source]='DG'

UNION

select NULL as [LER vs Non], NULL as [Tracked vs Non], NULL as [Source], 'Tracked' as Retailer ,BUName,[Type], Category, Product, SUM(COALESCE([Dollar Sales], 0)) as [Dollar Sales], Time_Period, Week_end_date from #all_outlet_all_sources_data_LER_Tracked_mapping where [Tracked vs Non] = 'Tracked' and Retailer in ('NonLERMULO', 'Walmart', 'Target', 'Kroger','Sams')
group by BUName,[Type], Category, Product, Time_Period, Week_end_date 

UNION

select NULL as [LER vs Non], NULL as [Tracked vs Non], NULL as [Source], 'Untracked' as Retailer ,BUName,[Type], Category, Product, SUM(COALESCE([Dollar Sales], 0)) as [Dollar Sales], Time_Period, Week_end_date from #all_outlet_all_sources_data_LER_Tracked_mapping where [Tracked vs Non] = 'Untracked'
group by BUName,[Type], Category, Product, Time_Period, Week_end_date 

UNION

select NULL as [LER vs Non], NULL as [Tracked vs Non], NULL as [Source], 'Total' as Retailer ,BUName,[Type], Category, Product, SUM(COALESCE([Dollar Sales], 0)) as [Dollar Sales], Time_Period, Week_end_date from #all_outlet_all_sources_data_LER_Tracked_mapping where ([LER vs Non] <> 'NonLER' or [Source] <> 'IRI' or Retailer = 'NonLERMULO') --and Retailer <> 'DG'    --CHANGED "REMOVED Retailer <> 'DG'"
group by BUName,[Type], Category, Product, Time_Period, Week_end_date 


--select * from #final_share_data



DELETE FROM [ebi].[ebi_all_outlet_sharedata] where [Week_end_date] in (select DISTINCT([Week_end_date]) from #final_share_data)
INSERT INTO [ebi].[ebi_all_outlet_sharedata]([LER vs Non], [Tracked vs Non],[Source],[Retailer], [BUName], [Type], [Category], [Product],[Consumption],[Time_Period],  [Week_end_date], [Fiscal_Month] ,[Fiscal_Year], [Fiscal_qtr], [Data_Type])
SELECT a.[LER vs Non], a.[Tracked vs Non], a.[Source], a.[Retailer], a.[BUName], a.[Type], a.[Category], a.[Product], COALESCE(a.[Dollar Sales],0)/1000000 as [Consumption], a.[Time_Period], a.[Week_end_date] ,   b.[Fiscal_Month], b.[Fiscal_Year], b.[Fiscal_qtr],
case when (a.[Type] = 'Clx' and a.Category is null and a.Product not in ('Total','Total excl VMS/Burts')) then 'Clorox BU Topline' 
 when (a.[Type] = 'Clx' and a.Category is null and a.Product in ('Total')) then  'Clorox Total Topline'
 when (a.[Type] = 'Clx' and a.Category is null and a.Product in ('Total excl VMS/Burts')) then 'Clorox Total Topline ex VMS/Burts'
 when (a.[Type] = 'Clx' and a.Category is not null) then 'Clorox Sub-Category Topline'
 when (a.[Type] = 'Cat' and a.Category is null and a.Product not in ('Total','Total excl VMS/Burts')) then 'Category Total'
 when (a.[Type] = 'Cat' and a.Category is null and a.Product in ('Total')) then  'All-Category Total'
 when (a.[Type] = 'Cat' and a.Category is null and a.Product in ('Total excl VMS/Burts')) then 'All-Category Total ex VMS/Burts'
 when (a.[Type] = 'Cat' and a.Category is not null) then 'Sub-category total' end as Data_Type FROM #final_share_data a
 LEFT JOIN 
 (select fiscal_yr_cd as [Fiscal_Year], rank_Val as [Fiscal_Month], max(wk_end_dt) as Week_End_Date,
case when rank_Val in (1,2,3) then 'Q1'
when rank_Val in (4,5,6) then 'Q2'
when rank_Val in (7,8,9) then 'Q3'
when rank_Val in (10,11,12) then 'Q4'
end as [Fiscal_qtr]
from [ebi].[cal_445_wk_dim_2] group by fiscal_yr_cd, rank_Val
) b
ON a.Week_End_Date = b.[Week_End_Date]

where a.Week_End_Date >= '2018-07-29'



update ebi.ebi_all_outlet_sharedata
set Time_period = 'Last 4-5 weeks'
where Time_period = 'Last 4-5 week'

update ebi.ebi_all_outlet_sharedata
set BUName = 'Scoop Away'
where [Type] = 'Clx' and Product = 'Scoop Away'


update ebi.ebi_all_outlet_sharedata
set BUName = 'Fresh Step'
where [Type] = 'Clx' and Product = 'Fresh Step'



END



GO


DELETE from ebi.ebi_all_outlet_stackline_base where [Week_end_date] in ('2023-03-26','2022-03-27')
DELETE from ebi.ebi_all_outlet_iri_base where [Week_end_date] in ('2023-03-26','2022-03-27')
DELETE from ebi.ebi_all_outlet_VMS_base where [Week_end_date] in ('2023-03-26','2022-03-27')
DELETE from ebi.ebi_all_outlet_chewy_base where [Week_end_date] in ('2023-03-26','2022-03-27')
DELETE from ebi.ebi_all_outlet_DG_base where [Week_end_date] in ('2023-03-26','2022-03-27')
DELETE from ebi.ebi_all_outlet_HD_base where [Week_end_date] in ('2023-03-26','2022-03-27')
DELETE from ebi.ebi_all_outlet_lowes_base where [Week_end_date] in ('2023-03-26','2022-03-27')
DELETE from ebi.ebi_all_outlet_costco_base where [Week_end_date] in ('2023-03-26','2022-03-27')


select count(*) from ebi.ebi_costco_base
select count(*) from ebi.ebi_all_outlet_costco_map
select count(*) from ebi.ebi_VMS_base
select count(*) from ebi.ebi_all_outlet_VMS_map
select count(*) from ebi.ebi_HD_base
select count(*) from ebi.ebi_all_outlet_HD_map
select count(*) from ebi.ebi_DG_base
select count(*) from ebi.ebi_all_outlet_DG_map
select count(*) from ebi.ebi_lowes_base
select count(*) from ebi.ebi_all_outlet_lowes_map