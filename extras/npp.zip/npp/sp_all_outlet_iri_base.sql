/****** Object:  StoredProcedure [ebi].[sp_all_outlet_iri_base]    Script Date: 1/17/2023 8:37:34 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROC [ebi].[sp_all_outlet_iri_base] @iri_week_end_date [nvarchar](200),@Fiscal_Month [INT],@Fiscal_YEAR [INT] AS 
BEGIN


/*
DECLARE @iri_week_end_date [DATE]
select @iri_week_end_date = '2021-12-26'
*/



IF OBJECT_ID('tempdb..#all_outlet_iri_retailer_except_MULOP_and_MULOPPlus') IS NOT NULL
BEGIN
DROP TABLE #all_outlet_iri_retailer_except_MULOP_and_MULOPPlus
END

CREATE TABLE #all_outlet_iri_retailer_except_MULOP_and_MULOPPlus
WITH
( 
DISTRIBUTION = ROUND_ROBIN
)
AS
--all retailers except MULOP, MULO+P; does not contain VMS BU total (contains VMS Probiotics Segment total)
select a.Product, a.Retailer,a.Week_End_Date,a.Time_Period, b.AO_BU, b.AO_Segment, b.AO_Level, b.[AO_Share Component], a.[Dollar_sales], a.[Dollar_Sales_Year_Ago], a.[Dollar_Sales_2_Years_Ago], a.[Dollar_sales_3_Years_Ago]  from ( select * from ebi.ebi_iri_base_AO where Retailer not in ('MULOP', 'MULO+P') and Week_End_Date in (select distinct Week_End_Date from ebi.ebi_iri_RL_base_AO)) a
RIGHT JOIN
(select * from ebi.ebi_all_outlet_iri_product_mapping where Active_Flag = 'Y') b
ON a.Product = b.AO_Product






IF OBJECT_ID('tempdb..#all_outlet_iri_retailer_except_MULOP_and_MULOPPlus_with_VMS_BU_Total') IS NOT NULL
BEGIN
DROP TABLE #all_outlet_iri_retailer_except_MULOP_and_MULOPPlus_with_VMS_BU_Total
END

CREATE TABLE #all_outlet_iri_retailer_except_MULOP_and_MULOPPlus_with_VMS_BU_Total
WITH
( 
DISTRIBUTION = ROUND_ROBIN
)
AS
select * from #all_outlet_iri_retailer_except_MULOP_and_MULOPPlus

UNION

select Product, Retailer, Week_End_Date, Time_Period, AO_BU, 'Total' as AO_Segment, 'BU Total' as AO_Level, [AO_Share Component], [Dollar_sales], [Dollar_Sales_Year_Ago], [Dollar_Sales_2_Years_Ago], [Dollar_sales_3_Years_Ago] from #all_outlet_iri_retailer_except_MULOP_and_MULOPPlus where AO_BU = 'VMS'

------------------------------------*********-----------------------------------
IF OBJECT_ID('tempdb..#all_outlet_iri_retailer_MULOP_and_MULOPPlus') IS NOT NULL
BEGIN
DROP TABLE #all_outlet_iri_retailer_MULOP_and_MULOPPlus
END

CREATE TABLE #all_outlet_iri_retailer_MULOP_and_MULOPPlus
WITH
( 
DISTRIBUTION = ROUND_ROBIN
)
AS
--MULOP, MULO+P retailer, does not contain VMS BU total and VMS Probiotics segment total
select a.Product, a.Retailer, a.Week_End_Date,a.Time_Period, b.AO_BU, b.AO_Segment, b.AO_Level, b.[AO_Share Component], a.[Dollar_sales], a.[Dollar_Sales_Year_Ago], a.[Dollar_Sales_2_Years_Ago], a.[Dollar_sales_3_Years_Ago] from ( select * from ebi.ebi_iri_base_AO where Retailer in ('MULOP', 'MULO+P') and Week_End_Date in (select distinct Week_End_Date from ebi.ebi_iri_RL_base_AO)) a
RIGHT JOIN
(select * from ebi.ebi_all_outlet_iri_product_mapping where Active_Flag = 'Y' and AO_BU not in ('VMS')) b
ON a.Product = b.AO_Product

UNION
--MULOP retailer, only VMS BU Total and VMS Probiotics segment total
select a.SPINS_Brand as [Product], a.Retailer,a.Week_End_Date, a.Time_Period, b.AO_BU, b.AO_Segment, b.AO_Level, b.[AO_Share Component], a.[Dollar_sales], a.[Dollar_Sales_Year_Ago], a.[Dollar_Sales_2_Years_Ago], a.[Dollar_sales_3_Years_Ago] from ( select * from ebi.ebi_iri_RL_base_AO where Retailer in ('MULOP') and Week_End_Date in (select distinct Week_End_Date from ebi.ebi_iri_base_AO)) a
RIGHT JOIN
(select * from ebi.ebi_all_outlet_iri_RL_product_mapping) b
ON a.Product = b.Product
and a.SPINS_Brand = b.SPINS_Brand

UNION
--MULO+P retailer, only VMS BU Total and VMS Probiotics segment total
select a.SPINS_Brand as [Product], 'MULO+P' as Retailer,a.Week_End_Date,a.Time_Period, b.AO_BU, b.AO_Segment, b.AO_Level, b.[AO_Share Component], a.[Dollar_sales], a.[Dollar_Sales_Year_Ago], a.[Dollar_Sales_2_Years_Ago], a.[Dollar_sales_3_Years_Ago] from ( select * from ebi.ebi_iri_RL_base_AO where Retailer in ('MULOP') and Week_End_Date in (select distinct Week_End_Date from ebi.ebi_iri_base_AO)) a
RIGHT JOIN
(select * from ebi.ebi_all_outlet_iri_RL_product_mapping) b
ON a.Product = b.Product
and a.SPINS_Brand = b.SPINS_Brand



/**
default.ebi_ebi_iri_base_ao
default.ebi_ebi_all_outlet_iri_rl_product_mapping
default.ebi_ebi_iri_rl_base_ao
default.ebi_ebi_all_outlet_iri_product_mapping
**/

-----------------------------**************---------------------------------------

IF OBJECT_ID('tempdb..#all_outlet_iri_products') IS NOT NULL
BEGIN
DROP TABLE #all_outlet_iri_products
END

CREATE TABLE #all_outlet_iri_products
WITH
( 
DISTRIBUTION = ROUND_ROBIN
)
AS

select * from #all_outlet_iri_retailer_MULOP_and_MULOPPlus

UNION

select * from #all_outlet_iri_retailer_except_MULOP_and_MULOPPlus_with_VMS_BU_Total

----------------------------------------------------------------------------

IF OBJECT_ID('tempdb..#all_outlet_iri_products_with_total_clorox') IS NOT NULL
BEGIN
DROP TABLE #all_outlet_iri_products_with_total_clorox
END

CREATE TABLE #all_outlet_iri_products_with_total_clorox
WITH
( 
DISTRIBUTION = ROUND_ROBIN
)
AS
select * from #all_outlet_iri_products

UNION

select 'Total excl VMS/Burts + VMS + Burt''s' as Product ,Retailer, Week_End_Date, Time_Period, 'Total' as AO_BU, 'Total' as AO_Segment, 'All Category Total' as AO_Level, [AO_Share Component], SUM(Dollar_Sales), SUM(Dollar_Sales_Year_Ago), SUM(Dollar_Sales_2_Years_Ago) , SUM(Dollar_Sales_3_Years_Ago) from #all_outlet_iri_products where AO_BU in ('Total excl VMS/Burts', 'VMS', 'Burt''s') and AO_Segment = 'Total' group by Retailer, Week_End_Date, Time_Period, [AO_Share Component] 



/*
select * from (
select Retailer, Week_end_date, Time_Period, count(*) as c from #all_outlet_iri_products where AO_BU in ('VMS') and AO_Segment = 'Total' group by Retailer, Week_end_date, Time_Period 
) x 
--where  c not in (2) 
order by Week_End_date

*/

------------------------------------

 IF OBJECT_ID('tempdb..#iri_sharetab') IS NOT NULL
BEGIN
DROP TABLE #iri_sharetab
END

CREATE TABLE #iri_sharetab
WITH
( DISTRIBUTION = ROUND_ROBIN
)
AS
  select [Product_IRI],[Source], Retailer, 
  case
  when ([Type] = 'Clx') then CONCAT(Product,[Type])
  when ([Type] = 'Cat') then Product
  end as BUName,
  [Type],
  Category,
  Product,
  [Dollar Sales],
  [Dollar_Sales_Year_Ago],
  [Dollar_Sales_2_Years_Ago],
  [Dollar_Sales_3_Years_Ago],
  Time_Period,
  Week_end_date
  from
  (
SELECT Product as [Product_IRI],
	   case 
	   when ([AO_Share Component] = 'Category') then 'Cat'
	   when ([AO_Share Component] = 'Clorox') then 'Clx'
	   end as [Type]
      ,'IRI' as [Source],
	  [Retailer]
      ,[Time_Period]
      ,[Week_End_Date]
      ,[Dollar_Sales] as [Dollar Sales]
	  ,[Dollar_Sales_Year_Ago]
	  ,[Dollar_Sales_2_Years_Ago]
	  ,[Dollar_Sales_3_Years_Ago]
	  ,case 
	  when (AO_Segment = 'Total' and AO_Level = 'BU Total') then AO_BU
	  when (AO_Level = 'Segment Total') then AO_Segment
	  when (AO_Level in ('All Category Total', 'Custom Total')) then AO_BU
	  when (AO_Segment <> 'Total' and AO_Level = 'BU Total') then AO_Segment
	  end as Product,
	  case 
	  when (AO_Segment = 'Total' and AO_Level = 'BU Total') then NULL
	  when (AO_Level = 'Segment Total') then AO_BU
	  when (AO_Level in ('All Category Total', 'Custom Total')) then NULL
	  when (AO_Segment <> 'Total' and AO_Level = 'BU Total') then AO_BU
	  end as Category
  FROM #all_outlet_iri_products_with_total_clorox
  ) a

--select * from  #iri_sharetab where Product in ('Total')

DELETE FROM [ebi].[ebi_all_outlet_iri_base] where [Week_end_date] in (select DISTINCT([Week_end_date]) from #iri_sharetab)
INSERT INTO [ebi].[ebi_all_outlet_iri_base]([Product_IRI], [Source], [Retailer], [BUName], [Type], [Category], [Product], [Dollar Sales], [Dollar_Sales_Year_Ago], [Dollar_Sales_2_Years_Ago], [Dollar_Sales_3_Years_Ago], [Time_Period], [Week_end_date])
SELECT [Product_IRI], [Source], [Retailer], [BUName], [Type], [Category], [Product], [Dollar Sales], [Dollar_Sales_Year_Ago], [Dollar_Sales_2_Years_Ago], [Dollar_Sales_3_Years_Ago], [Time_Period], [Week_end_date] FROM #iri_sharetab


END

select count(*) from [ebi].[ebi_all_outlet_iri_base] where Week_End_Date in ('2018-07-01','2018-07-29','2018-08-26','2018-09-30','2018-10-28','2018-11-25','2018-12-30','2019-01-27','2019-02-24','2019-03-31','2019-04-28','2019-05-26','2019-06-30','2019-07-28','2019-08-25','2019-09-29','2019-10-27','2019-11-24','2019-12-29','2020-01-26','2020-02-23','2020-03-29','2020-04-26','2020-05-24','2020-06-28','2020-07-26','2020-08-23','2020-09-27','2020-10-25','2020-11-22','2020-12-27','2021-01-24','2021-02-21','2021-03-28','2021-04-25','2021-05-23','2021-06-27','2021-07-25','2021-08-22','2021-09-26','2021-10-24','2021-11-21','2021-12-26','2022-01-23','2022-02-20','2022-03-27','2022-04-24','2022-05-22','2022-06-26','2022-07-24','2022-08-21','2022-09-25','2022-10-23','2022-11-20','2022-12-25','2023-01-22','2023-02-19','2023-03-26')

GO


