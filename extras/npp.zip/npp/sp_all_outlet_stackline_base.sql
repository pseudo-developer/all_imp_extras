/****** Object:  StoredProcedure [ebi].[sp_all_outlet_stackline_base]    Script Date: 1/23/2023 10:38:46 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON

GO

CREATE PROC [ebi].[sp_all_outlet_stackline_base] @iri_week_end_date [nvarchar](200),@Fiscal_Month [INT],@Fiscal_YEAR [INT] AS 
BEGIN

select @iri_week_end_date = cast(@iri_week_end_date as Date)

/*
DECLARE @Fiscal_Month INT, @Fiscal_YEAR INT, @iri_week_end_date date
select @Fiscal_Month = Fiscal_Month, @Fiscal_YEAR = Fiscal_YEAR from (select TOP 1* from (select DISTINCT Fiscal_Month, Fiscal_YEAR from ebi.calendar_week_dim2 where calendar_month = MONTH(DATEADD(MM, DATEDIFF(MM, 0, GETDATE()) - 1, 0)) and calendar_year = YEAR(DATEADD(MM, DATEDIFF(MM, 0, GETDATE()) - 1, 0))) tbl) new_tbl

select @iri_week_end_date = max(wk_end_dt) from [ebi].[cal_445_wk_dim_2] where fiscal_yr_cd = @Fiscal_YEAR  and rank_val = @Fiscal_Month group by fiscal_yr_cd,rank_val 
select @iri_week_end_date
*/
Declare @iri_week_end_date
SET @iri_week_end_date = 01-22-23
IF OBJECT_ID('tempdb..#all_outlet_stackline_time_aggregated') IS NOT NULL
BEGIN
DROP TABLE #all_outlet_stackline_time_aggregated
END

CREATE TABLE #all_outlet_stackline_time_aggregated
WITH
( DISTRIBUTION = ROUND_ROBIN
)
AS
select RetailerName, RetailerSku, SegmentName, Brand, Manufacturer, Category, Subcategory, @iri_week_end_date as IRI_week_end_date , 'Last 4-5 week' as Time_period, SUM(coalesce([RetailSales],0)) as 'Sales' from ebi.ebi_stackline_base_AO where IRI_week_end_date in (select wk_end_dt from [ebi].[cal_445_wk_dim_2] where fiscal_yr_cd = 2024 and rank_val = 1 )
GROUP BY RetailerName, RetailerSku, SegmentName, Brand, Manufacturer, Category, Subcategory

UNION

select RetailerName, RetailerSku, SegmentName, Brand, Manufacturer, Category, Subcategory, @iri_week_end_date as IRI_week_end_date , 'Last 13 weeks' as Time_period, SUM(coalesce([RetailSales],0)) as 'Sales' from ebi.ebi_stackline_base_AO where IRI_week_end_date in (select TOP 13 wk_end_dt from [ebi].[cal_445_wk_dim_2] where wk_end_dt <= @iri_week_end_date order by wk_end_dt desc)
GROUP BY RetailerName, RetailerSku, SegmentName, Brand, Manufacturer,  Category, Subcategory

UNION

select RetailerName, RetailerSku, SegmentName, Brand, Manufacturer, Category, Subcategory, @iri_week_end_date as IRI_week_end_date, 'Last 52 weeks' as Time_period, SUM(coalesce([RetailSales],0)) as 'Sales' from ebi.ebi_stackline_base_AO where IRI_week_end_date in (select TOP 52 wk_end_dt from [ebi].[cal_445_wk_dim_2] where wk_end_dt <= @iri_week_end_date order by wk_end_dt desc)
GROUP BY RetailerName, RetailerSku, SegmentName, Brand, Manufacturer, Category, Subcategory

select * from #all_outlet_stackline_time_aggregated

1 - 52 - used in aggregation.
53-104 - not used anywhere.
--------------------------------------------------
IF OBJECT_ID('tempdb..#AO_stackline_mapped_data_temp') IS NOT NULL
BEGIN
DROP TABLE #AO_stackline_mapped_data_temp
END

CREATE TABLE #AO_stackline_mapped_data_temp
WITH
( DISTRIBUTION = ROUND_ROBIN
)
AS
 select a.[RetailerName], a.[RetailerSku], a.[SegmentName], a.[Brand], a.[Manufacturer], a.[Category], a.[SubCategory], a.[IRI_week_end_date], a.[Time_Period], a.[Sales], b.AO_BU, b.AO_Segment
FROM (select * from #all_outlet_stackline_time_aggregated) a
INNER JOIN (select * from [ebi].[ebi_all_outlet_stackline_bu_segment_mapping] where AO_subcategory is NOT NULL) b
ON lower(a.SegmentName) = lower(b.AO_stacklinesegmentname) AND
lower(a.Subcategory) = lower(b.AO_subcategory)

UNION

select a.[RetailerName], a.[RetailerSku], a.[SegmentName], a.[Brand], a.[Manufacturer], a.[Category], a.[SubCategory], a.[IRI_week_end_date], a.[Time_Period], a.[Sales], b.AO_BU, b.AO_Segment
FROM (select * from #all_outlet_stackline_time_aggregated) a
INNER JOIN (select * from [ebi].[ebi_all_outlet_stackline_bu_segment_mapping] where AO_subcategory is NULL) b
ON lower(a.SegmentName) = lower(b.AO_stacklinesegmentname)

--select * from #AO_stackline_mapped_data_temp

---------***---------

IF OBJECT_ID('tempdb..#all_outlet_stackline_BU_aggregated') IS NOT NULL
BEGIN
DROP TABLE #all_outlet_stackline_BU_aggregated
END

CREATE TABLE #all_outlet_stackline_BU_aggregated
WITH
( 
DISTRIBUTION = ROUND_ROBIN
)
AS
select RetailerName,'Total' AS AO_BU, 'Total' AS AO_Segment, IRI_week_end_date, Time_Period, 'Category' as AO_Share_Component, 'All Category Total' as AO_level, SUM(coalesce([Sales],0)) as Sales
FROM #AO_stackline_mapped_data_temp
GROUP BY  RetailerName, IRI_week_end_date, Time_Period

UNION

select RetailerName,'Total' AS AO_BU, 'Total' AS AO_Segment, IRI_week_end_date, Time_Period, 'Clorox' as AO_Share_Component, 'All Category Total' as AO_level, SUM(coalesce([Sales],0)) as Sales
FROM (select * from #AO_stackline_mapped_data_temp where Manufacturer = 'Clorox') a
GROUP BY  RetailerName, IRI_week_end_date, Time_Period

UNION

select RetailerName, AO_BU, 'Total' AS AO_Segment, IRI_week_end_date, Time_Period, 'Category' as AO_Share_Component, 'BU Total' as AO_level, SUM(coalesce([Sales],0)) as Sales
FROM #AO_stackline_mapped_data_temp
GROUP BY  RetailerName, AO_BU, IRI_week_end_date, Time_Period

UNION

select a.RetailerName, a.AO_BU,'Total' AS AO_Segment, a.IRI_week_end_date, a.Time_Period, 'Clorox' as AO_Share_Component, 'BU Total' as AO_level, SUM(coalesce([Sales],0)) as Sales
FROM (select * from #AO_stackline_mapped_data_temp where Manufacturer = 'Clorox') a
GROUP BY a.RetailerName, a.AO_BU, a.IRI_week_end_date, a.Time_Period

UNION

select a.RetailerName, a.AO_BU, a.AO_Segment, a.IRI_week_end_date, a.Time_Period, 'Category' as AO_Share_Component, 'Segment Total' as AO_level, SUM(coalesce([Sales],0)) as Sales
FROM (select * from #AO_stackline_mapped_data_temp where AO_Segment IS NOT NULL) a
GROUP BY a.RetailerName, a.AO_BU, a.AO_Segment, a.IRI_week_end_date, a.Time_Period

UNION

select a.RetailerName, a.AO_BU, a.AO_Segment, a.IRI_week_end_date, a.Time_Period, 'Clorox' as AO_Share_Component, 'Segment Total' as AO_level, SUM(coalesce([Sales],0)) as Sales
FROM (select * from #AO_stackline_mapped_data_temp where AO_Segment IS NOT NULL and Manufacturer = 'Clorox') a
GROUP BY a.RetailerName, a.AO_BU, a.AO_Segment, a.IRI_week_end_date, a.Time_Period

UNION

select a.RetailerName, a.AO_BU, a.Brand as AO_Segment, a.IRI_week_end_date, a.Time_Period, 'Clorox' as AO_Share_Component, 'Segment Total' as AO_level, SUM(coalesce([Sales],0)) as Sales
FROM (select * from #AO_stackline_mapped_data_temp where Brand in ('Fresh Step', 'Scoop Away') and Manufacturer = 'Clorox') a
GROUP BY a.RetailerName, a.AO_BU, a.Brand, a.IRI_week_end_date, a.Time_Period

UNION

select a1.RetailerName, 'Total excl VMS/Burts' AS AO_BU, a1.AO_Segment, a1.IRI_week_end_date, a1.Time_period, a1.AO_Share_Component, a1.AO_Level , COALESCE(a1.Sales,0) - COALESCE(b1.Sales,0) AS Sales
from
(select RetailerName,'Total' AS AO_BU, 'Total' AS AO_Segment, IRI_week_end_date, Time_Period, 'Category' as AO_Share_Component, 'All Category Total' as AO_level, SUM(coalesce([Sales],0)) as Sales
FROM #AO_stackline_mapped_data_temp
GROUP BY  RetailerName, IRI_week_end_date, Time_Period) as a1
LEFT JOIN
(select RetailerName, 'VMS/Burts' AS AO_BU, 'Total' as AO_Segment, a.IRI_week_end_date, a.Time_Period, 'Category' as AO_Share_Component, 'All Category Total' as AO_level, sum(COALESCE(Sales,0)) as Sales
FROM (select * from #AO_stackline_mapped_data_temp where AO_BU in ('Burt''s','VMS')) a
GROUP BY a.RetailerName,a.IRI_week_end_date, a.Time_Period) as b1
ON a1.IRI_week_end_date = b1.IRI_week_end_date and
a1.Time_Period = b1.Time_Period

UNION

select a1.RetailerName, 'Total excl VMS/Burts' AS AO_BU, a1.AO_Segment, a1.IRI_week_end_date, a1.Time_period, a1.AO_Share_Component, a1.AO_Level , COALESCE(a1.Sales,0) - COALESCE(b1.Sales,0) AS Sales
from
(
select a.RetailerName,'Total' AS AO_BU, 'Total' AS AO_Segment, a.IRI_week_end_date, a.Time_Period, 'Clorox' as AO_Share_Component, 'All Category Total' as AO_level, SUM(coalesce([Sales],0)) as Sales
FROM (select * from #AO_stackline_mapped_data_temp where Manufacturer = 'Clorox') a
GROUP BY  RetailerName, IRI_week_end_date, Time_Period) as a1
LEFT JOIN
(select RetailerName, 'VMS/Burts' AS AO_BU, 'Total' as AO_Segment, a.IRI_week_end_date, a.Time_Period, 'Clorox' as AO_Share_Component, 'All Category Total' as AO_level, sum(COALESCE(Sales,0)) as Sales
FROM (select * from #AO_stackline_mapped_data_temp where AO_BU in ('Burt''s','VMS') and Manufacturer = 'Clorox') a
GROUP BY a.RetailerName, a.IRI_week_end_date, a.Time_Period) as b1
ON a1.IRI_week_end_date = b1.IRI_week_end_date and
a1.Time_Period = b1.Time_Period

--select * from #all_outlet_stackline_BU_aggregated

-----------------

 IF OBJECT_ID('tempdb..#stackline_sharetab') IS NOT NULL
BEGIN
DROP TABLE #stackline_sharetab
END

CREATE TABLE #stackline_sharetab
WITH
( DISTRIBUTION = ROUND_ROBIN
)
AS
  select [Source], Retailer, 
  case
  when ([Type] = 'Clx') then CONCAT(Product,[Type])
  when ([Type] = 'Cat') then Product
  end as BUName,
  [Type],
  Category,
  Product,
  [Dollar Sales],
  Time_Period,
  Week_end_date
  from
  (
SELECT 
	   case 
	   when ([AO_Share_Component] = 'Category') then 'Cat'
	   when ([AO_Share_Component] = 'Clorox') then 'Clx'
	   end as [Type],
	   'Stackline' as [Source]
      ,case
	   when ([RetailerName] = 'Amazon.com') then 'Amazon'
	   end as [Retailer]
      ,[Time_Period]
      ,[IRI_week_end_date] as [Week_End_Date]
      ,[Sales] as [Dollar Sales]
	  ,case 
	  when (AO_Segment = 'Total' and AO_Level = 'BU Total') then AO_BU
	  when (AO_Level = 'Segment Total') then AO_Segment
	  when (AO_Level in ('All Category Total', 'Custom Total')) then AO_BU
	  when (AO_Segment <> 'Total' and AO_Level = 'BU Total') then AO_Segment
	  end as Product,
	  case 
	  when (AO_Segment = 'Total' and AO_Level = 'BU Total') then NULL
	  when (AO_Level = 'Segment Total') then AO_BU
	  when (AO_Level in ('All Category Total', 'Custom Total')) then NULL
	  when (AO_Segment <> 'Total' and AO_Level = 'BU Total') then AO_BU
	  end as Category
  FROM #all_outlet_stackline_BU_aggregated
  ) a

--select * from #stackline_sharetab

--------***-------------

DELETE FROM [ebi].[ebi_all_outlet_stackline_base] where [Week_end_date] in (select DISTINCT([Week_end_date]) from #stackline_sharetab)
INSERT INTO [ebi].[ebi_all_outlet_stackline_base]([Source], [Retailer], [BUName], [Type], [Category], [Product],[Dollar Sales],[Time_Period], [Week_end_date] )
SELECT [Source], [Retailer], [BUName], [Type], [Category], [Product],[Dollar Sales],[Time_Period],  [Week_end_date] FROM #stackline_sharetab

END
GO


12-25-22
2021-12-26 00:00:00

- truncate table ebi.ebi_stackline_base_AO and [ebi].[ebi_all_outlet_stackline_base]
- bring data from UAT to DEV  for these two

- Trucate all maping tables([ebi].[ebi_all_outlet_stackline_bu_segment_mapping],ebi.stackline_brand_manufacturer_map) in between and bring in data for those all from UAT to DEV.





