/****** Object:  StoredProcedure [ebi].[sp_all_outlet_lowes_base]    Script Date: 6/14/2023 10:40:38 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER PROC [ebi].[sp_all_outlet_lowes_base] @iri_week_end_date [nvarchar](200),@Fiscal_Month [INT],@Fiscal_YEAR [INT] AS 
BEGIN


select @iri_week_end_date = cast(@iri_week_end_date as Date)

/*
DECLARE @Fiscal_Month INT, @Fiscal_YEAR INT, @iri_week_end_date date
select @Fiscal_Month = Fiscal_Month, @Fiscal_YEAR = Fiscal_YEAR from (select TOP 1* from (select DISTINCT Fiscal_Month, Fiscal_YEAR from ebi.calendar_week_dim2 where calendar_month = MONTH(DATEADD(MM, DATEDIFF(MM, 0, GETDATE()) - 2, 0)) and calendar_year = YEAR(DATEADD(MM, DATEDIFF(MM, 0, GETDATE()) - 2, 0))) tbl) new_tbl

select @iri_week_end_date = max(wk_end_dt) from [ebi].[cal_445_wk_dim_2] where fiscal_yr_cd = @Fiscal_YEAR and rank_val = @Fiscal_Month group by fiscal_yr_cd,rank_val 
--select @iri_week_end_date
*/

declare @iri_week_end_date_previous DATE, @Fiscal_Month_previous INT, @Fiscal_YEAR_previous INT
if @Fiscal_Month = 1
begin
select @Fiscal_Month_previous = 12, @Fiscal_YEAR_previous = @Fiscal_YEAR - 1
end
else
begin
select @Fiscal_Month_previous = @Fiscal_Month - 1, @Fiscal_YEAR_previous = @Fiscal_YEAR
end

select @iri_week_end_date_previous = max(wk_end_dt) from [ebi].[cal_445_wk_dim_2] where fiscal_yr_cd = @Fiscal_YEAR_previous and rank_val = @Fiscal_Month_previous group by fiscal_yr_cd,rank_val

select @iri_week_end_date_previous

-------------------------------------------------------



--checking if 52 weeks are available for aggregation, if True then aggregate for 52 weeks else, blank table for 52 weeks
declare @count_weeks_for_52 INT
select @count_weeks_for_52 = COUNT(distinct(Wk_end_dt)) from ebi.ebi_lowes_base where wk_end_dt in 
(select TOP 52 wk_end_dt from [ebi].[cal_445_wk_dim_2] where wk_end_dt <= @iri_week_end_date order by wk_end_dt desc)
select @count_weeks_for_52
IF OBJECT_ID('tempdb..#all_outlet_lowes_time_aggregated_52weeks') IS NOT NULL
BEGIN
DROP TABLE #all_outlet_lowes_time_aggregated_52weeks
END

IF @count_weeks_for_52 = 52
BEGIN
CREATE TABLE #all_outlet_lowes_time_aggregated_52weeks
WITH
( DISTRIBUTION = ROUND_ROBIN
)
AS
select Item_Number_ID, @iri_week_end_date as Week_end_date , 'Last 52 weeks' as Time_period, sum(COALESCE(Sales, 0)) as 'Total_Sales' 
from ebi.ebi_lowes_base where wk_end_dt in 
(select TOP 52 wk_end_dt from [ebi].[cal_445_wk_dim_2] where wk_end_dt <= @iri_week_end_date order by wk_end_dt desc)
GROUP BY Item_Number_ID
END
ELSE 
BEGIN
CREATE TABLE #all_outlet_lowes_time_aggregated_52weeks
(
Item_Number_ID INT,
Week_end_date Date,
Time_Period nvarchar(50),
Total_Sales decimal(18,4)
)
WITH
(
DISTRIBUTION = ROUND_ROBIN
)
END

select * from #all_outlet_lowes_time_aggregated_52weeks

IF OBJECT_ID('tempdb..#all_outlet_lowes_time_aggregated') IS NOT NULL
BEGIN
DROP TABLE #all_outlet_lowes_time_aggregated
END

CREATE TABLE #all_outlet_lowes_time_aggregated
WITH
( DISTRIBUTION = ROUND_ROBIN
)
AS

select Item_Number_ID, @iri_week_end_date as Week_end_date , 'Last 4-5 week' as Time_period, 
sum(COALESCE(Sales, 0)) as 'Total_Sales' from ebi.ebi_lowes_base where 
Wk_end_dt in (select wk_end_dt from [ebi].[cal_445_wk_dim_2] where fiscal_yr_cd = @Fiscal_YEAR and rank_val = @Fiscal_Month )
GROUP BY Item_Number_ID


UNION
select Item_Number_ID, @iri_week_end_date as Week_end_date , 'Last 13 weeks' as Time_period, sum(COALESCE(Sales, 0)) as 'Total_Sales' from ebi.ebi_lowes_base where wk_end_dt in
 (select TOP 13 wk_end_dt from [ebi].[cal_445_wk_dim_2] where wk_end_dt <= @iri_week_end_date order by wk_end_dt desc)
GROUP BY Item_Number_ID

UNION

select * from #all_outlet_lowes_time_aggregated_52weeks



select * from #all_outlet_lowes_time_aggregated 




IF OBJECT_ID('tempdb..#all_outlet_lowes_mapped') IS NOT NULL
BEGIN
DROP TABLE #all_outlet_lowes_mapped
END

CREATE TABLE #all_outlet_lowes_mapped
WITH
( 
DISTRIBUTION = ROUND_ROBIN
)
AS
select a.Item_Number_ID, a.Week_end_date, a.Time_period, a.Total_Sales, b.BU, b.Segment
from #all_outlet_lowes_time_aggregated a
INNER JOIN (select * from [ebi].[ebi_all_outlet_lowes_Map] where Active_Flag = 'Y') b
ON a.Item_Number_ID = b.Item_Number_ID

select * from #all_outlet_lowes_mapped 




IF OBJECT_ID('tempdb..#all_outlet_lowes_BU_aggregated') IS NOT NULL
BEGIN
DROP TABLE #all_outlet_lowes_BU_aggregated
END

CREATE TABLE #all_outlet_lowes_BU_aggregated
WITH
( 
DISTRIBUTION = ROUND_ROBIN
)
AS

select BU AS AO_BU, 'Total' AS AO_Segment, Week_End_Date, Time_Period, 'Clorox' as AO_Share_Component, 'BU Total' as AO_level, sum(Total_Sales) as Sales
FROM #all_outlet_lowes_mapped
GROUP BY   Week_end_date, Time_Period, BU


UNION

select a.BU AS AO_BU, a.Segment as AO_Segment, a.Week_End_Date, a.Time_Period, 'Clorox' as AO_Share_Component, 'Segment Total' as AO_level, sum(a.Total_Sales) as Sales
FROM (select * from #all_outlet_lowes_mapped where Segment IS NOT NULL) a
GROUP BY a.Week_end_date, a.Time_Period, a.BU, a.Segment


UNION

select 'Total' AS AO_BU, 'Total' as AO_Segment, a.Week_End_Date, a.Time_Period, 'Clorox' as AO_Share_Component, 'All Category Total' as AO_level, sum(a.Total_Sales) as Sales
FROM (select * from #all_outlet_lowes_mapped) a
GROUP BY a.Week_end_date, a.Time_Period

UNION

select 'Total excl VMS/Burts' AS AO_BU, a1.AO_Segment, a1.Week_end_date, a1.Time_period, a1.AO_Share_Component, a1.AO_Level , COALESCE(a1.Sales,0) - COALESCE(b1.Sales,0) AS Sales
from
(select 'Total' AS AO_BU, 'Total' as AO_Segment, a.Week_End_Date, a.Time_Period, 'Clorox' as AO_Share_Component, 'All Category Total' as AO_level, sum(a.Total_Sales) as Sales
FROM (select * from #all_outlet_lowes_mapped) a
GROUP BY a.Week_end_date, a.Time_Period) as a1

LEFT JOIN

(select 'VMS/Burts' AS AO_BU, 'Total' as AO_Segment, a.Week_End_Date, a.Time_Period, 'Clorox' as AO_Share_Component, 'All Category Total' as AO_level, sum(a.Total_Sales) as Sales
FROM (select * from #all_outlet_lowes_mapped where BU in ('Burt''s','VMS')) a
GROUP BY a.Week_end_date, a.Time_Period) as b1
ON a1.Week_end_date = b1.Week_end_date and
a1.Time_Period = b1.Time_Period

select * from #all_outlet_lowes_BU_aggregated 



 IF OBJECT_ID('tempdb..#lowes_sharetab_clx') IS NOT NULL
BEGIN
DROP TABLE #lowes_sharetab_clx
END

CREATE TABLE #lowes_sharetab_clx
WITH
( DISTRIBUTION = ROUND_ROBIN
)
AS
  select [Source],Retailer, 
  case
  when ([Type] = 'Clx') then CONCAT(Product,[Type])
  when ([Type] = 'Cat') then Product
  end as BUName,
  [Type],
  Category,
  Product,
  [Dollar Sales],
  Time_Period,
  Week_end_date
  from
  (
SELECT 
	   case 
	   when ([AO_Share_Component] = 'Category') then 'Cat'
	   when ([AO_Share_Component] = 'Clorox') then 'Clx'
	   end as [Type]
	   ,'Lowes' as [Source]
      ,'Lowes' as [Retailer]
      ,[Time_Period]
      ,[Week_End_Date]
      ,[Sales] as [Dollar Sales]
	  ,case 
	  when (AO_Segment = 'Total' and AO_Level = 'BU Total') then AO_BU
	  when (AO_Level = 'Segment Total') then AO_Segment
	  when (AO_Level in ('All Category Total', 'Custom Total')) then AO_BU
	  when (AO_Segment <> 'Total' and AO_Level = 'BU Total') then AO_Segment
	  end as Product,
	  case 
	  when (AO_Segment = 'Total' and AO_Level = 'BU Total') then NULL
	  when (AO_Level = 'Segment Total') then AO_BU
	  when (AO_Level in ('All Category Total', 'Custom Total')) then NULL
	  when (AO_Segment <> 'Total' and AO_Level = 'BU Total') then AO_BU
	  end as Category
  FROM #all_outlet_lowes_BU_aggregated
  ) a
  
  
select * from #lowes_sharetab_clx order by 8, 5,6

-------------------------Category Calculations-------------------------------------------

 IF OBJECT_ID('tempdb..#lowes_sharetab_share_value') IS NOT NULL
BEGIN
DROP TABLE #lowes_sharetab_share_value
END

CREATE TABLE #lowes_sharetab_share_value
WITH
( DISTRIBUTION = ROUND_ROBIN
)
AS
  select [Source], Retailer, 
  case
  when ([Type] = 'Clx') then CONCAT(Product,[Type])
  when ([Type] = 'Cat') then Product
  end as BUName,
  [Type],
  Category,
  Product,
  [Share],
  Time_Period,
  Week_end_date
  from
  (
SELECT 
	   case 
	   when ([AO_Share Component] = 'Category') then 'Cat'
	   when ([AO_Share Component] = 'Clorox') then 'Clx'
	   end as [Type]
	   ,'Lowes' as [Source]
      ,'Lowes' as [Retailer]
      ,[Time_Period]
      ,IRI_month_end_date AS [Week_End_Date]
      ,[Share] as [Share]
	  ,case 
	  when (AO_Segment = 'Total' and AO_Level = 'BU Total') then AO_BU
	  when (AO_Level = 'Segment Total') then AO_Segment
	  when (AO_Level in ('All Category Total', 'Custom Total')) then AO_BU
	  when (AO_Segment <> 'Total' and AO_Level = 'BU Total') then AO_Segment
	  end as Product,
	  case 
	  when (AO_Segment = 'Total' and AO_Level = 'BU Total') then NULL
	  when (AO_Level = 'Segment Total') then AO_BU
	  when (AO_Level in ('All Category Total', 'Custom Total')) then NULL
	  when (AO_Segment <> 'Total' and AO_Level = 'BU Total') then AO_BU
	  end as Category
  FROM [ebi].[ebi_all_outlet_iri_panel_share] where IRI_month_end_date = @iri_week_end_date and Retailer = 'Lowes'
  ) a



------
--------------------LEVEL 1 formuale for category calculations



IF OBJECT_ID('tempdb..#lowes_sharetab_cat') IS NOT NULL
BEGIN
DROP TABLE #lowes_sharetab_cat
END 
CREATE TABLE #lowes_sharetab_cat
WITH
(
DISTRIBUTION = ROUND_ROBIN
)
AS
select * from (
select  a.[Source], a.Retailer, a.Product as [BUName] , 'Cat' as [Type], a.Category, a.Product,
(a.[Dollar Sales] / NULLIF(b.Share,0)) AS [Dollar Sales],  a.Time_Period, a.Week_end_date
from #lowes_sharetab_clx a
inner join #lowes_sharetab_share_value b
on a.[Source] = b.[Source] and
a.Retailer = b.Retailer and
a.BUName = b.BUName and
a.[Type] = b.[Type] and
a.Product = b.Product and 
a.Time_Period = b.Time_Period
and a.Week_end_date = b.Week_end_date
) a1
where a1.[Dollar Sales] is NOT NULL



select * from #lowes_sharetab_cat  order by 8,5,6,3
-------------------------


IF OBJECT_ID('tempdb..#panel_raw_data_for_special_cases') IS NOT NULL
BEGIN
DROP TABLE #panel_raw_data_for_special_cases
END 
CREATE TABLE #panel_raw_data_for_special_cases
WITH
(
DISTRIBUTION = ROUND_ROBIN
)
AS
select * from (
SELECT [AO_BU],[AO_Segment],[AO_Level],[AO_Share Component],[Product],[Retailer],[Time_Period], b.[Week_end_date],c.IRI_month_end_date as [IRI_month_end_Date],[Dollar_Sales],null as Share, GETDATE() as  [Modified_time]
FROM [ebi].[ebi_all_outlet_panel_base] b
INNER JOIN  [ebi].[ebi_all_outlet_iri_product_mapping] a
ON a.AO_Product = b.Product
INNER JOIN ebi.calendar_panel_iri c on b.Week_end_date = c.Panel_week_end_date ) a1
where a1.IRI_month_end_date = @iri_week_end_date and a1.Retailer = 'Lowes'



select * from #lowes_sharetab_cat



--in #lowes_sharetab_cat table there will be no record of Dilutables if Dollar Sales is null (as per #lowes_sharetab_cat table query above), so in below,  IF condition of Dilutables record is not present then only the special calculation of DILUTABLES WILL BE DONE
-----(Level 2 formulae for category calculations)


IF (select COUNT(*) from #lowes_sharetab_cat where Product in ('Dilutables') and Time_period in ('Last 4-5 week', 'Last 13 Weeks')) = 0
BEGIN

		delete from ebi.ebi_all_outlet_iri_panel_share_special_cases where Retailer = 'Lowes' and Time_Period in ('Last 4-5 week', 'Last 13 weeks') and AO_segment = 'Dilutables' and IRI_month_end_date = @iri_week_end_date

		INSERT INTO ebi.ebi_all_outlet_iri_panel_share_special_cases(AO_BU, AO_Segment, AO_Level, Retailer, Time_Period, IRI_month_end_date, Share)
		select TOP 2 AO_BU, AO_Segment, AO_Level, Retailer, Time_Period, @iri_week_end_date as IRI_month_end_date, Share_ AS Share from 
		(
		select AVG(Share) OVER (partition by Time_Period ORDER BY IRI_month_end_date desc ROWS BETWEEN CURRENT ROW AND 3 FOLLOWING) as Share_, * from ebi.ebi_all_outlet_iri_panel_share_special_cases where Retailer = 'Lowes' and Time_Period in ('Last 4-5 week', 'Last 13 weeks') and AO_segment = 'Dilutables' and IRI_month_end_date < @iri_week_end_date
		) a order by a.IRI_month_end_date desc, a.Time_Period


		 ----4-5 week and 13 weeks DILUTABLES
		INSERT INTO #lowes_sharetab_cat([Source], [Retailer],[BUName],[Type],[Category], [Product], [Dollar Sales], [Time_Period], [Week_end_date])
		select a.[Source], a.[Retailer], a.Product as [BUName], 'Cat' as [Type], a.Category, a.Product, (a.[Dollar Sales] / NULLIF(b.Share,0)) AS [Dollar Sales],  a.Time_Period, a.Week_end_date
		from
		(select * from #lowes_sharetab_clx where Product in ('Dilutables') and Time_period in ('Last 4-5 week', 'Last 13 Weeks')) a
		INNER JOIN
		(select * from ebi.ebi_all_outlet_iri_panel_share_special_cases where IRI_month_end_date = @iri_week_end_date and Retailer = 'Lowes' and AO_Segment in ('Dilutables') and Time_Period in ('Last 4-5 week', 'Last 13 Weeks')) b
		ON a.Time_Period = b.Time_Period and
		a.Product = b.AO_Segment and
		a.Category = b.AO_BU

END
ELSE
BEGIN
		delete from ebi.ebi_all_outlet_iri_panel_share_special_cases where Retailer = 'Lowes' and Time_Period in ('Last 4-5 week', 'Last 13 weeks') and AO_segment = 'Dilutables' and IRI_month_end_date = @iri_week_end_date
		INSERT INTO ebi.ebi_all_outlet_iri_panel_share_special_cases(AO_BU, AO_Segment, AO_Level, Retailer, Time_Period, IRI_month_end_date, Share)
		select AO_BU, AO_Segment, AO_Level, Retailer, Time_Period, IRI_month_end_date, Share from ebi.ebi_all_outlet_iri_panel_share where Retailer = 'Lowes' and Time_Period in ('Last 4-5 week', 'Last 13 weeks') and AO_segment = 'Dilutables' and IRI_month_end_date = @iri_week_end_date

END



 ----52 weeks DILUTABLES
 -----(Level 2 formulae for category calculations)
IF (select COUNT(*) from #lowes_sharetab_cat where Product in ('Dilutables') and Time_period in ('Last 52 Weeks')) = 0
BEGIN
INSERT INTO #lowes_sharetab_cat([Source], [Retailer],[BUName],[Type],[Category], [Product], [Dollar Sales], [Time_Period], [Week_end_date])
select a.[Source], a.[Retailer], a.Product as [BUName], 'Cat' as [Type], a.Category, a.Product, (a.[Dollar Sales]*c.[Dollar Sales])/NULLIF(b.[Dollar Sales],0) AS [Dollar Sales],  a.Time_Period, a.Week_end_date
from
(select * from #lowes_sharetab_clx where Product in ('Dilutables') and Time_period in ('Last 52 Weeks')) a
INNER JOIN
(select * from [ebi].[ebi_all_outlet_lowes_base] where Week_end_date = @iri_week_end_date_previous and [Type] = 'Clx' and Product in ('Dilutables') and Time_Period in ('Last 52 Weeks')) b
on a.[Source] = b.[Source] and
a.Retailer = b.Retailer and
a.Product = b.Product and 
a.Time_Period = b.Time_Period and
a.Category = b.Category
INNER JOIN
(select * from [ebi].[ebi_all_outlet_lowes_base] where Week_end_date = @iri_week_end_date_previous and [Type] = 'Cat' and Product in ('Dilutables') and Time_Period in ('Last 52 Weeks')) c
on a.[Source] = c.[Source] and
a.Retailer = c.Retailer and
a.Product = c.Product and 
a.Time_Period = c.Time_Period and
a.Category = c.Category

END



;
--GLAD BU TOTAL
--in #lowes_sharetab_cat table there will be no record of Glad BU total if Dollar Sales is null (as per #lowes_sharetab_cat table query above), so in below,  IF condition of Glad BU total record is not present then only the special calculation of Glad BU total WILL BE DONE
-----(Level 2 formulae for category calculations)


IF (select COUNT(*) from #lowes_sharetab_cat where Product in ('Glad') and Time_period in ('Last 4-5 week', 'Last 13 Weeks', 'Last 52 weeks')) = 0
BEGIN

		delete from ebi.ebi_all_outlet_iri_panel_share_special_cases where Retailer = 'Lowes' and Time_Period in ('Last 4-5 week', 'Last 13 weeks', 'Last 52 weeks') and AO_BU = 'Glad' and AO_segment = 'Total' and IRI_month_end_date = @iri_week_end_date

		INSERT INTO ebi.ebi_all_outlet_iri_panel_share_special_cases(AO_BU, AO_Segment, AO_Level, Retailer, Time_Period, IRI_month_end_date, Share)
		select AO_BU, AO_Segment, AO_Level, Retailer, Time_Period, @iri_week_end_date as IRI_month_end_date, Share from  ebi.ebi_all_outlet_iri_panel_share_special_cases where Retailer = 'Lowes' and Time_Period in ('Last 4-5 week', 'Last 13 weeks', 'Last 52 weeks') and AO_BU = 'Glad' and AO_segment = 'Total' and IRI_month_end_date = @iri_week_end_date_previous


		 ----4-5 week and 13 weeks, 52 weeks GLAD BU TOTAL CAT
		INSERT INTO #lowes_sharetab_cat([Source], [Retailer],[BUName],[Type],[Category], [Product], [Dollar Sales], [Time_Period], [Week_end_date])
		select a.[Source], a.[Retailer], a.Product as [BUName], 'Cat' as [Type], a.Category, a.Product, (a.[Dollar Sales] / NULLIF(b.Share,0)) AS [Dollar Sales],  a.Time_Period, a.Week_end_date
		from
		(select * from #lowes_sharetab_clx where Product in ('Glad') and Time_period in ('Last 4-5 week', 'Last 13 Weeks', 'Last 52 weeks')) a
		INNER JOIN
		(select * from ebi.ebi_all_outlet_iri_panel_share_special_cases where IRI_month_end_date = @iri_week_end_date and Retailer = 'Lowes' and AO_BU = 'Glad' and AO_Segment in ('Total') and Time_Period in ('Last 4-5 week', 'Last 13 Weeks','Last 52 weeks')) b
		ON a.Time_Period = b.Time_Period and
		a.Product = b.AO_BU

END
ELSE
BEGIN
		delete from ebi.ebi_all_outlet_iri_panel_share_special_cases where Retailer = 'Lowes' and Time_Period in ('Last 4-5 week', 'Last 13 weeks', 'Last 52 weeks') and AO_BU = 'Glad' and AO_segment = 'Total' and IRI_month_end_date = @iri_week_end_date
		INSERT INTO ebi.ebi_all_outlet_iri_panel_share_special_cases(AO_BU, AO_Segment, AO_Level, Retailer, Time_Period, IRI_month_end_date, Share)
		select AO_BU, AO_Segment, AO_Level, Retailer, Time_Period, IRI_month_end_date, Share from ebi.ebi_all_outlet_iri_panel_share where Retailer = 'Lowes' and Time_Period in ('Last 4-5 week', 'Last 13 weeks', 'Last 52 weeks') and AO_BU = 'Glad' and AO_segment = 'Total' and IRI_month_end_date = @iri_week_end_date

END



----------------------------------------------------------------------------------------------------------------------------------------------------------------------

--in #lowes_sharetab_cat table there will be no record of Trash if Dollar Sales is null, so in IF condition of Trash record is not present then only the special calculation of Trash WILL BE DONE
------(Level 2 formulae for category calculations)

IF (select COUNT(*) from #lowes_sharetab_cat where Product in ('Trash') and Time_period in ('Last 4-5 week', 'Last 13 Weeks')) = 0
BEGIN

		delete from ebi.ebi_all_outlet_iri_panel_share_special_cases where Retailer = 'Lowes' and Time_Period in ('Last 4-5 week', 'Last 13 weeks') and AO_segment = 'Trash' and IRI_month_end_date = @iri_week_end_date

		INSERT INTO ebi.ebi_all_outlet_iri_panel_share_special_cases(AO_BU, AO_Segment, AO_Level, Retailer, Time_Period, IRI_month_end_date, Share)
		select AO_BU, AO_Segment, AO_Level, Retailer, Time_Period, @iri_week_end_date as IRI_month_end_date, Share from  ebi.ebi_all_outlet_iri_panel_share_special_cases where Retailer = 'Lowes' and Time_Period in ('Last 4-5 week', 'Last 13 weeks') and AO_BU = 'Glad' and AO_segment = 'Trash' and IRI_month_end_date = @iri_week_end_date_previous


		 ----4-5 week and 13 weeks trash
		INSERT INTO #lowes_sharetab_cat([Source], [Retailer],[BUName],[Type],[Category], [Product], [Dollar Sales], [Time_Period], [Week_end_date])
		select a.[Source], a.[Retailer], a.Product as [BUName], 'Cat' as [Type], a.Category, a.Product, (a.[Dollar Sales] / NULLIF(b.Share,0)) AS [Dollar Sales],  a.Time_Period, a.Week_end_date
		from
		(select * from #lowes_sharetab_clx where Product in ('Trash') and Time_period in ('Last 4-5 week', 'Last 13 Weeks')) a
		INNER JOIN
		(select * from ebi.ebi_all_outlet_iri_panel_share_special_cases where IRI_month_end_date = @iri_week_end_date and Retailer = 'Lowes' and AO_Segment in ('Trash') and Time_Period in ('Last 4-5 week', 'Last 13 Weeks')) b
		ON a.Time_Period = b.Time_Period and
		a.Product = b.AO_Segment and
		a.Category = b.AO_BU

END
ELSE
BEGIN
		delete from ebi.ebi_all_outlet_iri_panel_share_special_cases where Retailer = 'Lowes' and Time_Period in ('Last 4-5 week', 'Last 13 weeks') and AO_segment = 'Trash' and IRI_month_end_date = @iri_week_end_date
		INSERT INTO ebi.ebi_all_outlet_iri_panel_share_special_cases(AO_BU, AO_Segment, AO_Level, Retailer, Time_Period, IRI_month_end_date, Share)
		select AO_BU, AO_Segment, AO_Level, Retailer, Time_Period, IRI_month_end_date, Share from ebi.ebi_all_outlet_iri_panel_share where Retailer = 'Lowes' and Time_Period in ('Last 4-5 week', 'Last 13 weeks') and AO_segment = 'Trash' and IRI_month_end_date = @iri_week_end_date

END

 ----52 weeks Trash
 ---------(Level 2 formulae for category calculations)
IF (select COUNT(*) from #lowes_sharetab_cat where Product in ('Trash') and Time_period in ('Last 52 Weeks')) = 0
BEGIN
/*
INSERT INTO #lowes_sharetab_cat([Source], [Retailer],[BUName],[Type],[Category], [Product], [Dollar Sales], [Time_Period], [Week_end_date])
select a.[Source], a.[Retailer], a.Product as [BUName], 'Cat' as [Type], a.Category, a.Product, (a.[Dollar Sales]*c.[Dollar Sales])/NULLIF(b.[Dollar Sales],0) AS [Dollar Sales],  a.Time_Period, a.Week_end_date
from
(select * from #lowes_sharetab_clx where Product in ('Trash') and Time_period in ('Last 52 Weeks')) a
INNER JOIN
(select * from [ebi].[ebi_all_outlet_lowes_base] where Week_end_date = @iri_week_end_date_previous and [Type] = 'Clx' and Product in ('Trash') and Time_Period in ('Last 52 Weeks')) b
on a.[Source] = b.[Source] and
a.Retailer = b.Retailer and
a.Product = b.Product and 
a.Time_Period = b.Time_Period and
a.Category = b.Category
INNER JOIN
(select * from [ebi].[ebi_all_outlet_lowes_base] where Week_end_date = @iri_week_end_date_previous and [Type] = 'Cat' and Product in ('Trash') and Time_Period in ('Last 52 Weeks')) c
on a.[Source] = c.[Source] and
a.Retailer = c.Retailer and
a.Product = c.Product and 
a.Time_Period = c.Time_Period and
a.Category = c.Category
*/
INSERT INTO #lowes_sharetab_cat([Source], [Retailer],[BUName],[Type],[Category], [Product], [Dollar Sales], [Time_Period], [Week_end_date])
select a.Source, a.Retailer, c.AO_Segment as BUName, a.[Type], c.AO_BU as Category, c.AO_Segment as Product, (a.[Dollar Sales]*c.[Dollar_Sales])/NULLIF(b.[Dollar_Sales],0) as [Dollar Sales], c.Time_Period, a.Week_end_date
from 
(select * from #lowes_sharetab_cat where Time_Period = 'Last 52 weeks' and [Type] = 'Cat' and Category is NULL
and Product = 'Glad') a
INNER JOIN
(select * from #panel_raw_data_for_special_cases where Time_Period = 'Last 52 weeks' and [AO_Share Component] = 'Category'
and AO_BU = 'Glad' and AO_Segment = 'Total') b
ON a.Time_Period = b.Time_Period and
a.Product = b.AO_BU
INNER JOIN
(select * from #panel_raw_data_for_special_cases where Time_Period = 'Last 52 weeks' and [AO_Share Component] = 'Category'
and AO_BU = 'Glad' and AO_Segment = 'Trash') c
ON a.Time_Period = c.Time_Period and 
a.Product = c.AO_BU
END


-------------------------------------------------------------------------------------------------------------------------------------------------------------------------


--Pellets 52 weeks category
------(Level 2 formulae for category calculations)

delete from #lowes_sharetab_cat where Product in ('Pellets')

INSERT INTO #lowes_sharetab_cat([Source], [Retailer],[BUName],[Type],[Category], [Product], [Dollar Sales], [Time_Period], [Week_end_date])
select a.Source, a.Retailer, c.AO_Segment as BUName, a.[Type], c.AO_BU as Category, c.AO_Segment as Product, (a.[Dollar Sales]*c.[Dollar_Sales])/NULLIF(b.[Dollar_Sales],0) as [Dollar Sales], c.Time_Period, a.Week_end_date
from 
(select * from #lowes_sharetab_cat where Time_Period = 'Last 52 weeks' and [Type] = 'Cat' and Category is NULL
and Product = 'Kingsford') a
INNER JOIN
(select * from #panel_raw_data_for_special_cases where Time_Period = 'Last 52 weeks' and [AO_Share Component] = 'Category'
and AO_BU = 'Kingsford' and AO_Segment = 'Total') b
ON a.Time_Period = b.Time_Period and
a.Product = b.AO_BU
INNER JOIN
(select * from #panel_raw_data_for_special_cases where Time_Period = 'Last 52 weeks' and [AO_Share Component] = 'Category'
and AO_BU = 'Kingsford' and AO_Segment = 'Pellets') c
ON a.Time_Period = c.Time_Period and 
a.Product = c.AO_BU


--Pellets 13 weeks category

INSERT INTO #lowes_sharetab_cat([Source], [Retailer],[BUName],[Type],[Category], [Product], [Dollar Sales], [Time_Period], [Week_end_date])
select c.Source, c.Retailer, c.BUName as BUName, c.[Type], c.Category as Category, c.Product as Product, (a.[Dollar Sales]*c.[Dollar Sales])/NULLIF(b.[Dollar Sales],0) as [Dollar Sales], a.Time_Period, c.Week_end_date
from 
(select * from #lowes_sharetab_cat where Time_Period = 'Last 13 weeks' and [Type] = 'Cat' and Category = 'Kingsford'
and Product = 'Charcoal') a
INNER JOIN
(select * from #lowes_sharetab_cat where Time_Period = 'Last 52 weeks' and [Type] = 'Cat' and Category = 'Kingsford'
and Product = 'Charcoal') b
ON a.Category = b.Category
INNER JOIN
(select * from #lowes_sharetab_cat where Time_Period = 'Last 52 weeks' and [Type] = 'Cat' and Category = 'Kingsford'
and Product = 'Pellets') c
ON a.Category = c.Category


--Pellets 4-5 week category

INSERT INTO #lowes_sharetab_cat([Source], [Retailer],[BUName],[Type],[Category], [Product], [Dollar Sales], [Time_Period], [Week_end_date])
select c.Source, c.Retailer, c.BUName as BUName, c.[Type], c.Category as Category, c.Product as Product, (a.[Dollar Sales]*c.[Dollar Sales])/NULLIF(b.[Dollar Sales],0) as [Dollar Sales], a.Time_Period, c.Week_end_date
from 
(select * from #lowes_sharetab_cat where Time_Period = 'Last 4-5 week' and [Type] = 'Cat' and Category is NULL
and Product = 'Kingsford') a
INNER JOIN
(select * from #lowes_sharetab_cat where Time_Period = 'Last 13 weeks' and [Type] = 'Cat' and Category is NULL
and Product = 'Kingsford') b
ON a.Product= b.Product
INNER JOIN
(select * from #lowes_sharetab_cat where Time_Period = 'Last 13 weeks' and [Type] = 'Cat' and Category = 'Kingsford'
and Product = 'Pellets') c
ON a.Product = c.Category


----Category Total calculations and Total excl/ VMS burts

INSERT INTO #lowes_sharetab_cat([Source], [Retailer],[BUName],[Type],[Category], [Product], [Dollar Sales], [Time_Period], [Week_end_date])
select [Source], Retailer, 'Total' AS BUName, [Type], NULL as Category, 'Total' AS Product, sum(coalesce([Dollar Sales],0)) as Sales, Time_Period, Week_End_Date
FROM (select * from #lowes_sharetab_cat where Category is NULL and Product <> 'Total') a
GROUP BY [Source], Retailer, [Type], Week_end_date, Time_Period

UNION

select a1.[Source], a1.Retailer, 'Total excl VMS/Burts' AS BUName, a1.[Type], NULL as Category, 'Total excl VMS/Burts' AS Product, (coalesce(a1.[Sales],0) - coalesce(b1.[Sales],0)) as Sales, a1.Time_Period, a1.Week_End_Date 
from (select [Source], Retailer, 'Total' AS BUName, [Type], NULL as Category, 'Total' AS Product, sum(coalesce([Dollar Sales],0)) as Sales, Time_Period, Week_End_Date
FROM (select * from #lowes_sharetab_cat where Category is NULL and Product <> 'Total') a
GROUP BY [Source], Retailer, [Type], Week_end_date, Time_Period ) a1
LEFT JOIN
(select [Source], Retailer, 'VMS/Burts' AS BUName, [Type], NULL as Category, 'VMS/Burts' AS Product, sum(coalesce([Dollar Sales],0)) as Sales, Time_Period, Week_End_Date
FROM (select * from #lowes_sharetab_cat where Category is NULL and Product in ('VMS', 'Burts')) b
GROUP BY [Source], Retailer, [Type], Week_end_date, Time_Period) b1
ON a1.[Source] = b1.[Source] and
a1.[Retailer] = b1.[Retailer] and
a1.[Type] = b1.[Type] and
a1.Time_Period = b1.Time_Period and
a1.Week_end_date = b1.Week_end_date






DELETE FROM [ebi].[ebi_all_outlet_lowes_base] where [Week_end_date] in (select DISTINCT([Week_end_date]) from #lowes_sharetab_clx)
INSERT INTO [ebi].[ebi_all_outlet_lowes_base]([Source], [Retailer], [BUName], [Type], [Category], [Product],[Dollar Sales],[Time_Period], [Week_end_date] )
SELECT [Source], [Retailer], [BUName], [Type], [Category], [Product],[Dollar Sales],[Time_Period],  [Week_end_date] FROM #lowes_sharetab_clx

INSERT INTO [ebi].[ebi_all_outlet_lowes_base]([Source], [Retailer], [BUName], [Type], [Category], [Product],[Dollar Sales],[Time_Period], [Week_end_date] )
SELECT [Source], [Retailer], [BUName], [Type], [Category], [Product],[Dollar Sales],[Time_Period],  [Week_end_date] FROM #lowes_sharetab_cat

END