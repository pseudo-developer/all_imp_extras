/****** Object:  StoredProcedure [ebi].[sp_all_outlet_costco_base]    Script Date: 6/14/2023 10:40:14 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER PROC [ebi].[sp_all_outlet_costco_base] @iri_week_end_date [nvarchar](200),@Fiscal_Month [INT],@Fiscal_YEAR [INT] AS 
BEGIN

select @iri_week_end_date = cast(@iri_week_end_date as Date)

------*****-------
--checking if 52 weeks are available for aggregation, if True then aggregate for 52 weeks else, blank table for 52 weeks
declare @count_weeks_for_52 INT
select @count_weeks_for_52 = COUNT(distinct(Week_end_date)) from ebi.ebi_costco_base where Week_End_Date in (select TOP 52 wk_end_dt from [ebi].[cal_445_wk_dim_2] where wk_end_dt <= @iri_week_end_date order by wk_end_dt desc)
select @count_weeks_for_52

IF OBJECT_ID('tempdb..#all_outlet_costco_time_aggregated_52weeks') IS NOT NULL
BEGIN
DROP TABLE #all_outlet_costco_time_aggregated_52weeks
END

IF @count_weeks_for_52 = 52
BEGIN
CREATE TABLE #all_outlet_costco_time_aggregated_52weeks
WITH
( DISTRIBUTION = ROUND_ROBIN
)
AS
select Item_Number, @iri_week_end_date as Week_end_date , 'Last 52 weeks' as Time_period, sum(COALESCE(Dollar_Sales, 0)) as 'Sales' from ebi.ebi_costco_base where Week_End_Date in (select TOP 52 wk_end_dt from [ebi].[cal_445_wk_dim_2] where wk_end_dt <= @iri_week_end_date order by wk_end_dt desc)
GROUP BY Item_Number
END

ELSE 

BEGIN
CREATE TABLE #all_outlet_costco_time_aggregated_52weeks
(
Item_Number INT,
Week_end_date Date,
Time_Period nvarchar(50),
Sales decimal(18,4)
)
WITH
(
DISTRIBUTION = ROUND_ROBIN
)
END

select * from #all_outlet_costco_time_aggregated_52weeks

IF OBJECT_ID('tempdb..#all_outlet_costco_time_aggregated') IS NOT NULL
BEGIN
DROP TABLE #all_outlet_costco_time_aggregated
END

CREATE TABLE #all_outlet_costco_time_aggregated
WITH
( DISTRIBUTION = ROUND_ROBIN
)
AS
select Item_Number, @iri_week_end_date as Week_end_date , 'Last 4-5 week' as Time_period, sum(COALESCE(Dollar_Sales, 0)) as 'Sales' from ebi.ebi_costco_base where Week_End_Date in (select wk_end_dt from [ebi].[cal_445_wk_dim_2] where fiscal_yr_cd = @Fiscal_YEAR and rank_val = @Fiscal_Month )
GROUP BY Item_Number

UNION

select Item_Number, @iri_week_end_date as Week_end_date , 'Last 13 weeks' as Time_period, sum(COALESCE(Dollar_Sales, 0)) as 'Sales' from ebi.ebi_costco_base where Week_End_Date in (select TOP 13 wk_end_dt from [ebi].[cal_445_wk_dim_2] where wk_end_dt <= @iri_week_end_date order by wk_end_dt desc)
GROUP BY Item_Number

UNION

select * from #all_outlet_costco_time_aggregated_52weeks



select * from #all_outlet_costco_time_aggregated


------------------***000---------------------
--join with mapping table
-- BU aggregation

IF OBJECT_ID('tempdb..#all_outlet_costco_mapped') IS NOT NULL
BEGIN
DROP TABLE #all_outlet_costco_mapped
END

CREATE TABLE #all_outlet_costco_mapped
WITH
( 
DISTRIBUTION = ROUND_ROBIN
)
AS
select a.Item_Number, a.Week_end_date, a.Time_period, a.Sales, b.BU, b.Segment
from #all_outlet_costco_time_aggregated a
INNER JOIN (select * from [ebi].[ebi_all_outlet_Costco_Map]  where Active_Flag = 'Y') b
ON a.Item_Number = b.item_number

select * from #all_outlet_costco_mapped



IF OBJECT_ID('tempdb..#all_outlet_costco_BU_aggregated') IS NOT NULL
BEGIN
DROP TABLE #all_outlet_costco_BU_aggregated
END

CREATE TABLE #all_outlet_costco_BU_aggregated
WITH
( 
DISTRIBUTION = ROUND_ROBIN
)
AS

select BU AS AO_BU, 'Total' AS AO_Segment, Week_End_Date, Time_Period, 'Clorox' as AO_Share_Component, 'BU Total' as AO_level, sum(Sales) as Sales
FROM #all_outlet_costco_mapped
GROUP BY   Week_end_date, Time_Period, BU

UNION

select a.BU AS AO_BU, a.Segment as AO_Segment, a.Week_End_Date, a.Time_Period, 'Clorox' as AO_Share_Component, 'Segment Total' as AO_level, sum(a.Sales) as Sales
FROM (select * from #all_outlet_costco_mapped where Segment IS NOT NULL) a
GROUP BY a.Week_end_date, a.Time_Period, a.BU, a.Segment

UNION

select 'Total' AS AO_BU, 'Total' as AO_Segment, a.Week_End_Date, a.Time_Period, 'Clorox' as AO_Share_Component, 'All Category Total' as AO_level, sum(a.Sales) as Sales
FROM (select * from #all_outlet_costco_mapped) a
GROUP BY a.Week_end_date, a.Time_Period

UNION

select 'Total excl VMS/Burts' AS AO_BU, a1.AO_Segment, a1.Week_end_date, a1.Time_period, a1.AO_Share_Component, a1.AO_Level , a1.Sales - b1.Sales AS Sales
from
(select 'Total' AS AO_BU, 'Total' as AO_Segment, a.Week_End_Date, a.Time_Period, 'Clorox' as AO_Share_Component, 'All Category Total' as AO_level, sum(a.Sales) as Sales
FROM (select * from #all_outlet_costco_mapped) a
GROUP BY a.Week_end_date, a.Time_Period) as a1
LEFT JOIN
(select 'VMS/Burts' AS AO_BU, 'Total' as AO_Segment, a.Week_End_Date, a.Time_Period, 'Clorox' as AO_Share_Component, 'All Category Total' as AO_level, sum(a.Sales) as Sales
FROM (select * from #all_outlet_costco_mapped where BU in ('Burt''s','VMS')) a
GROUP BY a.Week_end_date, a.Time_Period) as b1
ON a1.Week_end_date = b1.Week_end_date and
a1.Time_Period = b1.Time_Period

----------*****------------

select * from #all_outlet_costco_BU_aggregated


 IF OBJECT_ID('tempdb..#costco_sharetab_clx') IS NOT NULL
BEGIN
DROP TABLE #costco_sharetab_clx
END

CREATE TABLE #costco_sharetab_clx
WITH
( DISTRIBUTION = ROUND_ROBIN
)
AS
  select [Source], Retailer, 
  case
  when ([Type] = 'Clx') then CONCAT(Product,[Type])
  when ([Type] = 'Cat') then Product
  end as BUName,
  [Type],
  Category,
  Product,
  [Dollar Sales],
  Time_Period,
  Week_end_date
  from
  (
SELECT 
	   case 
	   when ([AO_Share_Component] = 'Category') then 'Cat'
	   when ([AO_Share_Component] = 'Clorox') then 'Clx'
	   end as [Type]
	   ,'Costco' as [Source]
      ,'Costco' as [Retailer]
      ,[Time_Period]
      ,[Week_End_Date]
      ,[Sales] as [Dollar Sales]
	  ,case 
	  when (AO_Segment = 'Total' and AO_Level = 'BU Total') then AO_BU
	  when (AO_Level = 'Segment Total') then AO_Segment
	  when (AO_Level in ('All Category Total', 'Custom Total')) then AO_BU
	  when (AO_Segment <> 'Total' and AO_Level = 'BU Total') then AO_Segment
	  end as Product,
	  case 
	  when (AO_Segment = 'Total' and AO_Level = 'BU Total') then NULL
	  when (AO_Level = 'Segment Total') then AO_BU
	  when (AO_Level in ('All Category Total', 'Custom Total')) then NULL
	  when (AO_Segment <> 'Total' and AO_Level = 'BU Total') then AO_BU
	  end as Category
  FROM #all_outlet_costco_BU_aggregated
  ) a

--select * from #costco_sharetab_clx

---------------
/*

DECLARE @Fiscal_Month INT, @Fiscal_YEAR INT, @iri_week_end_date date
select @Fiscal_Month = Fiscal_Month, @Fiscal_YEAR = Fiscal_YEAR from (select TOP 1* from (select DISTINCT Fiscal_Month, Fiscal_YEAR from ebi.calendar_week_dim2 where calendar_month = MONTH(DATEADD(MM, DATEDIFF(MM, 0, GETDATE()) - 5, 0)) and calendar_year = YEAR(DATEADD(MM, DATEDIFF(MM, 0, GETDATE()) - 5, 0))) tbl) new_tbl

select @iri_week_end_date = max(wk_end_dt) from [ebi].[cal_445_wk_dim_2] where fiscal_yr_cd = @Fiscal_YEAR and rank_val = @Fiscal_Month group by fiscal_yr_cd,rank_val 
select @iri_week_end_date
*/

 IF OBJECT_ID('tempdb..#costco_sharetab_share_value') IS NOT NULL
BEGIN
DROP TABLE #costco_sharetab_share_value
END


CREATE TABLE #costco_sharetab_share_value
WITH
( DISTRIBUTION = ROUND_ROBIN
)
AS
  select [Source], Retailer, 
  case
  when ([Type] = 'Clx') then CONCAT(Product,[Type])
  when ([Type] = 'Cat') then Product
  end as BUName,
  [Type],
  Category,
  Product,
  [Share],
  Time_Period,
  Week_end_date
  from
  (
SELECT 
	   case 
	   when ([AO_Share Component] = 'Category') then 'Cat'
	   when ([AO_Share Component] = 'Clorox') then 'Clx'
	   end as [Type]
	   ,'Costco' as [Source]
      ,'Costco' as [Retailer]
      ,[Time_Period]
      ,IRI_month_end_date AS [Week_End_Date]
      ,[Share] as [Share]
	  ,case 
	  when (AO_Segment = 'Total' and AO_Level = 'BU Total') then AO_BU
	  when (AO_Level = 'Segment Total') then AO_Segment
	  when (AO_Level in ('All Category Total', 'Custom Total')) then AO_BU
	  when (AO_Segment <> 'Total' and AO_Level = 'BU Total') then AO_Segment
	  end as Product,
	  case 
	  when (AO_Segment = 'Total' and AO_Level = 'BU Total') then NULL
	  when (AO_Level = 'Segment Total') then AO_BU
	  when (AO_Level in ('All Category Total', 'Custom Total')) then NULL
	  when (AO_Segment <> 'Total' and AO_Level = 'BU Total') then AO_BU
	  end as Category
  FROM [ebi].[ebi_all_outlet_iri_panel_share] where IRI_month_end_date = @iri_week_end_date and Retailer = 'Costco'
  ) a


--select * from #costco_sharetab_share_value

----------------

select * from #costco_sharetab_clx 

--------------------


IF OBJECT_ID('tempdb..#costco_sharetab_cat') IS NOT NULL
BEGIN
DROP TABLE #costco_sharetab_cat
END 
CREATE TABLE #costco_sharetab_cat
WITH
(
DISTRIBUTION = ROUND_ROBIN
)
AS
select * from (
select  a.[Source], a.Retailer, a.Product as [BUName] , 'Cat' as [Type], a.Category, a.Product,
(a.[Dollar Sales] / NULLIF(b.Share,0)) AS [Dollar Sales],  a.Time_Period, a.Week_end_date
from #costco_sharetab_clx a
inner join #costco_sharetab_share_value b
on a.[Source] = b.[Source] and
a.Retailer = b.Retailer and
a.BUName = b.BUName and
a.[Type] = b.[Type] and
a.Product = b.Product and 
a.Time_Period = b.Time_Period
and a.Week_end_date = b.Week_end_date
) a1
where a1.[Dollar Sales] is NOT NULL


--select * from #costco_sharetab_cat order by 8,5,6,3
-------------------------


IF OBJECT_ID('tempdb..#panel_raw_data_for_special_cases') IS NOT NULL
BEGIN
DROP TABLE #panel_raw_data_for_special_cases
END 
CREATE TABLE #panel_raw_data_for_special_cases
WITH
(
DISTRIBUTION = ROUND_ROBIN
)
AS
select * from (
SELECT [AO_BU],[AO_Segment],[AO_Level],[AO_Share Component],[Product],[Retailer],[Time_Period], b.[Week_end_date],c.IRI_month_end_date as [IRI_month_end_Date],[Dollar_Sales],null as Share, GETDATE() as  [Modified_time]
FROM [ebi].[ebi_all_outlet_panel_base] b
INNER JOIN  [ebi].[ebi_all_outlet_iri_product_mapping] a
ON a.AO_Product = b.Product
INNER JOIN ebi.calendar_panel_iri c on b.Week_end_date = c.Panel_week_end_date ) a1
where a1.IRI_month_end_date = @iri_week_end_date and a1.Retailer = 'Costco'


---------------Pellets 52 , 13 weeks category
delete from #costco_sharetab_cat where Product in ('Pellets')


INSERT INTO #costco_sharetab_cat([Source], [Retailer],[BUName],[Type],[Category], [Product], [Dollar Sales], [Time_Period], [Week_end_date])
select a.Source, a.Retailer, c.AO_Segment as BUName, a.[Type], c.AO_BU as Category, c.AO_Segment as Product, (a.[Dollar Sales]*c.[Dollar_Sales])/NULLIF(b.[Dollar_Sales],0) as [Dollar Sales], c.Time_Period, a.Week_end_date
from 
(select * from #costco_sharetab_cat where Time_Period in ('Last 52 weeks','Last 13 weeks') and [Type] = 'Cat' and Category is NULL
and Product = 'Kingsford') a
INNER JOIN
(select * from #panel_raw_data_for_special_cases where Time_Period in ('Last 52 weeks','Last 13 weeks') and [AO_Share Component] = 'Category'
and AO_BU = 'Kingsford' and AO_Segment = 'Total') b
ON a.Time_Period = b.Time_Period and
a.Product = b.AO_BU
INNER JOIN
(select * from #panel_raw_data_for_special_cases where Time_Period in ('Last 52 weeks','Last 13 weeks') and [AO_Share Component] = 'Category'
and AO_BU = 'Kingsford' and AO_Segment = 'Pellets') c
ON a.Time_Period = c.Time_Period and 
a.Product = c.AO_BU



--Pellets 4-5 week category

INSERT INTO #costco_sharetab_cat([Source], [Retailer],[BUName],[Type],[Category], [Product], [Dollar Sales], [Time_Period], [Week_end_date])
select c.Source, c.Retailer, c.BUName as BUName, c.[Type], c.Category as Category, c.Product as Product, (a.[Dollar Sales]*c.[Dollar Sales])/NULLIF(b.[Dollar Sales],0) as [Dollar Sales], a.Time_Period, c.Week_end_date
from 
(select * from #costco_sharetab_cat where Time_Period = 'Last 4-5 week' and [Type] = 'Cat' and Category is NULL
and Product = 'Kingsford') a
INNER JOIN
(select * from #costco_sharetab_cat where Time_Period = 'Last 13 weeks' and [Type] = 'Cat' and Category is NULL
and Product = 'Kingsford') b
ON a.Product= b.Product
INNER JOIN
(select * from #costco_sharetab_cat where Time_Period = 'Last 13 weeks' and [Type] = 'Cat' and Category = 'Kingsford'
and Product = 'Pellets') c
ON a.Product = c.Category

---------------------------

--Wet Floor, Disinfecting Aerosol, Drain 52, 13 category
delete from #costco_sharetab_cat where Product in ('Wet Floor', 'Disinfecting Aerosol', 'Drain')


INSERT INTO #costco_sharetab_cat([Source], [Retailer],[BUName],[Type],[Category], [Product], [Dollar Sales], [Time_Period], [Week_end_date])
select a.[Source], a.Retailer, c.AO_Segment as BUName, a.[Type], c.AO_BU as Category, c.AO_Segment as Product, (a.[Dollar Sales]*c.[Dollar_Sales])/NULLIF(b.[Dollar_Sales],0) as [Dollar Sales], c.Time_Period, a.Week_end_date
from 
(select * from #costco_sharetab_cat where Time_Period in ('Last 52 weeks','Last 13 weeks') and [Type] = 'Cat' and Category is NULL
and Product = 'Home Care') a
INNER JOIN
(select * from #panel_raw_data_for_special_cases where Time_Period in ('Last 52 weeks', 'Last 13 weeks') and [AO_Share Component] = 'Category'
and AO_BU = 'Home Care' and AO_Segment ='Total') b
ON a.Time_Period = b.Time_Period and
a.Product = b.AO_BU
INNER JOIN
(select * from #panel_raw_data_for_special_cases where  [AO_Share Component] = 'Category'
and AO_BU = 'Home Care' and AO_Segment in ('Wet Floor', 'Disinfecting Aerosol', 'Drain')) c
ON a.Time_Period = c.Time_Period and 
a.Product = c.AO_BU


------------------------------


--Wet Floor, Disinfecting Aerosol, Drain 4-5 category

INSERT INTO #costco_sharetab_cat([Source], [Retailer],[BUName],[Type],[Category], [Product], [Dollar Sales], [Time_Period], [Week_end_date])
select a.[Source], a.Retailer, c.BUName as BUName, a.[Type], c.Category as Category, c.Product as Product, (a.[Dollar Sales]*c.[Dollar Sales])/NULLIF(b.[Dollar Sales],0) as [Dollar Sales], b.Time_Period as [Time_Period], a.Week_end_date
from 
(select * from #costco_sharetab_cat where Time_Period in ('Last 13 weeks') and [Type] = 'Cat' and Category is NULL
and Product = 'Home Care') a
INNER JOIN
(select * from #costco_sharetab_cat where Time_Period in ('Last 4-5 week') and [Type] = 'Cat' and Category is NULL
and Product = 'Home Care') b
ON a.Product = b.Product
INNER JOIN
(select * from #costco_sharetab_cat where Time_Period in ('Last 13 weeks') and [Type] = 'Cat' and Product  in ('Wet Floor', 'Disinfecting Aerosol', 'Drain')) c
ON a.Product = c.Category





------------------------------------------
-------------BRITA BU TOTAL---------------

delete from #costco_sharetab_cat where Product in ('Brita')

INSERT INTO #costco_sharetab_cat([Source], [Retailer],[BUName],[Type],[Category], [Product], [Dollar Sales], [Time_Period], [Week_end_date]) 
select [Source], [Retailer], 'Brita' as [BUName], [Type], NULL as [Category], 'Brita' as Product, SUM(COALESCE([Dollar Sales],0)) as [Dollar Sales],Time_Period, Week_end_date from #costco_sharetab_cat where Category in ('Brita')
group by [Source], [Retailer], [Type], [Category], Time_Period, Week_end_date


--select * from #costco_sharetab_cat where Product = 'PTF'
-----------------------------------------------------------------
----------------52 weeks Trash-----------------------------------

delete from #costco_sharetab_cat where Product in ('Glad','Trash')


INSERT INTO #costco_sharetab_cat([Source], [Retailer],[BUName],[Type],[Category], [Product], [Dollar Sales], [Time_Period], [Week_end_date]) 
select x1.[Source], x1.[Retailer], x1.[BUName], x1.[Type], x1.Category, x1.Product, (x1.[Dollar Sales]*y1.[Dollar_Sales])/NULLIF(z1.[Dollar Sales],0) as [Dollar Sales], y1.Time_Period, y1.IRI_month_end_date as [Week_end_date] from
(select [Source], [Retailer], 'Trash' as [BUName], [Type],[Category], Product, SUM(COALESCE([Dollar Sales],0)) as [Dollar Sales] from ebi.ebi_all_outlet_costco_base where Retailer = 'Costco' and Product = 'Trash' and [Type] = 'Cat' and Time_Period = 'Last 52 Weeks' and Week_end_date BETWEEN '2019-06-30' and '2020-02-23'  group by [Source],  [Retailer], [Type], [Category], [Product]) x1
INNER JOIN
(select * from #panel_raw_data_for_special_cases where Retailer = 'Costco' and Time_Period = 'Last 52 weeks' and AO_BU = 'Glad' and AO_Segment = 'Trash' and [AO_Share Component] = 'Category') y1
ON x1.Category = y1.AO_BU
and x1.Product = y1.AO_Segment
INNER JOIN
(select a1.AO_BU, a1.AO_Segment, a1.AO_Level, a1.[AO_Share Component], a1.[Retailer], a1.Time_Period, SUM(COALESCE([Dollar_Sales],0)) as [Dollar Sales] from (
	SELECT [AO_BU],[AO_Segment],[AO_Level],[AO_Share Component],[Product],[Retailer],[Time_Period], b.[Week_end_date],c.IRI_month_end_date as [IRI_month_end_Date],[Dollar_Sales],null as Share, GETDATE() as  [Modified_time]
	FROM [ebi].[ebi_all_outlet_panel_base] b
	INNER JOIN  [ebi].[ebi_all_outlet_iri_product_mapping] a
	ON a.AO_Product = b.Product
	INNER JOIN ebi.calendar_panel_iri c on b.Week_end_date = c.Panel_week_end_date ) a1
	where a1.Retailer = 'Costco'
	and a1.Time_Period = 'Last 52 weeks' and a1.IRI_month_end_date between '2019-06-30' and '2020-02-23'
and a1.AO_BU = 'Glad'
and a1.AO_Segment = 'Trash'
and a1.[AO_Share Component] = 'Category' 
GROUP BY a1.AO_BU, a1.AO_Segment, a1.AO_Level, a1.[AO_Share Component], a1.[Retailer], a1.Time_Period
) z1
ON
x1.Category = z1.AO_BU
and x1.Product = z1.AO_Segment

--------------52 weeks Glad---------------

INSERT INTO #costco_sharetab_cat([Source], [Retailer],[BUName],[Type],[Category], [Product], [Dollar Sales], [Time_Period], [Week_end_date]) 
select x1.[Source], x1.[Retailer], x1.[BUName], x1.[Type], x1.Category, x1.Product, (x1.[Dollar Sales]*y1.[Dollar_Sales])/NULLIF(z1.[Dollar Sales],0) as [Dollar Sales], y1.Time_Period, y1.IRI_month_end_date as [Week_end_date] from
(select [Source], [Retailer], 'Glad' as [BUName], [Type],[Category], Product, SUM(COALESCE([Dollar Sales],0)) as [Dollar Sales] from ebi.ebi_all_outlet_costco_base where Retailer = 'Costco' and Product = 'Glad' and [Type] = 'Cat' and Time_Period = 'Last 52 Weeks' and Week_end_date BETWEEN '2019-06-30' and '2020-02-23'  group by [Source],  [Retailer], [Type], [Category], [Product]) x1
INNER JOIN
(select * from #panel_raw_data_for_special_cases where Retailer = 'Costco' and Time_Period = 'Last 52 weeks' and AO_BU = 'Glad' and AO_Segment = 'Total' and [AO_Share Component] = 'Category') y1
ON x1.Product = y1.AO_BU
INNER JOIN
(select a1.AO_BU, a1.AO_Segment, a1.AO_Level, a1.[AO_Share Component], a1.[Retailer], a1.Time_Period, SUM(COALESCE([Dollar_Sales],0)) as [Dollar Sales] from (
	SELECT [AO_BU],[AO_Segment],[AO_Level],[AO_Share Component],[Product],[Retailer],[Time_Period], b.[Week_end_date],c.IRI_month_end_date as [IRI_month_end_Date],[Dollar_Sales],null as Share, GETDATE() as  [Modified_time]
	FROM [ebi].[ebi_all_outlet_panel_base] b
	INNER JOIN  [ebi].[ebi_all_outlet_iri_product_mapping] a
	ON a.AO_Product = b.Product
	INNER JOIN ebi.calendar_panel_iri c on b.Week_end_date = c.Panel_week_end_date ) a1
	where a1.Retailer = 'Costco'
	and a1.Time_Period = 'Last 52 weeks' and a1.IRI_month_end_date between '2019-06-30' and '2020-02-23'
and a1.AO_BU = 'Glad'
and a1.AO_Segment = 'Total'
and a1.[AO_Share Component] = 'Category' 
GROUP BY a1.AO_BU, a1.AO_Segment, a1.AO_Level, a1.[AO_Share Component], a1.[Retailer], a1.Time_Period
) z1
ON
x1.Product = z1.AO_BU

---------------------- 13 weeks Trash --------------

INSERT INTO #costco_sharetab_cat([Source], [Retailer],[BUName],[Type],[Category], [Product], [Dollar Sales], [Time_Period], [Week_end_date]) 
select x1.[Source], x1.[Retailer], x1.[BUName], x1.[Type], x1.Category, x1.Product, (x1.[Dollar Sales]*y1.[Dollar_Sales])/NULLIF(z1.[Dollar Sales],0) as [Dollar Sales], y1.Time_Period, y1.IRI_month_end_date as [Week_end_date] from
(select [Source], [Retailer], 'Trash' as [BUName], [Type],[Category], Product, SUM(COALESCE([Dollar Sales],0)) as [Dollar Sales] from ebi.ebi_all_outlet_costco_base where Retailer = 'Costco' and Product = 'Trash' and [Type] = 'Cat' and Time_Period = 'Last 13 Weeks' and Week_end_date BETWEEN '2018-09-30' and '2020-01-26'  group by [Source],  [Retailer], [Type], [Category], [Product]) x1
INNER JOIN
(select * from #panel_raw_data_for_special_cases where Retailer = 'Costco' and Time_Period = 'Last 13 weeks' and AO_BU = 'Glad' and AO_Segment = 'Trash' and [AO_Share Component] = 'Category') y1
ON x1.Category = y1.AO_BU
and x1.Product = y1.AO_Segment
INNER JOIN
(select a1.AO_BU, a1.AO_Segment, a1.AO_Level, a1.[AO_Share Component], a1.[Retailer], a1.Time_Period, SUM(COALESCE([Dollar_Sales],0)) as [Dollar Sales] from (
	SELECT [AO_BU],[AO_Segment],[AO_Level],[AO_Share Component],[Product],[Retailer],[Time_Period], b.[Week_end_date],c.IRI_month_end_date as [IRI_month_end_Date],[Dollar_Sales],null as Share, GETDATE() as  [Modified_time]
	FROM [ebi].[ebi_all_outlet_panel_base] b
	INNER JOIN  [ebi].[ebi_all_outlet_iri_product_mapping] a
	ON a.AO_Product = b.Product
	INNER JOIN ebi.calendar_panel_iri c on b.Week_end_date = c.Panel_week_end_date ) a1
	where a1.Retailer = 'Costco'
	and a1.Time_Period = 'Last 13 weeks' and a1.IRI_month_end_date between '2018-09-30' and '2020-01-26'
and a1.AO_BU = 'Glad'
and a1.AO_Segment = 'Trash'
and a1.[AO_Share Component] = 'Category' 
GROUP BY a1.AO_BU, a1.AO_Segment, a1.AO_Level, a1.[AO_Share Component], a1.[Retailer], a1.Time_Period
) z1
ON
x1.Category = z1.AO_BU
and x1.Product = z1.AO_Segment

---------------13 weeks Glad-----------------


INSERT INTO #costco_sharetab_cat([Source], [Retailer],[BUName],[Type],[Category], [Product], [Dollar Sales], [Time_Period], [Week_end_date]) 
select x1.[Source], x1.[Retailer], x1.[BUName], x1.[Type], x1.Category, x1.Product, (x1.[Dollar Sales]*y1.[Dollar_Sales])/NULLIF(z1.[Dollar Sales],0) as [Dollar Sales], y1.Time_Period, y1.IRI_month_end_date as [Week_end_date] from
(select [Source], [Retailer], 'Glad' as [BUName], [Type],[Category], Product, SUM(COALESCE([Dollar Sales],0)) as [Dollar Sales] from ebi.ebi_all_outlet_costco_base where Retailer = 'Costco' and Product = 'Glad' and [Type] = 'Cat' and Time_Period = 'Last 13 Weeks' and Week_end_date BETWEEN '2018-09-30' and '2020-01-26'  group by [Source],  [Retailer], [Type], [Category], [Product]) x1
INNER JOIN
(select * from #panel_raw_data_for_special_cases where Retailer = 'Costco' and Time_Period = 'Last 13 weeks' and AO_BU = 'Glad' and AO_Segment = 'Total' and [AO_Share Component] = 'Category') y1
ON x1.Product = y1.AO_BU
INNER JOIN
(select a1.AO_BU, a1.AO_Segment, a1.AO_Level, a1.[AO_Share Component], a1.[Retailer], a1.Time_Period, SUM(COALESCE([Dollar_Sales],0)) as [Dollar Sales] 
	from (
	SELECT [AO_BU],[AO_Segment],[AO_Level],[AO_Share Component],[Product],[Retailer],[Time_Period], b.[Week_end_date],c.IRI_month_end_date as [IRI_month_end_Date],[Dollar_Sales],null as Share, GETDATE() as  [Modified_time]
	FROM [ebi].[ebi_all_outlet_panel_base] b
	INNER JOIN  [ebi].[ebi_all_outlet_iri_product_mapping] a
	ON a.AO_Product = b.Product
	INNER JOIN ebi.calendar_panel_iri c on b.Week_end_date = c.Panel_week_end_date ) a1
	where a1.Retailer = 'Costco'
	and a1.Time_Period = 'Last 13 weeks' and a1.IRI_month_end_date between '2018-09-30' and '2020-01-26'
and a1.AO_BU = 'Glad'
and a1.AO_Segment = 'Total'
and a1.[AO_Share Component] = 'Category'
GROUP BY a1.AO_BU, a1.AO_Segment, a1.AO_Level, a1.[AO_Share Component], a1.[Retailer], a1.Time_Period
) z1
ON
x1.Product = z1.AO_BU


----------------------4-5 weeks Trash, GLAD BU TOTAL --------------


IF OBJECT_ID('tempdb..#previous_year_months') IS NOT NULL
BEGIN
DROP TABLE #previous_year_months
END 
CREATE TABLE #previous_year_months
WITH
(
DISTRIBUTION = ROUND_ROBIN
)
AS
With Calender AS
(
select *, ROW_NUMBER() OVER (ORDER BY [month_end_date]) AS [rn] from 
(select fiscal_yr_cd, rank_val, max(wk_end_dt) as month_end_date from [ebi].[cal_445_wk_dim_2] group by fiscal_yr_cd, rank_val) a
)
select a.month_end_date, b.month_end_date as [month_end_date_previous], c.month_end_date as [month_end_date_next] from
Calender a
INNER JOIN Calender b ON a.[rn] = b.[rn] + 1 
INNER JOIN Calender c ON a.[rn] = c.[rn] - 1
where a.month_end_date = (select max(wk_end_dt) from [ebi].[cal_445_wk_dim_2] where fiscal_yr_cd = @Fiscal_YEAR - 1 and rank_val = @Fiscal_Month group by fiscal_yr_cd,rank_val) 



INSERT INTO #costco_sharetab_cat([Source], [Retailer],[BUName],[Type],[Category], [Product], [Dollar Sales], [Time_Period], [Week_end_date]) 
select y1.[Source], y1.[Retailer], y1.[BUName], y1.[Type], y1.Category, y1.Product, (x1.[Dollar Sales]*y1.[Dollar Sales])/NULLIF(z1.[Dollar Sales],0) as [Dollar Sales], x1.Time_Period, y1.Week_end_date as [Week_end_date] from
(select [Source], [Retailer], [BUName], [Type],[Category], Product, [Dollar Sales], 'Last 4-5 week' as Time_Period, Week_end_date from ebi.ebi_all_outlet_costco_base where Retailer = 'Costco' and Product in ('Trash', 'Glad') and [Type] = 'Cat' and Time_Period = 'Last 4-5 Week' and Week_End_Date in (select CAST(month_end_Date as DATE) from #previous_year_months) ) x1
INNER JOIN
(select * from #costco_sharetab_cat where Retailer = 'Costco' and Time_Period = 'Last 13 weeks'  and Product in ('Trash', 'Glad') and [Type] = 'Cat') y1
ON  x1.Product = y1.Product
and x1.[Type] = y1.[Type]
INNER JOIN
(select [Source], [Retailer], Product as [BUName], [Type],[Category], Product, SUM(COALESCE([Dollar Sales],0)) as [Dollar Sales] from ebi.ebi_all_outlet_costco_base where Retailer = 'Costco' and Product in ('Trash', 'Glad') and [Type] = 'Cat' and Time_Period = 'Last 4-5 Week' and Week_end_date in (select month_end_date from #previous_year_months UNION select month_end_date_previous from #previous_year_months UNION select month_end_date_next from #previous_year_months)
GROUP BY [Source],  [Retailer], [Type], [Category], [Product]) z1
ON  x1.Product = z1.Product
and x1.[Type] = z1.[Type]

-----------------------------------------------------------------
-----------------------------------------------------------------
----------52 , 13 weeks food bags
delete from #costco_sharetab_cat where Product in ('Food Bags', 'Wraps')


INSERT INTO #costco_sharetab_cat([Source], [Retailer],[BUName],[Type],[Category], [Product], [Dollar Sales], [Time_Period], [Week_end_date])
select a.[Source], a.Retailer, c.AO_Segment as BUName, a.[Type], c.AO_BU as Category, c.AO_Segment as Product, (a.[Dollar Sales]*c.[Dollar_Sales])/NULLIF(b.[Dollar_Sales],0) as [Dollar Sales], c.Time_Period, a.Week_end_date
from 
(select * from #costco_sharetab_cat where Time_Period in ('Last 52 weeks','Last 13 weeks') and [Type] = 'Cat' and Product in ('Trash')) a
INNER JOIN
(select * from #panel_raw_data_for_special_cases where Time_Period in ('Last 52 weeks', 'Last 13 weeks') and [AO_Share Component] = 'Category'
and AO_BU = 'Glad' and AO_Segment in ('Trash')) b
ON a.Time_Period = b.Time_Period and
a.Category = b.AO_BU
INNER JOIN
(select * from #panel_raw_data_for_special_cases where  [AO_Share Component] = 'Category'
and AO_BU = 'Glad' and AO_Segment in ('Food Bags')) c
ON a.Time_Period = c.Time_Period 


-----------------52, 13 weeks wraps

INSERT INTO #costco_sharetab_cat([Source], [Retailer],[BUName],[Type],[Category], [Product], [Dollar Sales], [Time_Period], [Week_end_date])
select a.[Source], a.Retailer, c.AO_Segment as BUName, a.[Type], c.AO_BU as Category, c.AO_Segment as Product, (a.[Dollar Sales]*c.[Dollar_Sales])/NULLIF(b.[Dollar_Sales],0) as [Dollar Sales], c.Time_Period, a.Week_end_date
from 
(select * from #costco_sharetab_cat where Time_Period in ('Last 52 weeks','Last 13 weeks') and [Type] = 'Cat' and Product in ('Food Bags')) a
INNER JOIN
(select * from #panel_raw_data_for_special_cases where Time_Period in ('Last 52 weeks', 'Last 13 weeks') and [AO_Share Component] = 'Category'
and AO_BU = 'Glad' and AO_Segment in ('Trash')) b
ON a.Time_Period = b.Time_Period 
and a.Category = b.AO_BU
INNER JOIN
(select * from #panel_raw_data_for_special_cases where  [AO_Share Component] = 'Category'
and AO_BU = 'Glad' and AO_Segment in ('Wraps')) c
ON a.Time_Period = c.Time_Period 

------------------------------------4-5 weeks Food bags---------

INSERT INTO #costco_sharetab_cat([Source], [Retailer],[BUName],[Type],[Category], [Product], [Dollar Sales], [Time_Period], [Week_end_date])
select c.Source, c.Retailer, c.BUName as BUName, c.[Type], c.Category as Category, c.Product as Product, (a.[Dollar Sales]*c.[Dollar Sales])/NULLIF(b.[Dollar Sales],0) as [Dollar Sales], a.Time_Period, c.Week_end_date
from 
(select * from #costco_sharetab_cat where Time_Period = 'Last 4-5 week' and [Type] = 'Cat' and Product = 'Trash') a
INNER JOIN
(select * from #costco_sharetab_cat where Time_Period = 'Last 13 weeks' and [Type] = 'Cat' and Product in ('Trash')) b
ON a.Category = b.Category and
a.[Source] = b.[Source] and
a.[Retailer] = b.[Retailer] and
a.[Type] = b.[Type] and
a.Week_end_date = b.Week_end_date
INNER JOIN
(select * from #costco_sharetab_cat where Time_Period = 'Last 13 weeks' and [Type] = 'Cat' and Product in ('Food Bags')) c
ON a.Category = c.Category and
a.[Source] = b.[Source] and
a.[Retailer] = b.[Retailer] and
a.[Type] = b.[Type] and
a.Week_end_date = b.Week_end_date



------------------------------------4-5 weeks Wraps---------

INSERT INTO #costco_sharetab_cat([Source], [Retailer],[BUName],[Type],[Category], [Product], [Dollar Sales], [Time_Period], [Week_end_date])
select c.Source, c.Retailer, c.BUName as BUName, c.[Type], c.Category as Category, c.Product as Product, (a.[Dollar Sales]*c.[Dollar Sales])/NULLIF(b.[Dollar Sales],0) as [Dollar Sales], a.Time_Period, c.Week_end_date
from 
(select * from #costco_sharetab_cat where Time_Period = 'Last 4-5 week' and [Type] = 'Cat' and Product = 'Food Bags') a
INNER JOIN
(select * from #costco_sharetab_cat where Time_Period = 'Last 13 weeks' and [Type] = 'Cat' and Product in ('Food Bags')) b
ON a.Category = b.Category and
a.[Source] = b.[Source] and
a.[Retailer] = b.[Retailer] and
a.[Type] = b.[Type] and
a.Week_end_date = b.Week_end_date
INNER JOIN
(select * from #costco_sharetab_cat where Time_Period = 'Last 13 weeks' and [Type] = 'Cat' and Product in ('Wraps')) c
ON a.Category = c.Category and
a.[Source] = b.[Source] and
a.[Retailer] = b.[Retailer] and
a.[Type] = b.[Type] and
a.Week_end_date = b.Week_end_date



---------------------

----Category Total calculations and Total excl/ VMS burts

INSERT INTO #costco_sharetab_cat([Source], [Retailer],[BUName],[Type],[Category], [Product], [Dollar Sales], [Time_Period], [Week_end_date])
select [Source], Retailer, 'Total' AS BUName, [Type], NULL as Category, 'Total' AS Product, sum(coalesce([Dollar Sales],0)) as Sales, Time_Period, Week_End_Date
FROM (select * from #costco_sharetab_cat where Category is NULL and Product <> 'Total') a
GROUP BY [Source], Retailer, [Type], Week_end_date, Time_Period

UNION

select a1.[Source], a1.Retailer, 'Total excl VMS/Burts' AS BUName, a1.[Type], NULL as Category, 'Total excl VMS/Burts' AS Product, (coalesce(a1.[Sales],0) - coalesce(b1.[Sales],0)) as Sales, a1.Time_Period, a1.Week_End_Date 
from (select [Source], Retailer, 'Total' AS BUName, [Type], NULL as Category, 'Total' AS Product, sum(coalesce([Dollar Sales],0)) as Sales, Time_Period, Week_End_Date
FROM (select * from #costco_sharetab_cat where Category is NULL and Product <> 'Total') a
GROUP BY [Source], Retailer, [Type], Week_end_date, Time_Period ) a1
LEFT JOIN
(select [Source], Retailer, 'VMS/Burts' AS BUName, [Type], NULL as Category, 'VMS/Burts' AS Product, sum(coalesce([Dollar Sales],0)) as Sales, Time_Period, Week_End_Date
FROM (select * from #costco_sharetab_cat where Category is NULL and Product in ('VMS', 'Burts')) b
GROUP BY [Source], Retailer, [Type], Week_end_date, Time_Period) b1
ON a1.[Source] = b1.[Source] and
a1.[Retailer] = b1.[Retailer] and
a1.[Type] = b1.[Type] and
a1.Time_Period = b1.Time_Period and
a1.Week_end_date = b1.Week_end_date



--select * from #costco_sharetab_clx order by 8, 4,5,6

DELETE FROM [ebi].[ebi_all_outlet_costco_base] where [Week_end_date] in (select DISTINCT([Week_end_date]) from #costco_sharetab_clx)
INSERT INTO [ebi].[ebi_all_outlet_costco_base]([Source], [Retailer], [BUName], [Type], [Category], [Product],[Dollar Sales],[Time_Period], [Week_end_date] )
SELECT [Source], [Retailer], [BUName], [Type], [Category], [Product],[Dollar Sales],[Time_Period],  [Week_end_date] FROM #costco_sharetab_clx

INSERT INTO [ebi].[ebi_all_outlet_costco_base]([Source], [Retailer], [BUName], [Type], [Category], [Product],[Dollar Sales],[Time_Period], [Week_end_date] )
SELECT [Source], [Retailer], [BUName], [Type], [Category], [Product],[Dollar Sales],[Time_Period],  [Week_end_date] FROM #costco_sharetab_cat


END
