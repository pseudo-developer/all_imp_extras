/****** Object:  StoredProcedure [ebi].[sp_ecomm_stackline_chewy]    Script Date: 2/2/2023 10:49:10 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROC [ebi].[sp_ecomm_stackline_chewy] AS
BEGIN

/*
DECLARE @Fiscal_Month INT, @Fiscal_YEAR INT, @month_end_date DATE, @month_end_date_YAGO DATE
select @Fiscal_Month = Fiscal_Month, @Fiscal_YEAR = Fiscal_YEAR from (select TOP 1* from (select DISTINCT Fiscal_Month, Fiscal_YEAR from ebi.calendar_week_dim2 where calendar_month = MONTH(DATEADD(MM, DATEDIFF(MM, 0, GETDATE()) - 1, 0)) and calendar_year = YEAR(DATEADD(MM, DATEDIFF(MM, 0, GETDATE()) - 1, 0))) tbl) new_tbl


select @month_end_date = max(wk_end_dt) from [ebi].[cal_445_wk_dim_2] where fiscal_yr_cd = @Fiscal_YEAR and rank_val = @Fiscal_Month group by fiscal_yr_cd,rank_val 
select @month_end_date


*/
DECLARE @Fiscal_Month INT, @Fiscal_YEAR INT, @month_end_date DATE, @month_end_date_YAGO DATE
select @month_end_date = max(Month_End_Date) from [ebi].[ebi_ecomm_iri_base]
select @Fiscal_YEAR = fiscal_yr_cd, @Fiscal_Month = rank_val from [ebi].[cal_445_wk_dim_2] where wk_end_dt = @month_end_date
select @month_end_date


select @month_end_date_YAGO = max(wk_end_dt) from ebi.cal_445_wk_dim_2 where fiscal_yr_cd = @Fiscal_YEAR - 1 and rank_val = @Fiscal_Month
select @month_end_date_YAGO


IF OBJECT_ID('tempdb..#ecomm_stackline_time_aggregated') IS NOT NULL
BEGIN
DROP TABLE #ecomm_stackline_time_aggregated
END

CREATE TABLE #ecomm_stackline_time_aggregated
WITH
( DISTRIBUTION = ROUND_ROBIN
)
AS
select RetailerName, RetailerSku, SegmentName, Brand, Manufacturer, Category, Subcategory, @month_end_date as Month_End_Date, 'Last 13 weeks' as Time_period, SUM(coalesce([RetailSales],0)) as 'Sales' from ebi.ebi_stackline_base_AO where IRI_week_end_date in (select TOP 13 wk_end_dt from [ebi].[cal_445_wk_dim_2] where wk_end_dt <= @month_end_date order by wk_end_dt desc)
GROUP BY RetailerName, RetailerSku, SegmentName, Brand, Manufacturer,  Category, Subcategory

UNION

select RetailerName, RetailerSku, SegmentName, Brand, Manufacturer, Category, Subcategory, @month_end_date as Month_End_Date, 'Last 52 weeks' as Time_period, SUM(coalesce([RetailSales],0)) as 'Sales' from ebi.ebi_stackline_base_AO where IRI_week_end_date in (select TOP 52 wk_end_dt from [ebi].[cal_445_wk_dim_2] where wk_end_dt <= @month_end_date order by wk_end_dt desc)
GROUP BY RetailerName, RetailerSku, SegmentName, Brand, Manufacturer, Category, Subcategory

UNION

select RetailerName, RetailerSku, SegmentName, Brand, Manufacturer, Category, Subcategory, @month_end_date as Month_End_Date, 'Last 13 weeks YAGO' as Time_period, SUM(coalesce([RetailSales],0)) as 'Sales' from ebi.ebi_stackline_base_AO where IRI_week_end_date in (select TOP 13 wk_end_dt from [ebi].[cal_445_wk_dim_2] where wk_end_dt <= @month_end_date_YAGO order by wk_end_dt desc)
GROUP BY RetailerName, RetailerSku, SegmentName, Brand, Manufacturer,  Category, Subcategory

UNION

select RetailerName, RetailerSku, SegmentName, Brand, Manufacturer, Category, Subcategory, @month_end_date as Month_End_Date, 'Last 52 weeks YAGO' as Time_period, SUM(coalesce([RetailSales],0)) as 'Sales' from ebi.ebi_stackline_base_AO where IRI_week_end_date in (select TOP 52 wk_end_dt from [ebi].[cal_445_wk_dim_2] where wk_end_dt <= @month_end_date_YAGO order by wk_end_dt desc)
GROUP BY RetailerName, RetailerSku, SegmentName, Brand, Manufacturer, Category, Subcategory



--------------------------------------------------
IF OBJECT_ID('tempdb..#ecomm_stackline_mapped_data') IS NOT NULL
BEGIN
DROP TABLE #ecomm_stackline_mapped_data
END

CREATE TABLE #ecomm_stackline_mapped_data
WITH
( 
DISTRIBUTION = ROUND_ROBIN
)
AS
 select a.[RetailerName], a.[RetailerSku], a.[SegmentName], a.[Brand], a.[Manufacturer], a.[Category], a.[SubCategory], a.[Month_End_Date], a.[Time_Period], a.[Sales], b.BU, b.Segment
FROM (select * from #ecomm_stackline_time_aggregated) a
INNER JOIN (select * from [ebi].[ebi_ecomm_stackline_BU_mapping] where Subcategory is NOT NULL) b
ON lower(a.SegmentName) = lower(b.StacklineSegmentName) AND
lower(a.Subcategory) = lower(b.Subcategory)



UNION  

select a.[RetailerName], a.[RetailerSku], a.[SegmentName], a.[Brand], a.[Manufacturer], a.[Category], a.[SubCategory], a.[Month_End_Date], a.[Time_Period], a.[Sales], b.BU, b.Segment
FROM (select * from #ecomm_stackline_time_aggregated) a
INNER JOIN (select * from [ebi].[ebi_ecomm_stackline_BU_mapping] where Subcategory is NULL) b
ON lower(a.SegmentName) = lower(b.StacklineSegmentName)

--select Distinct Brand, Manufacturer from #ecomm_stackline_mapped_data where SegmentName in ('IRI_Official_litter_cat_litter_all') and Manufacturer <> 'Other'


---------***---------

IF OBJECT_ID('tempdb..#ecomm_stackline_BU_aggregated') IS NOT NULL
BEGIN
DROP TABLE #ecomm_stackline_BU_aggregated
END

CREATE TABLE #ecomm_stackline_BU_aggregated
WITH
( 
DISTRIBUTION = ROUND_ROBIN
)
AS
select RetailerName, BU, 'Total' AS Segment, Month_end_date, Time_Period, 'Cat' as Share_Component, 'BU Total' as [Level], SUM(coalesce([Sales],0)) as Sales
FROM #ecomm_stackline_mapped_data
GROUP BY  RetailerName, BU, Month_End_Date, Time_Period

UNION

select a.RetailerName, a.BU,'Total' AS Segment, a.Month_End_Date, a.Time_Period, 'Clx' as Share_Component, 'BU Total' as [Level], SUM(coalesce([Sales],0)) as Sales
FROM (select * from #ecomm_stackline_mapped_data where Manufacturer = 'Clorox') a
GROUP BY a.RetailerName, a.BU, a.Month_End_Date, a.Time_Period
 
    
    
UNION

select a.RetailerName, a.BU, a.Segment, a.Month_End_Date, a.Time_Period, 'Cat' as Share_Component, 'Segment Total' as [Level], SUM(coalesce([Sales],0)) as Sales
FROM (select * from #ecomm_stackline_mapped_data where Segment IS NOT NULL) a
GROUP BY a.RetailerName, a.BU, a.Segment, a.Month_End_Date, a.Time_Period

UNION

select a.RetailerName, a.BU, a.Segment, a.Month_End_Date, a.Time_Period, 'Clx' as Share_Component, 'Segment Total' as [Level], SUM(coalesce([Sales],0)) as Sales
FROM (select * from #ecomm_stackline_mapped_data where Segment IS NOT NULL and Manufacturer = 'Clorox') a
GROUP BY a.RetailerName, a.BU, a.Segment, a.Month_End_Date, a.Time_Period

UNION

select a.RetailerName, a.BU, a.Brand as [Segment], a.Month_End_Date, a.Time_Period, 'Clx' as Share_Component, 'Segment Total' as [Level], SUM(coalesce([Sales],0)) as Sales
FROM (select * from #ecomm_stackline_mapped_data where Brand in ('Fresh Step', 'Scoop Away')) a
GROUP BY a.RetailerName, a.BU, a.Brand, a.Month_End_Date, a.Time_Period

UNION

select a1.RetailerName, 'Total excl VMS/Burts' AS BU, a1.Segment, a1.Month_End_Date, a1.Time_period, a1.Share_Component, a1.[Level] , COALESCE(a1.Sales,0) - COALESCE(b1.Sales,0) AS Sales
from
(select RetailerName,'Total' AS BU, 'Total' AS Segment, Month_End_Date, Time_Period, 'Cat' as Share_Component, 'All Category Total' as [Level], SUM(coalesce([Sales],0)) as Sales
FROM #ecomm_stackline_mapped_data
GROUP BY  RetailerName, Month_End_Date, Time_Period) as a1
LEFT JOIN
(select RetailerName, 'VMS/Burts' AS BU, 'Total' as Segment, a.Month_End_Date, a.Time_Period, 'Cat' as Share_Component, 'All Category Total' as [Level], sum(COALESCE(Sales,0)) as Sales
FROM (select * from #ecomm_stackline_mapped_data where BU in ('Burt''s','VMS')) a
GROUP BY a.RetailerName,a.Month_End_Date, a.Time_Period) as b1
ON a1.Month_End_Date = b1.Month_End_Date and
a1.Time_Period = b1.Time_Period

UNION

select a1.RetailerName, 'Total excl VMS/Burts' AS BU, a1.Segment, a1.Month_End_Date, a1.Time_period, a1.Share_Component, a1.[Level] , COALESCE(a1.Sales,0) - COALESCE(b1.Sales,0) AS Sales
from
(
select a.RetailerName,'Total' AS BU, 'Total' AS Segment, a.Month_End_Date, a.Time_Period, 'Clx' as Share_Component, 'All Category Total' as [Level], SUM(coalesce([Sales],0)) as Sales
FROM (select * from #ecomm_stackline_mapped_data where Manufacturer = 'Clorox') a
GROUP BY  RetailerName, Month_End_Date, Time_Period) as a1
LEFT JOIN
(select RetailerName, 'VMS/Burts' AS BU, 'Total' as Segment, a.Month_End_Date, a.Time_Period, 'Clx' as Share_Component, 'All Category Total' as [Level], sum(COALESCE(Sales,0)) as Sales
FROM (select * from #ecomm_stackline_mapped_data where BU in ('Burt''s','VMS') and Manufacturer = 'Clorox') a
GROUP BY a.RetailerName, a.Month_End_Date, a.Time_Period) as b1
ON a1.Month_End_Date = b1.Month_End_Date and
a1.Time_Period = b1.Time_Period

--------------------------------------------------------------
select * from #ecomm_stackline_BU_aggregated order by TIme_Period, BU, Segment, Share_Component
---------------------------------------------------------------



DELETE FROM [ebi].[ebi_ecomm_stackline_processed] where Month_End_Date in (select DISTINCT(Month_End_Date) from #ecomm_stackline_BU_aggregated)
INSERT INTO [ebi].[ebi_ecomm_stackline_processed]([RetailerName], [BU], [Segment], [Month_End_Date], [Time_Period], [Share_Component], [Level], [Sales])
SELECT [RetailerName], [BU], [Segment], [Month_End_Date], [Time_Period], [Share_Component], [Level], [Sales] FROM #ecomm_stackline_BU_aggregated

--------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------

--CHEWY aggregation



IF OBJECT_ID('tempdb..#ecomm_chewy_time_aggregated') IS NOT NULL
BEGIN
DROP TABLE #ecomm_chewy_time_aggregated
END

CREATE TABLE #ecomm_chewy_time_aggregated
WITH
(
 DISTRIBUTION = ROUND_ROBIN
)
AS
select RetailerName, RetailerSku, Brand, Category, Subcategory, @month_end_date as Month_End_Date , 'Last 13 weeks' as Time_period, SUM(coalesce([RetailSales],0)) as 'Sales' from ebi.ebi_chewy_base_AO where IRI_week_end_date in (select TOP 13 wk_end_dt from [ebi].[cal_445_wk_dim_2] where wk_end_dt <= @month_end_date order by wk_end_dt desc)
GROUP BY RetailerName, RetailerSku, Brand, Category, Subcategory

UNION

select RetailerName, RetailerSku, Brand, Category, Subcategory, @month_end_date as Month_End_Date, 'Last 52 weeks' as Time_period, SUM(coalesce([RetailSales],0)) as 'Sales' from ebi.ebi_chewy_base_AO where IRI_week_end_date in (select TOP 52 wk_end_dt from [ebi].[cal_445_wk_dim_2] where wk_end_dt <= @month_end_date order by wk_end_dt desc)
GROUP BY RetailerName, RetailerSku, Brand, Category, Subcategory

UNION


select RetailerName, RetailerSku, Brand, Category, Subcategory, @month_end_date as Month_End_Date , 'Last 13 weeks YAGO' as Time_period, SUM(coalesce([RetailSales],0)) as 'Sales' from ebi.ebi_chewy_base_AO where IRI_week_end_date in (select TOP 13 wk_end_dt from [ebi].[cal_445_wk_dim_2] where wk_end_dt <= @month_end_date_YAGO order by wk_end_dt desc)
GROUP BY RetailerName, RetailerSku, Brand, Category, Subcategory

UNION

select RetailerName, RetailerSku, Brand, Category, Subcategory, @month_end_date as Month_End_Date, 'Last 52 weeks YAGO' as Time_period, SUM(coalesce([RetailSales],0)) as 'Sales' from ebi.ebi_chewy_base_AO where IRI_week_end_date in (select TOP 52 wk_end_dt from [ebi].[cal_445_wk_dim_2] where wk_end_dt <= @month_end_date_YAGO order by wk_end_dt desc)
GROUP BY RetailerName, RetailerSku, Brand, Category, Subcategory

--select * from #ecomm_chewy_time_aggregated

--select * from #ecomm_chewy_time_aggregated where Subcategory = 'Cat Litter' and Brand in ('Fresh Step', 'Scoop Away', 'Ever Clean')	
--------------------------------------------------
IF OBJECT_ID('tempdb..#ecomm_chewy_mapped_data') IS NOT NULL
BEGIN
DROP TABLE #ecomm_chewy_mapped_data
END

CREATE TABLE #ecomm_chewy_mapped_data
WITH
( DISTRIBUTION = ROUND_ROBIN
)
AS
select a.[RetailerName], a.[RetailerSku], a.[Brand], a.[Category], a.[SubCategory], a.[Month_End_Date], a.[Time_Period], a.[Sales], b.BU, b.Segment, b.Manufacturer
FROM (select * from #ecomm_chewy_time_aggregated ) a
RIGHT JOIN (select * from [ebi].[ebi_ecomm_chewy_BU_mapping] where Brands is NOT NULL) b
ON lower(a.Category) = lower(b.Category) AND
lower(a.Subcategory) = lower(b.Subcategory) AND
lower(a.Brand) = lower(b.Brands)

UNION

select a.[RetailerName], a.[RetailerSku], a.[Brand], a.[Category], a.[SubCategory], a.[Month_End_Date], a.[Time_Period], a.[Sales], b.BU, b.Segment, b.Manufacturer
FROM (select * from #ecomm_chewy_time_aggregated where Brand NOT in (select distinct(Brands) from [ebi].[ebi_ecomm_chewy_BU_mapping] where Brands is NOT NULL)) a
RIGHT JOIN (select * from [ebi].[ebi_ecomm_chewy_BU_mapping] where Brands is NULL) b
ON lower(a.Category) = lower(b.Category) AND
lower(a.Subcategory) = lower(b.Subcategory)

--select * from #ecomm_chewy_mapped_data

---------***---------

IF OBJECT_ID('tempdb..#ecomm_chewy_BU_aggregated') IS NOT NULL
BEGIN
DROP TABLE #ecomm_chewy_BU_aggregated
END

CREATE TABLE #ecomm_chewy_BU_aggregated
WITH
( 
DISTRIBUTION = ROUND_ROBIN
)
AS
select RetailerName, BU, 'Total' AS Segment, Month_End_Date, Time_Period, 'Cat' as Share_Component, 'BU Total' as [Level], SUM(coalesce([Sales],0)) as Sales
FROM #ecomm_chewy_mapped_data
GROUP BY  RetailerName, BU, Month_End_Date, Time_Period

UNION

select a.RetailerName, a.BU,'Total' AS Segment, a.Month_End_Date, a.Time_Period, 'Clx' as Share_Component, 'BU Total' as [Level], SUM(coalesce([Sales],0)) as Sales
FROM (select * from #ecomm_chewy_mapped_data where Manufacturer = 'Clorox') a
GROUP BY a.RetailerName, a.BU, a.Month_End_Date, a.Time_Period

UNION

select a.RetailerName, a.BU, a.Segment, a.Month_End_Date, a.Time_Period, 'Clx' as Share_Component, 'Segment Total' as [Level], SUM(coalesce([Sales],0)) as Sales
FROM (select * from #ecomm_chewy_mapped_data where Segment IS NOT NULL and Manufacturer = 'Clorox') a
GROUP BY a.RetailerName, a.BU, a.Segment, a.Month_End_Date, a.Time_Period

--select * from #ecomm_chewy_BU_aggregated where Segment not in ('Ever Clean') order by 4,5,6
---------------------------------------------


DELETE FROM [ebi].[ebi_ecomm_chewy_processed] where Month_End_Date in (select DISTINCT(Month_End_Date) from #ecomm_chewy_BU_aggregated)
INSERT INTO [ebi].[ebi_ecomm_chewy_processed]([RetailerName], [BU], [Segment], [Month_End_Date], [Time_Period], [Share_Component], [Level], [Sales])
SELECT [RetailerName], [BU], [Segment], [Month_End_Date], [Time_Period], [Share_Component], [Level], [Sales] FROM #ecomm_chewy_BU_aggregated



END

	
--truncate table ebi.ebi_stackline_base_AO
--insert into ebi.ebi_stackline_base_AO([RetailerId], [RetailerName], [RetailerSku], [UPC], [ModelNumber], [Title], [Brand], [Category], [SubCategory], [Stackline_WeekId], [WeekEnding], [RetailSales], [UnitsSold], [RetailPrice], [SegmentName], [Manufacturer], [IRI_week_end_date])
--select [RetailerId], [RetailerName], [RetailerSku], [UPC], [ModelNumber], [Title], [Brand], [Category], [SubCategory], [Stackline_WeekId], [WeekEnding], [RetailSales], [UnitsSold], [RetailPrice], [SegmentName], [Manufacturer], [IRI_week_end_date] from [ebi].[ebi_stackline_segment_history_monthly] where Reporting_Month = '2022-4'

--select distinct stackline_WeekID, WeekEnding from ebi.ebi_stackline_base_AO order by 1 desc
GO


