/****** Object:  StoredProcedure [ebi].[sp_all_outlet_presentation_new]    Script Date: 2/8/2023 10:23:29 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROC [ebi].[sp_all_outlet_presentation_new] AS

begin

delete from [ebi].[ebi_all_outlet_presentation] where [week_end_date] in (select distinct [week_end_date] from [ebi].[ebi_all_outlet_sharedata])



IF OBJECT_ID('tempdb..#temp_all_outlet_yago') IS NOT NULL
BEGIN
	DROP TABLE #temp_all_outlet_yago
END

CREATE TABLE #temp_all_outlet_yago
WITH
( DISTRIBUTION = ROUND_ROBIN,
CLUSTERED COLUMNSTORE INDEX
)
as
select a.[LER vs Non],a.[Tracked vs Non],case when a.Retailer = 'Total' then 'Total US Retail' else a.Retailer end as Retailer,a.BUName,a.Type,a.Category,case when a.Product = 'Total' then 'Total Clorox' when a.Product = 'Total excl VMS/Burts' then 'Total Clorox excl VMS/Burts' else a.Product end as Product,a.Time_period,a.week_end_date,
a.fiscal_year,a.fiscal_month,a.fiscal_qtr,a.Consumption,b.Consumption as Consumption_yago,a.Data_type
 from  [ebi].[ebi_all_outlet_sharedata] a left join [ebi].[ebi_all_outlet_sharedata] b
 on a.fiscal_year = b.fiscal_year+1
 and a.fiscal_month = b.fiscal_month
 and COALESCE(a.[LER vs Non],'') = COALESCE(b.[LER vs Non],'')
 and COALESCE(a.[Tracked vs Non],'') = COALESCE(b.[Tracked vs Non],'')
 and a.Retailer = b.retailer
 and a.BUName = b.BUName
 and a.Type = B.Type
 and COALESCE(A.Category,'') = COALESCE(B.Category,'')
 and a.Product = b.Product
 and a.Time_period = b.Time_period
 
 
 march 2023 - 52
 march 2022 - 52
 64 - 12 weeks extra 

IF OBJECT_ID('tempdb..#temp_all_outlet_share') IS NOT NULL
BEGIN
	DROP TABLE #temp_all_outlet_share
END

CREATE TABLE #temp_all_outlet_share
WITH
( DISTRIBUTION = ROUND_ROBIN,
CLUSTERED COLUMNSTORE INDEX
)
as
select a.[LER vs Non],a.[Tracked vs Non],a.Retailer,a.BUName,a.Type,a.Category,a.Product,a.Time_period,a.week_end_date,
a.fiscal_year,a.fiscal_month,a.fiscal_qtr,a.Data_type,a.Consumption,a.Consumption_yago,b.Consumption as [category_consumption], b.Consumption_yago as [category_consumption_yago], a.Consumption*100/NullIf(b.Consumption,0) as share, a.Consumption_yago*100/NullIf(b.Consumption_yago,0) as share_yago
 from  #temp_all_outlet_yago a left join #temp_all_outlet_yago b
 on a.fiscal_year = b.fiscal_year
 and a.fiscal_month = b.fiscal_month
 and COALESCE(a.[LER vs Non],'') = COALESCE(b.[LER vs Non],'')
 and COALESCE(a.[Tracked vs Non],'') = COALESCE(b.[Tracked vs Non],'')
 and a.Retailer = b.retailer
 and a.Type = 'Clx' and b.Type = 'Cat'
 and COALESCE(A.Category,'') = COALESCE(B.Category,'')
 and a.Product = b.Product
 and a.Time_period = b.Time_period
 where a.product not in ('Fresh Step','Scoop Away')
 
 /*For Fresh And Scoop Away -  Denominator will be BU Category total and not just Product Category Total -- hence below code is added */
UNION
select a.[LER vs Non],a.[Tracked vs Non],a.Retailer,a.BUName,a.Type,a.Category,a.Product,a.Time_period,a.week_end_date,
a.fiscal_year,a.fiscal_month,a.fiscal_qtr,a.Data_type,a.Consumption,a.Consumption_yago,b.Consumption as [category_consumption], b.Consumption_yago as [category_consumption_yago], a.Consumption*100/NullIf(b.Consumption,0) as share, a.Consumption_yago*100/NullIf(b.Consumption_yago,0) as share_yago
 from  #temp_all_outlet_yago a left join #temp_all_outlet_yago b
 on a.fiscal_year = b.fiscal_year
 and a.fiscal_month = b.fiscal_month
 and COALESCE(a.[LER vs Non],'') = COALESCE(b.[LER vs Non],'')
 and COALESCE(a.[Tracked vs Non],'') = COALESCE(b.[Tracked vs Non],'')
 and a.Retailer = b.retailer
 and a.Type = 'Clx' and b.Type = 'Cat'
 and a.product in ('Fresh Step','Scoop Away')
 and b.product in ('Litter')
 and a.Time_period = b.Time_period 
 where a.product in ('Fresh Step','Scoop Away')
 

IF OBJECT_ID('tempdb..#YOY_BU') IS NOT NULL
BEGIN
	DROP TABLE #YOY_BU
END	 

CREATE TABLE #YOY_BU
WITH
( DISTRIBUTION = ROUND_ROBIN
)
AS
 select *
from #temp_all_outlet_share where type = 'Clx' and product= 'Total Clorox'

--Retailer YOY
IF OBJECT_ID('tempdb..#YOY_Retailer') IS NOT NULL
BEGIN
	DROP TABLE #YOY_Retailer
END	 

CREATE TABLE #YOY_Retailer
WITH
( DISTRIBUTION = ROUND_ROBIN
)
AS
 select *
from #temp_all_outlet_share where type = 'Clx' and retailer = 'Total US Retail'



/*BU YOY -- Denominator for BU Sahre will be Total Clorox
BU Share : For Retailers - clorox BU sales change on yago/category BU sales change on yago - BU share yago)
Formula : 
((Clorox $sTotalLaundryClx - Clorox $sTotalLaundryClx_yago)+Clorox $sTotalTotalClx_yago)  / 
	((Category $sTotalLaundry - Category $sTotalLaundry yago) + Category $sTotalTotal_yago) - Clorox $sTotalTotalClx_yago/Category $sTotalTotal_yago

*/



/*Denominator of Retailer contribution will be Total US Retail 
Retailer Share : For BUs - clorox walmart sales change on yago/category walmart sales change on yago - walmart share yago)
Formula : 
((Clorox $sTotalClxWalmart - Clorox $sTotalClxWalmart_yago)+ Clorox $sTotalClxTotal_yago) /
	((Category $sTotalWalmart - Category $sTotalWalmart_yago) + Category $sTotalTotal_yago) -  (Clorox $sTotalClxTotal_yago/Category $sTotalTotal_yago)

*/


IF OBJECT_ID('tempdb..#temp_all_outlet_final') IS NOT NULL
BEGIN
	DROP TABLE #temp_all_outlet_final
END

CREATE TABLE #temp_all_outlet_final
WITH
( DISTRIBUTION = ROUND_ROBIN,
CLUSTERED COLUMNSTORE INDEX
)
as
select a.[LER vs Non],a.[Tracked vs Non],a.Retailer,a.BUName,a.Type,a.Category,a.Product,a.Time_period,a.week_end_date,
a.fiscal_year,a.fiscal_month,a.fiscal_qtr,a.Data_type,a.Consumption,a.Consumption_yago,a.[category_consumption],a.[category_consumption_yago], a.share, a.share_yago,
case when a.Product = 'Total Clorox' then a.share_yago 
 else  (((a.Consumption-a.Consumption_yago)+b.Consumption_yago)/ 
NULLIF(((a.[category_consumption]-a.[category_consumption_yago])+b.category_consumption_yago),0)
-(b.Consumption_yago/NULLIF(b.category_consumption_yago,0)))*100
 end as bu_share_contribution,
case when  a.retailer = 'Total US Retail' then a.share_yago 
else (((a.Consumption-a.Consumption_yago)+c.Consumption_yago)/ NULLIF(((a.[category_consumption]-a.[category_consumption_yago])+c.category_consumption_yago),0)-(c.Consumption_yago/NULLIF(c.category_consumption_yago,0)))*100  end as retailer_share_contribution
 from  #temp_all_outlet_share a left join #YOY_BU b
 on a.fiscal_year = b.fiscal_year
 and a.fiscal_month = b.fiscal_month
 and COALESCE(a.[LER vs Non],'') = COALESCE(b.[LER vs Non],'')
 and COALESCE(a.[Tracked vs Non],'') = COALESCE(b.[Tracked vs Non],'')
 and a.Retailer = b.retailer
 and COALESCE(A.Category,'') = COALESCE(B.Category,'')
 and a.Time_period = b.Time_period
 left join #YOY_Retailer c
  on a.fiscal_year = c.fiscal_year
 and a.fiscal_month = c.fiscal_month
 and a.Product = c.Product
 and COALESCE(A.Category,'') = COALESCE(c.Category,'')
 and a.Time_period = c.Time_period;


IF OBJECT_ID('tempdb..#temp_all_outlet_final_new') IS NOT NULL
BEGIN
	DROP TABLE #temp_all_outlet_final_new
END


/* BU & Retailer Share has to be updated. New formula : 
BUName		ShareContribution			Sharechange    NewShareCOntribution
BU1				1 (A)							2.4			1/4 * 5  (A/D)*E
BU2				2 (B)							1.2			2/4	* 5	 (B/D)*E
BU3				1 (C)							2			1/4 * 5  (C/D)*E
BU1+BU2+BU3		4 (D)
Total											5 (E)

ShareContribution(BU1)/ShareContribution(BU1+BU2+BU3)  * ShareChange(Total) 
(A/D)*E

For retailers only('Walmart','Target','Kroger','Sams','DG','NonLERMULO','Amazon','Costco','Home Depot','Lowes','Chewy','Other') sum to be used in denominator (F)
*/
CREATE TABLE #temp_all_outlet_final_new
WITH
( DISTRIBUTION = ROUND_ROBIN,
CLUSTERED COLUMNSTORE INDEX
)
as
/*Sum of all BU - to be used as denominator (D)*/
With BUShareContri_sum as 
(select a.[LER vs Non],a.[Tracked vs Non],a.Retailer,a.Time_period,a.week_end_date,a.Data_type,a.category,
a.fiscal_year,a.fiscal_month,a.fiscal_qtr, sum(a.BU_Share_contribution) as BU_Share 
from #temp_all_outlet_final a where  type = 'Clx' and Product not in ('Total Clorox excl VMS/Burts','Total Clorox') group by a.Retailer,a.Time_period,a.week_end_date,
a.fiscal_year,a.fiscal_month,a.fiscal_qtr,a.Data_type,a.category,a.[LER vs Non],a.[Tracked vs Non]),
 /* Deriving E for BU Share calculation - Total Clorox*/
 TotalClxShareChange as 
(select a.[LER vs Non],a.[Tracked vs Non],a.Retailer,a.Time_period,a.week_end_date,a.Data_type,a.category,
a.fiscal_year,a.fiscal_month,a.fiscal_qtr,sum(a.share-a.share_yago) as share_change 
from #temp_all_outlet_final a where  type = 'Clx' and Product in ('Total Clorox') group by a.Retailer,a.Time_period,a.week_end_date,
a.fiscal_year,a.fiscal_month,a.fiscal_qtr,a.Data_type,a.category,a.[LER vs Non],a.[Tracked vs Non]),
/* Sum of selected retailers :(F) calculation*/
RetailerShareContri_sum as 
(select a.Product,a.Time_period,a.week_end_date,a.Data_type,a.category,
a.fiscal_year,a.fiscal_month,a.fiscal_qtr, sum(a.Retailer_Share_contribution) as Retailer_Share 
from #temp_all_outlet_final a where  type = 'Clx'  and retailer in ('Walmart','Target','Kroger','Sams','DG','NonLERMULO','Amazon','Costco','Home Depot','Lowes','Chewy','Other') group by a.Product,a.Time_period,a.week_end_date,
a.fiscal_year,a.fiscal_month,a.fiscal_qtr,a.Data_type,a.category),
/* Deriving E for Retailer Share contribution - Total US Retail*/ 
 TotalUSShareChange as 
(select a.[LER vs Non],a.[Tracked vs Non],a.Product,a.Time_period,a.week_end_date,a.Data_type,a.category,
a.fiscal_year,a.fiscal_month,a.fiscal_qtr,sum(a.share-a.share_yago) as US_retail_share_change 
from #temp_all_outlet_final a where  type = 'Clx' and retailer = 'Total US Retail' group by a.Product,a.Time_period,a.week_end_date,
a.fiscal_year,a.fiscal_month,a.fiscal_qtr,a.Data_type,a.category,a.[LER vs Non],a.[Tracked vs Non])


select B.*,case when B.Product = 'Total Clorox' then B.share_yago 
 else(BU_Share_contribution/NULLIF(BU_Share,0))*share_change end as BU_Share_contribution_new,
 case when  B.retailer = 'Total US Retail' then B.share_yago 
else (REtailer_share_contribution/NULLIF(Retailer_Share,0))*US_retail_share_change end as REtailer_share_contribution_new from  #temp_all_outlet_final B left join BUShareContri_sum A 
on a.fiscal_year = b.fiscal_year
 and a.fiscal_month = b.fiscal_month
  and a.Retailer = b.retailer
 and COALESCE(A.Category,'') = COALESCE(B.Category,'')
 and a.Time_period = b.Time_period
 left join TotalClxShareChange c on
 a.fiscal_year = c.fiscal_year
 and a.fiscal_month = c.fiscal_month
  and a.Retailer = c.retailer
 and COALESCE(A.Category,'') = COALESCE(c.Category,'')
 and a.Time_period = c.Time_period
 left join RetailerShareContri_sum d
 on b.fiscal_year = d.fiscal_year
 and b.fiscal_month = d.fiscal_month
 and b.Product = d.Product
 and COALESCE(b.Category,'') = COALESCE(d.Category,'')
 and b.Time_period = d.Time_period
 left join TotalUSShareChange e on
 b.fiscal_year = e.fiscal_year
 and b.fiscal_month = e.fiscal_month
  and b.Product = e.Product
 and COALESCE(B.Category,'') = COALESCE(e.Category,'')
 and b.Time_period = e.Time_period
 
/* Untracked retailers (except Amazon) and for Total US Retail - Last4-5 Weeks should not be loaded to dashboard table
For Costco and Home Depot Consumption data(dollar sales) should not go to dashboard
*/
select * from #temp_all_outlet_final_new where Retailer ='Amazon' and Time_Period = 'Last 4-5 Weeks' 


insert into  [ebi].[ebi_all_outlet_presentation] ([LER],[Tracked],Retailer,BUName,Type,Category,Product,[Business_unit],Time_period,week_end_date,fiscal_year,fiscal_month,fiscal_qtr,Data_Type,Consumption,Consumption_yago,category_Consumption,category_consumption_yago,share,share_yago,BU_Share_Contribution,retailer_share_contribution,BU_Share_Contribution_new,retailer_share_contribution_new)
select  [LER vs Non],[Tracked vs Non],Retailer,BUName,Type,Category,Product,COALESCE(Category,Product) as [Business_unit],Time_period,week_end_date,fiscal_year,fiscal_month,fiscal_qtr,Data_Type,case when retailer in ('Costco','Home Depot') then null else Consumption end,case when retailer in ('Costco','Home Depot') then null else Consumption_yago end,case when retailer in ('Costco','Home Depot') then null else category_Consumption end,case when retailer in ('Costco','Home Depot') then null else  category_consumption_yago end,share,share_yago,round(bu_share_contribution,4),round(retailer_share_contribution,4),round(bu_share_contribution_new,4),round(retailer_share_contribution_new,4) from #temp_all_outlet_final_new where ((CONCAT([Tracked vs Non],time_period) not in ('UntrackedLast 4-5 Weeks')) or (CONCAT(Retailer,Time_period) in ('AmazonLast 4-5 Weeks'))) and CONCAT(Retailer,Time_period) not in ('UntrackedLast 4-5 Weeks','Total US RetailLast 4-5 Weeks')
END
GO

{"dest_path":"/dbfs/mnt/ebi-dev/staging/staging_precheck/stackline2","fail_path":"/dbfs/mnt/ebi-dev/raw/stackline2","source_path":"/dbfs/mnt/ebi-dev/raw/stackline2"}





