/****** Object:  StoredProcedure [ebi].[sp_iri_panel_base_AO]    Script Date: 2/1/2023 11:18:28 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROC [ebi].[sp_iri_panel_base_AO] AS


begin

delete from [ebi].[ebi_all_outlet_panel_stg] where week_end_date > CONVERT(date, GETDATE())

/*deleting records based on DISTINCT Week_end_date and Time_Period combination from base table and reloading*/
IF OBJECT_ID('tempdb..#distinct_week_end_date_timeperiod_tobe_deleted') IS NOT NULL
BEGIN
DROP TABLE #distinct_week_end_date_timeperiod_tobe_deleted
END

CREATE TABLE #distinct_week_end_date_timeperiod_tobe_deleted
WITH
( DISTRIBUTION = ROUND_ROBIN
)
AS
select a.Week_end_date, a.Time_period from
(select distinct [Week_end_date], [Time_period] from [ebi].[ebi_all_outlet_panel_stg]) a

select * from #distinct_week_end_date_timeperiod_tobe_deleted order by week_end_date

delete a from [ebi].[ebi_all_outlet_panel_base] a
inner join #distinct_week_end_date_timeperiod_tobe_deleted b on a.Week_end_date = b.Week_end_date
and a.Time_period = b.Time_period

drop table #distinct_week_end_date_timeperiod_tobe_deleted
 
insert into [ebi].[ebi_all_outlet_panel_base] ([Retailer], [Time_Period], [Week_end_date], [Product], [Dollar_Sales], [Clorox_Topline_Category_Value], [Clorox_Category_Value], [Clorox_Sub_category_value], [Clorox_Segment_Value], [Clorox_SubSegment_Value], [Clorox_Brand_Value], [Clorox_SubBrand_Value], [Clorox_Type_Value], [Clorox_Sub_Type_Value], [Clorox_Manufacture_Value], [Burts_Brand_ Value], [Burts_Natural_Brand_ Value]) 
select [Retailer], [Time_Period], [Week_end_date], [Product],TRY_CONVERT(decimal(18,5),[Dollar_Sales]), [Clorox_Topline_Category_Value], [Clorox_Category_Value], [Clorox_Sub_category_value], [Clorox_Segment_Value], [Clorox_SubSegment_Value], [Clorox_Brand_Value], [Clorox_SubBrand_Value], [Clorox_Type_Value], [Clorox_Sub_Type_Value], [Clorox_Manufacturer_Value], [Burts_Brand_Value], [Burts_Natural_Brand_Value]
 from  [ebi].[ebi_all_outlet_panel_stg]


END;


--select * from [ebi].[ebi].[ebi_all_outlet_panel_stg]

--select * from ebi.calendar_week_dim
--select * from [ebi].[ebi_all_outlet_panel_base]

GO


