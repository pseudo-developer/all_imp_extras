/****** Object:  StoredProcedure [ebi].[sp_all_outlet_VMS_base]    Script Date: 6/14/2023 10:40:49 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER PROC [ebi].[sp_all_outlet_VMS_base] @iri_week_end_date [nvarchar](200),@Fiscal_Month [INT],@Fiscal_YEAR [INT] AS 
BEGIN

select @iri_week_end_date = cast(@iri_week_end_date as Date)


/*
DECLARE @pre_fscl_month INT, @fscl_year INT, @iri_week_end_date date
select @pre_fscl_month = Fiscal_Month, @fscl_year = Fiscal_YEAR from (select TOP 1* from (select DISTINCT Fiscal_Month, Fiscal_YEAR from ebi.calendar_week_dim2 where calendar_month = MONTH(DATEADD(MM, DATEDIFF(MM, 0, GETDATE()) - 1, 0)) and calendar_year = YEAR(DATEADD(MM, DATEDIFF(MM, 0, GETDATE()) - 1, 0))) tbl) new_tbl

select @iri_week_end_date = max(wk_end_dt) from [ebi].[cal_445_wk_dim] where fiscal_yr_cd = @fscl_year and rank_val = @pre_fscl_month group by fiscal_yr_cd,rank_val 
--select @iri_week_end_date
*/


IF OBJECT_ID('tempdb..#all_outlet_VMS_mapped') IS NOT NULL
BEGIN
DROP TABLE #all_outlet_VMS_mapped
END

CREATE TABLE #all_outlet_VMS_mapped
WITH
( 
DISTRIBUTION = ROUND_ROBIN
)
AS
select a.[Product], a.[Retailer], a.[Time_Period], c.[IRI_month_end_Date] as Week_End_Date, a.[Dollar_Sales], b.[Geography], b.BU, b.Segment, b.[Type]
from (select * from [ebi].[ebi_VMS_base]) a
INNER JOIN (select * from [ebi].[ebi_all_outlet_vms_map] where Active_Flag = 'Y') b
ON a.Product = b.Product and
a.Retailer = b.Retailer
LEFT JOIN [ebi].[calendar_panel_iri] c
ON a.[Week_end_date] = c.[Panel_week_end_date]
WHERE c.[IRI_month_end_Date] = @iri_week_end_date
--order by c.[IRI_month_end_Date]


select * from #all_outlet_VMS_mapped order by 3, 8


IF OBJECT_ID('tempdb..#all_outlet_VMS_BU_aggregated') IS NOT NULL
BEGIN
DROP TABLE #all_outlet_VMS_BU_aggregated
END
CREATE TABLE #all_outlet_VMS_BU_aggregated
WITH
( 
DISTRIBUTION = ROUND_ROBIN
)
AS

select a.BU AS AO_BU, a.Segment as AO_Segment, a.Week_End_Date, a.Time_Period, a.[Type] as AO_Share_Component, 'Segment Total' as AO_level, sum(a.Dollar_Sales) as Sales
FROM (select * from #all_outlet_VMS_mapped) a
GROUP BY a.Week_end_date, a.Time_Period, a.[Type], a.BU, a.Segment

UNION

select a.BU AS AO_BU, 'Total' as AO_Segment, a.Week_End_Date, a.Time_Period, a.[Type] as AO_Share_Component, 'BU Total' as AO_level, sum(a.Dollar_Sales) as Sales
FROM (select * from #all_outlet_VMS_mapped) a
GROUP BY a.Week_end_date, a.Time_Period, a.[Type], a.BU

UNION

select 'Total' AS AO_BU, 'Total' as AO_Segment, a.Week_End_Date, a.Time_Period, a.[Type] as AO_Share_Component, 'All Category Total' as AO_level, sum(a.Dollar_Sales) as Sales
FROM (select * from #all_outlet_VMS_mapped) a
GROUP BY a.Week_end_date, a.Time_Period, a.[Type]


select * from #all_outlet_VMS_BU_aggregated order by 4, 1,2, 5
--------------------



 IF OBJECT_ID('tempdb..#VMS_sharetab') IS NOT NULL
BEGIN
DROP TABLE #VMS_sharetab
END

CREATE TABLE #VMS_sharetab
WITH
( DISTRIBUTION = ROUND_ROBIN
)
AS
  select [Source], Retailer, 
  case
  when ([Type] = 'Clx') then CONCAT(Product,[Type])
  when ([Type] = 'Cat') then Product
  end as BUName,
  [Type],
  Category,
  Product,
  [Dollar Sales],
  Time_Period,
  Week_end_date
  from
  (
SELECT 
	   case 
	   when ([AO_Share_Component] = 'Cat') then 'Cat'
	   when ([AO_Share_Component] = 'Clx') then 'Clx'
	   end as [Type]
	  ,'VMS' as [Source]
      ,'Other' as [Retailer]
      ,[Time_Period]
      ,[Week_End_Date]
      ,[Sales] as [Dollar Sales]
	  ,case 
	  when (AO_Segment = 'Total' and AO_Level = 'BU Total') then AO_BU
	  when (AO_Level = 'Segment Total') then AO_Segment
	  when (AO_Level in ('All Category Total', 'Custom Total')) then AO_BU
	  when (AO_Segment <> 'Total' and AO_Level = 'BU Total') then AO_Segment
	  end as Product,
	  case 
	  when (AO_Segment = 'Total' and AO_Level = 'BU Total') then NULL
	  when (AO_Level = 'Segment Total') then AO_BU
	  when (AO_Level in ('All Category Total', 'Custom Total')) then NULL
	  when (AO_Segment <> 'Total' and AO_Level = 'BU Total') then AO_BU
	  end as Category
  FROM #all_outlet_VMS_BU_aggregated
  ) a
 

 select * from #VMS_sharetab order by 8, 5,6,4

 ------------

 
DELETE FROM [ebi].[ebi_all_outlet_VMS_base] where [Week_end_date] in (select DISTINCT([Week_end_date]) from #VMS_sharetab)
INSERT INTO [ebi].[ebi_all_outlet_VMS_base]([Source],[Retailer], [BUName], [Type], [Category], [Product],[Dollar Sales],[Time_Period],  [Week_end_date] )
SELECT [Source], [Retailer], [BUName], [Type], [Category], [Product], [Dollar Sales],[Time_Period],  [Week_end_date] FROM #VMS_sharetab

END