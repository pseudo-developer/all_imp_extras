/****** Object:  StoredProcedure [ebi].[sp_all_outlet_iri_panel]    Script Date: 2/1/2023 6:04:47 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROC [ebi].[sp_all_outlet_iri_panel] AS

begin


IF OBJECT_ID('tempdb..#iri_panel_month_end_date_stamp') IS NOT NULL
BEGIN
DROP TABLE #iri_panel_month_end_date_stamp
END 
CREATE TABLE #iri_panel_month_end_date_stamp
WITH
(
DISTRIBUTION = ROUND_ROBIN
)
AS
SELECT [AO_BU],[AO_Segment],[AO_Level],[AO_Share Component],[Product],[Retailer],[Time_Period], b.[Week_end_date], c.IRI_month_end_Date as [IRI_month_end_Date],[Dollar_Sales],null as Share, GETDATE() as  [Modified_time]
FROM [ebi].[ebi_all_outlet_panel_base] b
INNER JOIN  (select * from [ebi].[ebi_all_outlet_iri_product_mapping] where Active_Flag = 'Y') a
ON a.AO_Product = b.Product
INNER JOIN ebi.calendar_panel_iri c on b.Week_end_date = c.Panel_week_end_date



--select * from #iri_panel_month_end_date_stamp order by IRI_Month_end_date,[AO_Share Component] ,AO_Level

--select count(distinct(week_end_date)) from #iri_panel_month_end_date_stamp where Time_period = 'Last 52 weeks'
/*
select AO_BU, AO_Segment, AO_Level, [AO_Share Component], Retailer, Time_Period, Week_end_date, IRI_Month_end_date, Dollar_Sales
from #iri_panel_month_end_date_stamp
where IRI_Month_end_date = '2021-08-22' and Time_period = 'Last 13 weeks' and Retailer = 'Total US - Costco' 
order by IRI_Month_end_date,[AO_Share Component] ,AO_Level
*/

IF OBJECT_ID('tempdb..#iri_panel_share_13_52_weeks') IS NOT NULL
BEGIN
DROP TABLE #iri_panel_share_13_52_weeks
END

CREATE TABLE #iri_panel_share_13_52_weeks
WITH
( DISTRIBUTION = ROUND_ROBIN
)
AS
SELECT  a.[AO_BU],a.[AO_Segment],a.[AO_Level],a.[AO_Share Component],a.[Product],a.[Retailer],a.[Time_Period],a.[Week_end_date], a.IRI_month_end_Date, a.Dollar_Sales/NULLIF(b.Dollar_Sales,0) as share, GETDATE() as  [Modified_time]
from 
(select * from #iri_panel_month_end_date_stamp where [AO_Share Component] = 'Clorox') a  
left join 
(select * from #iri_panel_month_end_date_stamp where [AO_Share Component] = 'Category') b
on 
a.[AO_BU]=b.[AO_BU] 
and a.[AO_Segment]= b.[AO_Segment]
and a.[AO_Level] = b.[AO_Level]
--and a.[Product] = b.[product]
and a.[Retailer] = b.[Retailer]
and a.[Time_Period]= b.[Time_period]
and a.[Week_end_date] = b.[Week_end_date]
and a.IRI_month_end_Date = b.IRI_month_end_Date

/*
select AO_BU, AO_Segment, AO_Level, [AO_Share Component], Retailer, Time_Period, Week_end_date, IRI_Month_end_date, Share
from #iri_panel_share_13_52_weeks
where IRI_month_end_date = '2021-08-22' and Time_period = 'Last 52 weeks' and Retailer = 'Total US - Costco' 
order by IRI_Month_end_date,[AO_Share Component] ,AO_Level, AO_BU, AO_Segment
*/

--select Retailer, COUNT(*) from #iri_panel_share_13_52_weeks group by Retailer


IF OBJECT_ID('tempdb..#iri_panel_share_4_5_week_share') IS NOT NULL
BEGIN
DROP TABLE #iri_panel_share_4_5_week_share
END

CREATE TABLE #iri_panel_share_4_5_week_share
WITH
( DISTRIBUTION = ROUND_ROBIN
)
AS
SELECT COALESCE(a.[AO_BU], b.[AO_BU]) as AO_BU, COALESCE(a.[AO_Segment], b.[AO_Segment]) as AO_Segment, COALESCE(a.[AO_Level], b.[AO_Level]) as AO_Level, 'Clorox' as [AO_Share Component],
COALESCE(a.[Product], b.[Product]) as Product,COALESCE(a.[Retailer], b.[Retailer]) as Retailer, 'Last 4-5 week' as [Time_Period], COALESCE(a.[Week_end_date],b.[Week_end_date]) as Week_end_date, COALESCE(a.IRI_month_end_Date, b.IRI_month_end_Date) as IRI_month_end_Date, a.share as ashare,
COALESCE(a.share,b.share) as Share, b.share as bshare, b.AO_BU as bBU, b.AO_Segment as bsegment, b.AO_Level as blevel, b.IRI_Month_end_date as bIRI_month_end_date
from (select * from #iri_panel_share_13_52_weeks where [AO_Share Component] = 'Clorox' and [Time_period] = 'Last 13 weeks') a
full join (select * from #iri_panel_share_13_52_weeks where [AO_Share Component] = 'Clorox' and [Time_period] = 'Last 52 weeks') b on 
a.[AO_BU]=b.[AO_BU] 
and a.[AO_Segment]= b.[AO_Segment]
and a.[AO_Level] = b.[AO_Level]
--and a.[Product] = b.[product]
and a.[Retailer] = b.[Retailer]
and a.[Week_end_date] = b.[Week_end_date]
and a.IRI_month_end_Date = b.IRI_month_end_Date

/*
select AO_BU, AO_Segment, AO_Level, [AO_Share Component], Retailer, Time_Period, Week_end_date, IRI_Month_end_date, Share
from #iri_panel_share_4_5_weeks_share 
where Time_period = 'Last 4-5 weeks' and IRI_month_end_date = '2021-08-22' and Retailer = 'Total US - Costco' 
order by IRI_Month_end_date, [AO_Share Component] ,AO_Level , AO_BU , AO_Segment
*/



IF OBJECT_ID('tempdb..#iri_panel_share') IS NOT NULL
BEGIN
DROP TABLE #iri_panel_share
END

CREATE TABLE #iri_panel_share
WITH
( DISTRIBUTION = ROUND_ROBIN
)
AS
SELECT [AO_BU],[AO_Segment],[AO_LEvel],[AO_Share Component],[Product],[Retailer],[Time_Period],[Week_end_date],IRI_month_end_Date,[Share]
from #iri_panel_share_4_5_week_share
UNION
SELECT [AO_BU],[AO_Segment],[AO_LEvel],[AO_Share Component],[Product],[Retailer],'Last 13 Weeks' AS [Time_Period],[Week_end_date],IRI_month_end_Date,[Share]
from #iri_panel_share_4_5_week_share
UNION
SELECT [AO_BU],[AO_Segment],[AO_LEvel],[AO_Share Component],[Product],[Retailer],[Time_Period],[Week_end_date],IRI_month_end_Date,[Share]
from #iri_panel_share_13_52_weeks where Time_period = 'Last 52 weeks'


IF OBJECT_ID('tempdb..#panel_distinct_week_end_date_timeperiod_tobe_deleted') IS NOT NULL
BEGIN
DROP TABLE #panel_distinct_week_end_date_timeperiod_tobe_deleted
END

CREATE TABLE #panel_distinct_week_end_date_timeperiod_tobe_deleted
WITH
( DISTRIBUTION = ROUND_ROBIN
)
AS
select a.IRI_Month_end_date, a.Time_period from
(select distinct [IRI_Month_end_date], [Time_period] from #iri_panel_share) a

--select * from #distinct_week_end_date_timeperiod_tobe_deleted order by week_end_date

delete a from [ebi].[ebi_all_outlet_iri_panel_share] a
inner join #panel_distinct_week_end_date_timeperiod_tobe_deleted b on a.IRI_Month_end_date = b.IRI_Month_end_date
and a.Time_period = b.Time_period


INSERT INTO [ebi].[ebi_all_outlet_iri_panel_share]([AO_BU],[AO_Segment],[AO_LEvel],[AO_Share Component],[Product],[Retailer],[Time_Period],[Week_end_date],IRI_month_end_Date,[Share], [Modified_time])
select [AO_BU],[AO_Segment],[AO_LEvel],[AO_Share Component],[Product],[Retailer],[Time_Period],[Week_end_date],IRI_month_end_Date,[Share], GETDATE()
from #iri_panel_share

/*
select * from [ebi].[ebi_all_outlet_iri_panel_share] 
where IRI_Month_end_date = '2021-08-22' and Time_period = 'Last 4-5 weeks' and Retailer = 'Total US - Costco' 
order by IRI_Month_end_date,[AO_Share Component] ,AO_Level
*/

END

/*
select * from [ebi].[ebi_all_outlet_iri_panel] where week_end_DAte = '2021-03-21'
and AO_BU = 'Home Care' and AO_Segment = 'Sprays'
and retailer = 'Total US - All Outlets' --0.24982
*/

--exec [ebi].[sp_all_outlet_iri_panel]



GO



