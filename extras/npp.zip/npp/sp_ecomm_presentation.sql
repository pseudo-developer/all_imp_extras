/****** Object:  StoredProcedure [ebi].[sp_ecomm_presentation_backup_032823]    Script Date: 3/28/2023 4:19:16 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROC [ebi].[sp_ecomm_presentation] AS
BEGIN


IF OBJECT_ID('tempdb..#stackline_chewy_litter') IS NOT NULL
BEGIN
DROP TABLE #stackline_chewy_litter
END

CREATE TABLE #stackline_chewy_litter
WITH
( DISTRIBUTION = ROUND_ROBIN
)
AS
select 'Amazon.com + Chewy' as [RetailerName], a.BU, a.Segment, a.Month_End_Date, a.Time_Period, a.Share_Component, a.[Level], a.Sales + b.Sales as [Sales]from
(select * from [ebi].[ebi_ecomm_stackline_processed]) a
INNER JOIN
(select * from [ebi].[ebi_ecomm_chewy_processed]) b
ON 
a.BU = b.BU
and a.Segment = b.Segment
and a.Month_End_Date = b.Month_End_Date
and a.Time_Period = b.Time_Period
and a.Share_Component = b.Share_Component
and a.[Level] = b.[Level]

-------------------------------------------------------------

IF OBJECT_ID('tempdb..#stackline_chewy_BU_aggregated') IS NOT NULL
BEGIN
DROP TABLE #stackline_chewy_BU_aggregated
END

CREATE TABLE #stackline_chewy_BU_aggregated
WITH
( DISTRIBUTION = ROUND_ROBIN
)
AS

select * from #stackline_chewy_litter

UNION

select * from [ebi].[ebi_ecomm_stackline_processed] where BU not in ('Litter')

UNION

select 'Amazon.com + Chewy' as [RetailerName] ,'Total' as BU, Segment, Month_End_Date, Time_Period, Share_Component, 'All Category Total'as [Level], SUM(Sales)  as [Sales] from (select * from #stackline_chewy_litter UNION select * from [ebi].[ebi_ecomm_stackline_processed] where BU not in ('Litter') ) a where Segment = 'Total'
group by Segment, Month_End_Date, Time_Period, Share_Component


--select * from #stackline_chewy_BU_aggregated
--------------

IF OBJECT_ID('tempdb..#stackline_chewy_ecomm_product_map') IS NOT NULL
BEGIN
DROP TABLE #stackline_chewy_ecomm_product_map
END

CREATE TABLE #stackline_chewy_ecomm_product_map
WITH
( DISTRIBUTION = ROUND_ROBIN
)
AS
select b.IRI_Products, b.Ecomm_Products, a.Time_Period, a.Month_End_Date, a.Sales as [Dollar_Sales], a.BU, a.Segment, a.Share_Component
from #stackline_chewy_BU_aggregated a
INNER JOIN (select * from ebi.ebi_ecomm_iri_product_BU_mapping where Active_Flag = 'Y') b
ON a.BU = b.BU and
a.Segment = b.Segment and
a.Share_Component = b.Share_Component

--select * from #stackline_chewy_ecomm_product_map order by 3,6,7,8

---------

IF OBJECT_ID('tempdb..#stackline_chewy_pivoted_final') IS NOT NULL
BEGIN
DROP TABLE #stackline_chewy_pivoted_final
END

CREATE TABLE #stackline_chewy_pivoted_final
WITH
( DISTRIBUTION = ROUND_ROBIN
)
AS
select a.IRI_Products, a.Ecomm_Products, a.Time_Period, a.Month_End_Date, a.Dollar_Sales, b.Dollar_Sales as [Dollar_Sales_YAGO], a.BU, a.Segment, a.Share_Component from 
(select * from #stackline_chewy_Ecomm_product_map where Time_Period = 'Last 13 Weeks') a
INNER JOIN
(select * from #stackline_chewy_Ecomm_product_map where Time_Period = 'Last 13 Weeks YAGO') b
ON a.Ecomm_Products = b.Ecomm_Products
and a.Month_End_Date = b.Month_End_Date

UNION

select a.IRI_Products, a.Ecomm_Products, a.Time_Period, a.Month_End_Date, a.Dollar_Sales, b.Dollar_Sales as [Dollar_Sales_YAGO], a.BU, a.Segment, a.Share_Component from 
(select * from #stackline_chewy_Ecomm_product_map where Time_Period = 'Last 52 Weeks') a
INNER JOIN
(select * from #stackline_chewy_Ecomm_product_map where Time_Period = 'Last 52 Weeks YAGO') b
ON a.Ecomm_Products = b.Ecomm_Products
and a.Month_End_Date = b.Month_End_Date

----------------------------------------------
--IRI+Stackline+Chewy

IF OBJECT_ID('tempdb..#ecomm_base') IS NOT NULL
BEGIN
DROP TABLE #ecomm_base
END

CREATE TABLE #ecomm_base
WITH
( DISTRIBUTION = ROUND_ROBIN
)
AS
select b.Ecomm_Products, 'E-Commerce' as [Geography], b.[Time_Period], b.[Month_End_Date], COALESCE((a.[Dollar_Sales]+b.[Dollar_Sales]),0) as [Dollar_sales],COALESCE((a.[Dollar_Sales_Year_AGO]+b.[Dollar_Sales_YAGO]),0) as [Dollar_sales_YAGO], b.BU, b.Segment, b.[Share_Component] from
(select * from [ebi].[ebi_ecomm_iri_processed] where Geography = 'Total E-Comm wo Amazon F3') a
RIGHT JOIN
(select * from #stackline_chewy_pivoted_final) b
ON a.Ecomm_Products = b.Ecomm_Products
and a.Time_Period = b.Time_Period
and a.Month_End_Date = b.Month_End_Date

UNION

select Ecomm_products, 'MULO+P' as [Geography], [Time_Period], [Month_End_Date], [Dollar_Sales], [Dollar_Sales_Year_AGO] as [Dollar_Sales_YAGO], [BU], [Segment], [Share_Component] from [ebi].[ebi_ecomm_iri_processed] where [Geography] = 'MULO + Pet Specialty + Pet Ecom'

UNION

select Ecomm_products, 'Amazon + Chewy' as [Geography], [Time_Period], [Month_End_Date], [Dollar_Sales], [Dollar_Sales_YAGO], [BU], [Segment], [Share_Component] from #stackline_chewy_pivoted_final



--select * from #ecomm_base order by Time_Period, [Geography],BU, Segment, Share_Component

-----
-----SHARE CALCULATIONS
IF OBJECT_ID('tempdb..#ecomm_presentation') IS NOT NULL
BEGIN
DROP TABLE #ecomm_presentation
END

CREATE TABLE #ecomm_presentation
WITH
( DISTRIBUTION = ROUND_ROBIN
)
AS
select Ecomm_products, [Geography], Time_Period, Month_End_Date, Dollar_Sales, Dollar_Sales_YAGO, Share, Share_YAGO, [Pt Chg vs YA], (([Dollar_Sales]/NULLIF([Dollar_Sales_YAGO],0)) - 1 )*100 AS [% Chg vs YAG], BU, Segment, Share_Component from 
(
select a.Ecomm_products, a.[Geography], a.[Time_Period], a.[Month_End_Date],a.[Dollar_Sales]/1000 as [Dollar_Sales], a.[Dollar_Sales_YAGO]/1000 as [Dollar_Sales_YAGO],
COALESCE(a.[Dollar_Sales]/NULLIF(b.[Dollar_sales],0),0)*100 AS Share,
COALESCE(a.[Dollar_Sales_YAGO]/NULLIF(b.[Dollar_sales_YAGO],0),0)*100 AS Share_YAGO,
(COALESCE(a.[Dollar_Sales]/NULLIF(b.[Dollar_sales],0),0)*100) - (COALESCE(a.[Dollar_Sales_YAGO]/NULLIF(b.[Dollar_sales_YAGO],0),0)*100) AS [Pt Chg vs YA],

a.[BU], a.[Segment], a.[Share_Component]
from
(select *  from #ecomm_base where Share_Component = 'Clx' and Segment not in ('Fresh Step', 'Scoop Away')) a
LEFT JOIN
(select * from #ecomm_base where Share_Component = 'Cat') b
ON a.BU = b.BU
and a.Segment = b.Segment
and a.Time_Period = b.Time_Period
and a.Month_End_Date = b.Month_End_Date
and a.[Geography] = b.[Geography]

UNION

select a.Ecomm_products, a.[Geography], a.[Time_Period], a.[Month_End_Date],a.[Dollar_Sales]/1000 as [Dollar_Sales], a.[Dollar_Sales_YAGO]/1000 as [Dollar_Sales_YAGO],
COALESCE(a.[Dollar_Sales]/NULLIF(b.[Dollar_sales],0),0)*100 AS Share,
COALESCE(a.[Dollar_Sales_YAGO]/NULLIF(b.[Dollar_sales_YAGO],0),0)*100 AS Share_YAGO,
(COALESCE(a.[Dollar_Sales]/NULLIF(b.[Dollar_sales],0),0)*100) - (COALESCE(a.[Dollar_Sales_YAGO]/NULLIF(b.[Dollar_sales_YAGO],0),0)*100) AS [Pt Chg vs YA],
a.[BU], a.[Segment], a.[Share_Component]
from
(select *  from #ecomm_base where Share_Component = 'Clx' and Segment in ('Fresh Step', 'Scoop Away')) a
LEFT JOIN
(select * from #ecomm_base where Share_Component = 'Cat' and BU = 'Litter' and Segment = 'Total') b  
ON a.BU = b.BU
and a.Time_Period = b.Time_Period
and a.Month_End_Date = b.Month_End_Date
and a.[Geography] = b.[Geography]

--Change in code done on 03-28-2023. Change includes : "Share_Component = 'Cat' ". Description : In line 182,in above code for table with alias "b", we changed the Share_Component value from "Clx" to "Cat" for Share calculations of Fresh Step and Scoop Away. Refer story 60079.


UNION

select Ecomm_products, [Geography], Time_Period, Month_End_Date, Dollar_Sales/1000 as [Dollar_Sales], Dollar_Sales_YAGO/1000 as [Dollar_Sales_YAGO], NULL as Share, NULL as Share_YAGO, NULL as [Pt Chg vs YA], BU, Segment, Share_Component from #ecomm_base where Share_Component = 'Cat'
) x


--------------------------------------------------------------------------------------


DELETE FROM [ebi].[ebi_ecomm_monthly_presentation] where Month_End_Date in (select DISTINCT(Month_End_Date) from #ecomm_presentation)
INSERT INTO [ebi].[ebi_ecomm_monthly_presentation]([Ecomm_products], [Geography], [Time_Period], [Month_End_Date], [Dollar_Sales], [Dollar_Sales_YAGO], [Share], [Share_YAGO], [Pt Chg vs YA], [% Chg vs YAG], [BU], [Segment], [Share_Component])
SELECT [Ecomm_products], [Geography], [Time_Period], [Month_End_Date], [Dollar_Sales], [Dollar_Sales_YAGO], [Share], [Share_YAGO], [Pt Chg vs YA], [% Chg vs YAG], [BU], [Segment], [Share_Component] FROM #ecomm_presentation where [Geography] <> 'Amazon + Chewy'

END

--select Month_End_Date, Geography, Time_Period, count(*) from ebi.[ebi_ecomm_monthly_presentation] group by Month_End_Date, Geography, Time_Period order by Month_End_Date, Geography, Time_Period, BU, Segment, Share_Component



--select count(*) from [ebi].[ebi_stackline_segment_history_monthly]

--select * from ebi.ebi_chewy_base_AO order by WeekID desc

--select * from ebi.ebi_stackline_base_AO order by Stackline_WeekID desc



--select * from [ebi].[ebi_ecomm_monthly_presentation] where 
----month_end_date = '2023-01-22' and
--Segment in ('Fresh Step', 'Scoop Away') 
--and time_period in ('Last 13 weeks','Last 52 weeks') and geography='E-Commerce'
--order by month_end_date desc


GO


--select count(*) from ebi.ebi_ecomm_monthly_presentation_backup_032823
--select count(*) from ebi.ebi_ecomm_monthly_presentation

--Select * into ebi.ebi_ecomm_monthly_presentation_backup_032823
--from ebi.ebi_ecomm_monthly_presentation
--where 1= 1


--Truncate table ebi.ebi_ecomm_monthly_presentation


1. Naming of notebooks and activities.
2. How we are sending errors (in what format: subject, title, everything inlcuded) and who else will get the mail, everything to be mentioned.
EXTRA : Try putting the send_email function present in most notebooks into utils notebook.
LINE no 5: what time or when the pipeline is going to be triggered. Also oto define the path where files needs to be placed. For unit testing we need to mention what will happen onc we place the file, means how to know if the run is successful.
Line no 6 (all_outlet_melt_costco) : We haven't mentioned any specefic point for him to validate for this story after completion. So we have to mention like - we need to analyse the raw file, what schema is coming in for that file and we need to think do we really need to change the schema of the file or not. If yes, then what the schea is going to be after we do transformation. Mention that. He agreed to keep the 2nd point mentioned in this story "To create a document and all....".

Line no 7: Focus should be more on the point description that we have mentioned. He strictly asking - Do we really need to change the schema? (just for the sake that it was previously done by someone, we dont have to follow that, although we can keep that if hats a better approach to handle files). NExt he said about -  to mentio how are we chaecking if an item present in the upcoming raw data should be called a missing item or new item. If it is missing/new, how are making users aware of that. In current architecture we are sending mail to users to make the know that these are missing/new items, but can we not place them in a table or something to let business people review?


dapi3b2f5b7c3da1f8767cc54ce942728070-2 - CLUSTER_DBC-EASDEV-EBI01-T_ACCESS_TOKEN
